<?php
require_once __DIR__ . '/../connect.php';
requireRole('caregiver');
mysqli_set_charset($conn, 'utf8mb4');

$caregiverId = (int)($_SESSION['user_id'] ?? 0);
$visitId = (int)($_GET['visit_id'] ?? 0);
$assignmentId = (int)($_GET['assignment_id'] ?? 0);
$visit = null;

// Only read visits for a patient currently assigned to the logged-in caregiver.
// Match on patient ID as well as the caregiver so old visits for this patient
// remain visible even if the historic visit used a different assignment ID.
if ($caregiverId > 0 && $visitId > 0 && $assignmentId > 0) {
    $sql = "SELECT vr.*, p.Fullname, v.villagename,
                   dr.display_name AS doctor_name, dr.username AS doctor_username
            FROM caregiver_visit_record vr
            JOIN patient_caregiver_assignment a
                ON a.patient_id=vr.patient_id
               AND a.assignment_id=?
               AND a.caregiver_user_id=?
            JOIN patient p ON p.Patient_id=vr.patient_id
            LEFT JOIN village v ON v.village_id=p.Village_id
            LEFT JOIN users dr ON dr.user_id=a.doctor_user_id AND dr.role='doctor'
            WHERE vr.visit_id=? AND vr.caregiver_user_id=?
              AND COALESCE(a.care_status,'กำลังดูแล') <> 'สิ้นสุดการดูแล'
            LIMIT 1";
    $stmt = mysqli_prepare($conn, $sql);
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'iiii', $assignmentId, $caregiverId, $visitId, $caregiverId);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $visit = $result ? mysqli_fetch_assoc($result) : null;
        mysqli_stmt_close($stmt);
    }
}
if (!$visit) http_response_code(404);

function cvdValue($value): string {
    $value = trim((string)($value ?? ''));
    return e($value !== '' ? $value : '-');
}
function cvdDate($value): string {
    if (!$value || $value === '0000-00-00') return '-';
    $ts = strtotime((string)$value);
    return $ts ? date('d/m/', $ts).((int)date('Y', $ts) + 543) : '-';
}
function cvdRow(string $label, $value, bool $multiline = false): void {
    echo '<tr class="cvd-row'.($multiline ? ' cvd-multiline' : '').'">'
        .'<th scope="row" class="cvd-label">'.e($label).'</th>'
        .'<td class="cvd-value">'.cvdValue($value).'</td></tr>';
}
$historyMonth = $visit ? substr((string)$visit['visit_date'], 0, 7) : date('Y-m');
$backHref = 'caregiver_visit.php?mode=history&assignment_id='.$assignmentId.'&month='.urlencode($historyMonth);
$visitPhotoUrl = $visit ? thonglangUploadedImageUrl($visit['visit_photo'] ?? '') : '';
$visitDateLabel = $visit ? cvdDate($visit['visit_date'] ?? '') : '-';
$visitTimeLabel = $visit && !empty($visit['visit_time']) ? substr((string)$visit['visit_time'],0,5).' น.' : '-';
?>
<!doctype html>
<html lang="th">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>รายละเอียดการบันทึกเข้าเยี่ยม | <?=e(appName())?></title>
<?php renderPastelTheme(); ?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Thai:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<style>
/* Visit detail: compact, aligned, readable report */
.cvd-page{
  width:100%;max-width:1140px;margin:0 auto;
  padding:16px 0 54px;color:#22474c;
  font-family:'Noto Sans Thai',sans-serif;
}
.cvd-back{
  display:inline-flex;align-items:center;justify-content:center;
  min-width:132px;min-height:48px;margin:0 0 20px;padding:0 22px;
  text-decoration:none;border:0;border-radius:15px;
  background:linear-gradient(125deg,#6ac8ca,#50b1b7);color:#fff;
  font-size:15px;font-weight:900;
  box-shadow:0 7px 18px rgba(63,163,167,.17);
}
.cvd-back:hover,.cvd-back:focus-visible{
  background:linear-gradient(125deg,#5cbec1,#429fa5);color:#fff;
}
.cvd-back:focus-visible{outline:3px solid #9ce2df;outline-offset:3px}
.cvd-sheet{
  width:100%;box-sizing:border-box;padding:35px 42px 42px;
  border:1px solid #dcebe9;border-radius:23px;
  background:#fff;box-shadow:0 10px 30px rgba(31,88,90,.035);
}
.cvd-report-header{margin:0 0 30px;padding-bottom:22px;border-bottom:1px solid #e5efed}
.cvd-report-header h1{
  margin:0;color:#1b4f55;font-size:25px;
  font-weight:900;line-height:1.5;letter-spacing:.05px;
}
.cvd-section{margin:0 0 32px}
.cvd-section:last-child{margin-bottom:0}
.cvd-section-title{
  display:flex;align-items:center;min-height:38px;
  margin:0 0 8px;padding:5px 0 5px 14px;
  border:0;border-left:4px solid #59babd;border-radius:0;
  background:transparent;color:#24565a;
  font-size:17px;font-weight:900;line-height:1.5;
}
.cvd-table{
  display:table;width:100%;table-layout:fixed;
  border-collapse:collapse;border-spacing:0;margin:0;
}
.cvd-table .cvd-key-col{width:72%}
.cvd-table .cvd-data-col{width:28%}
.cvd-table .cvd-row{display:table-row!important}
.cvd-table .cvd-label,.cvd-table .cvd-value{
  display:table-cell!important;box-sizing:border-box;
  height:58px;padding:13px 15px;
  text-align:left!important;vertical-align:middle;
  border-bottom:1px solid #e7efed;
  background:#fff!important;
  line-height:1.6;
}
.cvd-table .cvd-label{
  width:72%;padding-left:15px;padding-right:20px;
  font-size:14px;font-weight:700;color:#657e81;
}
.cvd-table .cvd-value{
  width:28%;padding-left:15px;padding-right:12px;
  font-size:15px;font-weight:800;color:#204e55;
  white-space:pre-wrap;overflow-wrap:anywhere;
}
.cvd-table .cvd-multiline .cvd-value{font-weight:700}
.cvd-table .cvd-row:last-child .cvd-label,
.cvd-table .cvd-row:last-child .cvd-value{border-bottom:0}
.cvd-photo{
  display:block;max-width:min(680px,100%);max-height:500px;
  height:auto;margin:14px 0 4px;border-radius:15px;
  border:1px solid #deece9;object-fit:contain;
}
.cvd-empty{padding:24px;background:#fff;border:1px solid #dcebe8;border-radius:15px;color:#5d777b;font-weight:700}
@media(max-width:900px){
  .cvd-page{padding:12px 0 36px}
  .cvd-sheet{padding:26px 25px 32px}
  .cvd-table .cvd-key-col{width:66%}
  .cvd-table .cvd-data-col{width:34%}
  .cvd-table .cvd-label{width:66%}
  .cvd-table .cvd-value{width:34%}
}
@media(max-width:580px){
  .cvd-back{min-width:108px;min-height:44px;margin-bottom:14px;padding:0 18px;font-size:14px}
  .cvd-sheet{padding:22px 17px 28px;border-radius:19px}
  .cvd-report-header{margin-bottom:22px;padding-bottom:17px}
  .cvd-report-header h1{font-size:21px}
  .cvd-section{margin-bottom:26px}
  .cvd-section-title{font-size:15px}
  .cvd-table .cvd-key-col{width:48%}
  .cvd-table .cvd-data-col{width:52%}
  .cvd-table .cvd-label,.cvd-table .cvd-value{height:60px;padding:11px 8px;line-height:1.55}
  .cvd-table .cvd-label{width:48%;padding-left:7px;padding-right:9px;font-size:12px}
  .cvd-table .cvd-value{width:52%;padding-left:8px;padding-right:5px;font-size:13px}
}
</style>
</head>
<body class="role-page">
<?php renderSidebar(); ?>
<main class="main">
<?php renderUserTopbar(); ?>
<div class="cvd-page">
<a href="<?=e($backHref)?>" class="cvd-back">ย้อนกลับ</a>
<?php if (!$visit): ?>
    <div class="cvd-empty">ไม่พบรายละเอียดการเข้าเยี่ยม หรือคุณไม่มีสิทธิ์เข้าถึงรายการนี้</div>
<?php else: ?>
<article class="cvd-sheet">
    <header class="cvd-report-header"><h1>รายละเอียดการบันทึกเข้าเยี่ยม</h1></header>
    <section class="cvd-section" aria-labelledby="cvd-visit-title">
        <h2 class="cvd-section-title" id="cvd-visit-title">ข้อมูลการเข้าเยี่ยม</h2>
        <table class="cvd-table"><colgroup><col class="cvd-key-col"><col class="cvd-data-col"></colgroup><tbody>
        <?php
            cvdRow('ประเภทการเยี่ยม', $visit['visit_type']);
            cvdRow('ครั้งที่เข้าเยี่ยม', $visit['visit_no']);
            cvdRow('สภาพทั่วไป', $visit['general_condition']);
            cvdRow('วัตถุประสงค์การเข้าเยี่ยม', $visit['purpose'], true);
            cvdRow('นัดติดตามครั้งถัดไป', cvdDate($visit['next_visit_date'] ?? null));
            cvdRow('การส่งต่อ', $visit['referral_type']);
            cvdRow('เหตุผลที่ส่งต่อ', $visit['referral_reason'], true);
        ?>
        </tbody></table>
    </section>
    <section class="cvd-section" aria-labelledby="cvd-care-title">
        <h2 class="cvd-section-title" id="cvd-care-title">รายละเอียดการดูแล</h2>
        <table class="cvd-table"><colgroup><col class="cvd-key-col"><col class="cvd-data-col"></colgroup><tbody>
        <?php
            cvdRow('อาการและข้อสังเกต', $visit['symptom_notes'], true);
            cvdRow('การดูแลและความช่วยเหลือที่ให้', $visit['care_actions'], true);
            cvdRow('คำแนะนำแก่ผู้สูงอายุ / ผู้ดูแล', $visit['advice'], true);
            cvdRow('หมายเหตุ', $visit['note'], true);
        ?>
        </tbody></table>
    </section>
    <?php if ($visitPhotoUrl !== ''): ?>
    <section class="cvd-section" aria-labelledby="cvd-photo-title">
        <h2 class="cvd-section-title" id="cvd-photo-title">รูปภาพประกอบการเข้าเยี่ยม</h2>
        <img class="cvd-photo" src="<?=e($visitPhotoUrl)?>" alt="รูปภาพประกอบการเข้าเยี่ยม">
    </section>
    <?php endif; ?>
</article>
<?php endif; ?>
</div>
</main>
</body>
</html>
