<?php
require_once __DIR__ . '/../connect.php';
requireRole('caregiver');
mysqli_set_charset($conn, 'utf8mb4');

$caregiverId = (int)($_SESSION['user_id'] ?? 0);
$adlId = (int)($_GET['adl_id'] ?? 0);
$error = '';
$patient = null;
$history = [];

function histH($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function histThaiDateTime(?string $value): string
{
    if (!$value) return '-';
    $ts = strtotime($value);
    if (!$ts) return (string)$value;
    $months = [1=>'ม.ค.',2=>'ก.พ.',3=>'มี.ค.',4=>'เม.ย.',5=>'พ.ค.',6=>'มิ.ย.',7=>'ก.ค.',8=>'ส.ค.',9=>'ก.ย.',10=>'ต.ค.',11=>'พ.ย.',12=>'ธ.ค.'];
    return (int)date('j',$ts).' '.$months[(int)date('n',$ts)].' '.((int)date('Y',$ts)+543).' '.date('H:i',$ts).' น.';
}

function histTableExists(mysqli $conn, string $table): bool
{
    $safe = mysqli_real_escape_string($conn, $table);
    $res = mysqli_query($conn, "SHOW TABLES LIKE '{$safe}'");
    return $res && mysqli_num_rows($res) > 0;
}

if ($adlId <= 0) {
    $error = 'ไม่พบรายการประเมินที่ต้องการดู';
} elseif (!histTableExists($conn, 'adl_assessment')) {
    $error = 'ยังไม่มีข้อมูลการประเมินในระบบ';
} else {
    $sql = "SELECT a.adl_id,a.patient_id,a.total_score,a.assessment_date,a.caregiver_total_score,a.caregiver_completed_at,
                   p.Fullname,p.Age,p.Gender,v.villagename,
                   d.display_name doctor_name,d.username doctor_username
            FROM adl_assessment a
            JOIN patient p ON p.Patient_id=a.patient_id
            LEFT JOIN village v ON v.village_id=p.Village_id
            LEFT JOIN users d ON d.user_id=a.doctor_user_id AND d.role='doctor'
            WHERE a.adl_id=? AND a.caregiver_user_id=? LIMIT 1";
    $stmt = mysqli_prepare($conn, $sql);
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'ii', $adlId, $caregiverId);
        mysqli_stmt_execute($stmt);
        $res = mysqli_stmt_get_result($stmt);
        $patient = $res ? mysqli_fetch_assoc($res) : null;
        mysqli_stmt_close($stmt);
    }
    if (!$patient) {
        $error = 'ไม่พบข้อมูล หรือรายการนี้ไม่ได้อยู่ในความรับผิดชอบของคุณ';
    } elseif (histTableExists($conn, 'caregiver_adl_history')) {
        $stmt = mysqli_prepare($conn, "SELECT * FROM caregiver_adl_history WHERE adl_id=? AND (caregiver_user_id=? OR caregiver_user_id IS NULL) AND COALESCE(assessment_round,0) >= 2 ORDER BY assessment_round DESC, assessed_at DESC, history_id DESC");
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, 'ii', $adlId, $caregiverId);
            mysqli_stmt_execute($stmt);
            $res = mysqli_stmt_get_result($stmt);
            while ($res && ($row = mysqli_fetch_assoc($res))) $history[] = $row;
            mysqli_stmt_close($stmt);
        }
    }
}

$doctorName = $patient ? (trim((string)($patient['doctor_name'] ?? '')) ?: trim((string)($patient['doctor_username'] ?? '')) ?: '-') : '-';

$currentHistoryMonth = date('Y-m');
$historyMonth = trim((string)($_GET['month'] ?? $currentHistoryMonth));
if (!preg_match('/^\d{4}-\d{2}$/', $historyMonth)) $historyMonth = $currentHistoryMonth;
if ($historyMonth > $currentHistoryMonth) $historyMonth = $currentHistoryMonth;
$historyMonthTs = strtotime($historyMonth.'-01');
$prevHistoryMonth = date('Y-m', strtotime('-1 month', $historyMonthTs));
$nextHistoryMonth = date('Y-m', strtotime('+1 month', $historyMonthTs));
$canGoNextHistoryMonth = $historyMonth < $currentHistoryMonth;
$thaiMonthsFull=[1=>'มกราคม',2=>'กุมภาพันธ์',3=>'มีนาคม',4=>'เมษายน',5=>'พฤษภาคม',6=>'มิถุนายน',7=>'กรกฎาคม',8=>'สิงหาคม',9=>'กันยายน',10=>'ตุลาคม',11=>'พฤศจิกายน',12=>'ธันวาคม'];
$historyMonthLabel=$thaiMonthsFull[(int)date('n',$historyMonthTs)].' '.((int)date('Y',$historyMonthTs)+543);
$monthHistory=array_values(array_filter($history,function($r) use ($historyMonth){ return substr((string)($r['assessed_at']??''),0,7)===$historyMonth; }));
$historyCount = count($monthHistory);
$pagedHistory = $monthHistory;
?>
<!doctype html>
<html lang="th">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>ประวัติการประเมิน | <?= e(appName()) ?></title>
<?php renderPastelTheme(); ?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Thai:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<style>
.history-page{padding-bottom:42px}.history-shell{display:grid;gap:18px}.history-head{display:flex;justify-content:space-between;align-items:flex-start;gap:18px;padding:0;border:none;border-radius:0;background:transparent;box-shadow:none}.history-head h1{margin:0 0 6px;color:#173f45;font-size:31px;line-height:1.2}.history-head p{margin:0;color:#718986;font-size:13px;line-height:1.6}.history-kicker{display:none}.history-actions{display:flex;gap:10px;flex-wrap:wrap}.history-back,.history-assess{display:inline-flex;align-items:center;justify-content:center;min-height:42px;padding:0 16px;border-radius:12px;text-decoration:none;font-size:13px;font-weight:900;border:1px solid #d2e7e3;background:#fff;color:#315f59}.history-assess{background:#54b9ba;border-color:#54b9ba;color:#fff}.patient-summary{display:grid;grid-template-columns:minmax(260px,1.2fr) repeat(4,minmax(150px,.8fr));gap:12px;padding:18px;border:1px solid #d8ebe8;border-radius:22px;background:#fff;box-shadow:0 10px 28px rgba(36,108,115,.05)}.patient-main,.summary-box{padding:16px 17px;border:1px solid #dfedeb;border-radius:16px;background:#fbfefd}.patient-name{font-size:26px;font-weight:900;color:#173f45;margin-bottom:8px}.patient-meta{color:#708783;font-size:13px;line-height:1.6}.summary-box span{display:block;color:#748b87;font-size:12px;font-weight:700;margin-bottom:6px}.summary-box strong{display:block;color:#214f54;font-size:18px;font-weight:900;line-height:1.3}.history-panel{border:1px solid #d8ebe8;border-radius:22px;background:#fff;overflow:hidden;box-shadow:0 10px 28px rgba(36,108,115,.05)}.history-panel-head{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:16px 20px;background:#eef8f7;border-bottom:1px solid #d7eae7}.history-panel-head h2{margin:0;color:#214f55;font-size:18px}.history-count{display:inline-flex;align-items:center;justify-content:center;min-width:74px;padding:8px 12px;border-radius:999px;background:#fff;border:1px solid #d5e8e4;color:#2e625c;font-weight:900;font-size:12px}.history-list{display:grid;gap:14px;padding:18px}
.history-card{border:1px solid #dfeceb;border-radius:18px;background:#fbfefd;padding:17px 18px}
.history-card-top{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;margin-bottom:14px}.history-round-link{color:inherit;text-decoration:none;display:inline-block}.history-round-link:hover{text-decoration:underline;text-underline-offset:3px}.history-round{font-size:17px;font-weight:900;color:#214e53}.history-date{margin-top:4px;color:#7a908d;font-size:12px}.history-score{min-width:84px;text-align:center;padding:10px 12px;border-radius:14px;background:#eaf8f5;color:#215e58;font-size:20px;font-weight:900}
.history-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px}.history-field{padding:12px 13px;border:1px solid #e3efed;border-radius:13px;background:#fff}.history-field span{display:block;color:#7a908d;font-size:11px;margin-bottom:5px}.history-field strong{display:block;color:#294f53;font-size:13px;line-height:1.45}
.history-detail{margin-top:12px}.history-detail summary{cursor:pointer;color:#2e6b67;font-size:13px;font-weight:900}.history-detail-body{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;margin-top:12px}.history-note{grid-column:1/-1;padding:12px 13px;border:1px solid #e3efed;border-radius:13px;background:#fff;color:#526e6c;font-size:13px;line-height:1.6}
.empty-history{padding:48px 22px;text-align:center;color:#7a908d}
.history-pagination{display:flex;align-items:center;justify-content:center;gap:6px;padding:4px 18px 20px;flex-wrap:wrap}
.history-page-btn{display:inline-flex;align-items:center;justify-content:center;min-width:36px;height:36px;padding:0 10px;border:1px solid #cfe5e2;border-radius:10px;background:#fff;color:#2f6f73;text-decoration:none;font-size:13px;font-weight:800;transition:.15s ease}
.history-page-btn:hover{background:#eef9f7;border-color:#9ed6d3}
.history-page-btn.is-active{background:#59bfc0;border-color:#59bfc0;color:#fff}
.history-page-btn.is-disabled{opacity:.35;pointer-events:none}
.history-page-ellipsis{display:inline-flex;align-items:center;justify-content:center;min-width:24px;height:36px;color:#78908c;font-weight:800}
.error-box{padding:18px;border:1px solid #efd6d6;border-radius:16px;background:#fff4f4;color:#965858}
@media(max-width:1180px){.patient-summary{grid-template-columns:repeat(2,minmax(0,1fr))}.patient-main{grid-column:1/-1}.history-grid,.history-detail-body{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:680px){.history-head{flex-direction:column}.history-actions{width:100%}.history-back,.history-assess{flex:1}.patient-summary,.history-grid,.history-detail-body{grid-template-columns:1fr}.patient-main{grid-column:auto}.history-card-top{flex-direction:column}.history-score{align-self:flex-start}}
.history-month-toolbar{display:flex;align-items:center;justify-content:flex-end;gap:12px;flex-wrap:wrap;margin:0 0 18px;padding:0;border:none;border-radius:0;background:transparent}.history-month-nav{display:flex;align-items:center;gap:10px;flex-wrap:wrap}.history-month-btn{display:inline-flex;align-items:center;justify-content:center;min-width:42px;min-height:42px;padding:0 14px;border:1px solid #cfe4e1;border-radius:13px;background:#fff;color:#2e6467;text-decoration:none;font-weight:900;box-shadow:0 6px 14px rgba(46,112,116,.04)}.history-month-current{font-size:16px;font-weight:900;color:#214f54}.history-month-picker{margin:0}.history-month-picker select{appearance:none;-webkit-appearance:none;-moz-appearance:none;min-width:240px;height:54px;padding:0 52px 0 18px;border:1px solid #cfe4e1;border-radius:16px;background-color:#fff;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='18' height='18' viewBox='0 0 24 24' fill='none' stroke='%232b3b3b' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Crect x='3' y='5' width='18' height='16' rx='2'/%3E%3Cline x1='16' y1='3' x2='16' y2='7'/%3E%3Cline x1='8' y1='3' x2='8' y2='7'/%3E%3Cline x1='3' y1='11' x2='21' y2='11'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 16px center;background-size:18px 18px;color:#244f52;font:inherit;font-size:16px;font-weight:500;outline:none;cursor:pointer;box-shadow:0 4px 12px rgba(46,112,116,.03)}.history-month-picker select:focus{border-color:#83cbc8;box-shadow:0 0 0 3px rgba(89,191,192,.10)}.history-month-form{display:flex;align-items:center;gap:8px}.history-month-form input{height:40px;border:1px solid #cfe4e1;border-radius:12px;padding:0 12px;font:inherit}.history-month-form button{height:40px;border:0;border-radius:12px;padding:0 14px;background:#59bfc0;color:#fff;font:inherit;font-weight:900}.history-table-wrap{overflow:auto}.history-table{width:100%;min-width:820px;border-collapse:collapse}.history-table th,.history-table td{padding:14px 12px;border-bottom:1px solid #e3efed;text-align:left}.history-table th{background:#eef8f7;color:#285d60;font-size:13px}.history-table td{color:#34575a;font-size:13px}.history-score-pill{display:inline-flex;padding:7px 11px;border-radius:999px;background:#eaf8f5;color:#215e58;font-weight:900}.history-detail-link{display:inline-flex;padding:8px 12px;border-radius:10px;border:1px solid #cfe4e1;background:#fff;color:#2e6467;text-decoration:none;font-weight:900}


/* Thai month picker */
.thai-month-picker{position:relative;margin:0;z-index:60}
.thai-month-picker-toggle{display:flex;align-items:center;justify-content:space-between;gap:14px;min-width:250px;height:52px;padding:0 15px 0 17px;border:1px solid #cfe4e1;border-radius:18px;background:#fff;color:#244f52;font:inherit;font-size:16px;font-weight:700;cursor:pointer;box-shadow:0 6px 14px rgba(46,112,116,.04)}
.thai-month-picker-toggle:focus,.thai-month-picker.open .thai-month-picker-toggle{border-color:#75c7c5;box-shadow:0 0 0 3px rgba(89,191,192,.12);outline:none}
.thai-month-picker-icon{width:19px;height:19px;display:inline-flex;align-items:center;justify-content:center;flex:0 0 auto}
.thai-month-picker-icon svg{width:18px;height:18px;display:block}
.thai-month-picker-popover{position:absolute;right:0;top:calc(100% + 8px);width:320px;padding:14px;background:#fff;border:1px solid #d7e5e3;border-radius:16px;box-shadow:0 18px 44px rgba(29,68,71,.18);display:none;z-index:999}
.thai-month-picker.open .thai-month-picker-popover{display:block}
.thai-month-picker-yearbar{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:2px 2px 12px;border-bottom:1px solid #e6efed;margin-bottom:12px}
.thai-month-picker-year{font-size:17px;font-weight:900;color:#244f52}
.thai-month-year-controls{display:flex;gap:6px}
.thai-month-year-btn{width:32px;height:32px;border:1px solid #d8e8e5;border-radius:9px;background:#f9fcfb;color:#5d7777;font:inherit;font-weight:900;cursor:pointer}
.thai-month-year-btn:disabled{opacity:.32;cursor:not-allowed}.thai-month-year-text{width:auto;min-width:78px;padding:0 10px;font-size:11px}
.thai-month-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:7px}
.thai-month-option{height:42px;border:1px solid transparent;border-radius:10px;background:transparent;color:#294f53;font:inherit;font-size:14px;font-weight:700;cursor:pointer}
.thai-month-option:hover{background:#eef8f7;border-color:#d8ebe8}
.thai-month-option.selected{background:#3f4a4d;color:#fff;border-color:#3f4a4d}
.thai-month-option:disabled{color:#b7c0bf;background:transparent;cursor:not-allowed}
.thai-month-picker-footer{display:flex;justify-content:flex-end;margin-top:12px;padding-top:10px;border-top:1px solid #e8f0ef}
.thai-month-today{border:0;background:transparent;color:#2f7e82;font:inherit;font-size:13px;font-weight:900;cursor:pointer;padding:5px 4px}
@media(max-width:620px){.thai-month-picker{width:100%}.thai-month-picker-toggle{width:100%;min-width:0}.thai-month-picker-popover{right:auto;left:0;width:min(320px,calc(100vw - 44px))}}


/* Consistent "รายละเอียดเพิ่มเติม" action */
.history-detail-link{display:inline-flex!important;align-items:center!important;justify-content:center!important;min-height:46px!important;padding:0 18px!important;border:1px solid #bcdedb!important;border-radius:14px!important;background:#fff!important;color:#215a60!important;text-decoration:none!important;font-size:13px!important;font-weight:900!important;box-shadow:none!important;white-space:nowrap!important}
.history-detail-link:hover{background:#f6fbfb!important;border-color:#9fd1cd!important}

</style>
</head>
<body class="role-page history-page">
<?php renderSidebar(); ?>
<main class="main">
<?php renderUserTopbar(); ?>
<div class="history-shell">
<?php if ($error !== ''): ?>
    <div class="error-box"><?= histH($error) ?></div>
    <div class="history-actions"><a class="history-back" href="caregiver_adl.php">กลับหน้าประเมิน</a></div>
<?php else: ?>
    <header class="history-head">
        <div>
            <h1>ประวัติการประเมิน ADL</h1>
        </div>
        <div class="history-actions">
            <a class="history-back" href="caregiver_adl.php">กลับหน้ารายการ</a>
            <a class="history-assess" href="caregiver_adl_form.php?adl_id=<?= (int)$adlId ?>">ประเมินครั้งถัดไป</a>
        </div>
    </header>

    <section class="patient-summary">
        <div class="patient-main">
            <div class="patient-name"><?= histH($patient['Fullname']) ?></div>
            <div class="patient-meta">อายุ <?= histH($patient['Age'] ?? '-') ?> ปี • เพศ <?= histH($patient['Gender'] ?? '-') ?> • หมู่บ้าน <?= histH($patient['villagename'] ?? '-') ?></div>
        </div>
        <div class="summary-box"><span>ผลครั้งที่ 1 โดยหมอ</span><strong><?= (int)($patient['total_score'] ?? 0) ?>/20</strong></div>
        <div class="summary-box"><span>หมอผู้ประเมิน</span><strong><?= histH($doctorName) ?></strong></div>
        <div class="summary-box"><span>ประวัติที่บันทึก</span><strong><?= number_format(count($history)) ?> ครั้ง</strong></div>
        <div class="summary-box"><span>ผลล่าสุดแคร์กิฟเวอร์</span><strong><?= $patient['caregiver_total_score'] !== null ? (int)$patient['caregiver_total_score'].'/20' : '-' ?></strong></div>
    </section>

    <section class="history-panel">
        <div class="history-panel-head"><h2>บันทึกการประเมินรายเดือน</h2><span class="history-count"><?= number_format($historyCount) ?> ครั้ง</span></div>
        <div style="padding:18px">
            <div class="history-month-toolbar">

                <form class="thai-month-picker" method="get" action="caregiver_adl_history.php">
                <input type="hidden" name="adl_id" value="<?=(int)$adlId?>">
                <input type="hidden" name="month" value="<?=histH($historyMonth)?>">
                <button type="button" class="thai-month-picker-toggle" aria-haspopup="dialog" aria-expanded="false">
                    <span class="thai-month-picker-label"><?=histH($historyMonthLabel)?></span>
                    <span class="thai-month-picker-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="5" width="18" height="16" rx="2"/><line x1="16" y1="3" x2="16" y2="7"/><line x1="8" y1="3" x2="8" y2="7"/><line x1="3" y1="11" x2="21" y2="11"/></svg></span>
                </button>
                <div class="thai-month-picker-popover" role="dialog" aria-label="เลือกเดือน">
                    <div class="thai-month-picker-yearbar"><div class="thai-month-picker-year"></div><div class="thai-month-year-controls"><button type="button" class="thai-month-year-btn thai-month-year-text" data-year-prev>ปีก่อนหน้า</button><button type="button" class="thai-month-year-btn thai-month-year-text" data-year-next>ปีถัดไป</button></div></div>
                    <div class="thai-month-grid"></div>
                    <div class="thai-month-picker-footer"><button type="button" class="thai-month-today">เดือนปัจจุบัน</button></div>
                </div>
            </form>
            </div>
            <?php if ($pagedHistory): ?>
            <div class="history-table-wrap"><table class="history-table"><thead><tr><th>วันที่ประเมิน</th><th>ครั้งที่</th><th>คะแนน</th><th>กลุ่ม ADL</th><th>รายละเอียด</th></tr></thead><tbody>
            <?php foreach($pagedHistory as $hist): ?>
                <tr>
                    <td><?=histH(histThaiDateTime($hist['assessed_at']??null))?></td>
                    <td>ครั้งที่ <?= (int)($hist['assessment_round']??0) ?></td>
                    <td><span class="history-score-pill"><?= $hist['caregiver_total_score']!==null ? (int)$hist['caregiver_total_score'].'/20' : '-' ?></span></td>
                    <td><?=histH($hist['caregiver_group']??'-')?></td>
                    <td><a class="history-detail-link" href="caregiver_adl_round_detail.php?adl_id=<?=(int)$adlId?>&round=<?=(int)($hist['assessment_round']??0)?>">รายละเอียดเพิ่มเติม</a></td>
                </tr>
            <?php endforeach; ?>
            </tbody></table></div>
            <?php else: ?><div class="empty-history">ไม่มีการประเมินในเดือนนี้</div><?php endif; ?>
        </div>
    </section>
<?php endif; ?>
</div>
</main>

<script>
(function(){
  const THAI_MONTHS=['มกราคม','กุมภาพันธ์','มีนาคม','เมษายน','พฤษภาคม','มิถุนายน','กรกฎาคม','สิงหาคม','กันยายน','ตุลาคม','พฤศจิกายน','ธันวาคม'];
  const THAI_SHORT=['ม.ค.','ก.พ.','มี.ค.','เม.ย.','พ.ค.','มิ.ย.','ก.ค.','ส.ค.','ก.ย.','ต.ค.','พ.ย.','ธ.ค.'];
  function initPicker(root){
    const toggle=root.querySelector('.thai-month-picker-toggle');
    const label=root.querySelector('.thai-month-picker-label');
    const pop=root.querySelector('.thai-month-picker-popover');
    const yearEl=root.querySelector('.thai-month-picker-year');
    const grid=root.querySelector('.thai-month-grid');
    const hidden=root.querySelector('input[name="month"]');
    const prevYear=root.querySelector('[data-year-prev]');
    const nextYear=root.querySelector('[data-year-next]');
    const todayBtn=root.querySelector('.thai-month-today');
    if(!toggle||!pop||!yearEl||!grid||!hidden)return;
    const now=new Date();
    const maxY=now.getFullYear(), maxM=now.getMonth()+1;
    let [selY,selM]=(hidden.value||'').split('-').map(Number);
    if(!selY||!selM){selY=maxY;selM=maxM;}
    let viewY=selY;
    function close(){root.classList.remove('open');toggle.setAttribute('aria-expanded','false');}
    function render(){
      yearEl.textContent=String(viewY+543);
      grid.innerHTML='';
      THAI_SHORT.forEach((m,i)=>{
        const month=i+1;
        const b=document.createElement('button');b.type='button';b.className='thai-month-option';b.textContent=m;
        const future=viewY>maxY||(viewY===maxY&&month>maxM);
        b.disabled=future;
        if(viewY===selY&&month===selM)b.classList.add('selected');
        b.addEventListener('click',()=>{selY=viewY;selM=month;hidden.value=selY+'-'+String(selM).padStart(2,'0');label.textContent=THAI_MONTHS[selM-1]+' '+(selY+543);close();hidden.form.submit();});
        grid.appendChild(b);
      });
      if(nextYear) nextYear.disabled=viewY>=maxY;
    }
    toggle.addEventListener('click',e=>{e.stopPropagation();const isOpen=root.classList.toggle('open');toggle.setAttribute('aria-expanded',isOpen?'true':'false');if(isOpen){viewY=selY;render();}});
    prevYear&&prevYear.addEventListener('click',()=>{viewY--;render();});
    nextYear&&nextYear.addEventListener('click',()=>{if(viewY<maxY){viewY++;render();}});
    todayBtn&&todayBtn.addEventListener('click',()=>{selY=maxY;selM=maxM;hidden.value=selY+'-'+String(selM).padStart(2,'0');label.textContent=THAI_MONTHS[selM-1]+' '+(selY+543);close();hidden.form.submit();});
    document.addEventListener('click',e=>{if(!root.contains(e.target))close();});
    render();
  }
  document.querySelectorAll('.thai-month-picker').forEach(initPicker);
})();
</script>

</body>
</html>
