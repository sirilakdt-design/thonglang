<?php
require_once __DIR__ . '/../connect.php';
ensureThonglangCoreSchema($conn);
requireRole('caregiver');
mysqli_set_charset($conn, 'utf8mb4');

$error = '';
$message = '';
$caregiverId = (int)($_SESSION['user_id'] ?? 0);

/* =========================================================
   ตารางการมอบหมายผู้สูงอายุ
========================================================= */
$createSql = "CREATE TABLE IF NOT EXISTS patient_caregiver_assignment (
    assignment_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    caregiver_user_id INT NOT NULL,
    doctor_user_id INT NOT NULL,
    assigned_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    care_status VARCHAR(30) NOT NULL DEFAULT 'กำลังดูแล',
    next_visit_date DATE NULL,
    care_end_reason VARCHAR(120) NULL,
    care_status_note VARCHAR(255) NULL,
    care_status_updated_at DATETIME NULL,
    UNIQUE KEY uq_patient_assignment (patient_id),
    KEY idx_caregiver_user (caregiver_user_id),
    KEY idx_doctor_user (doctor_user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if (!mysqli_query($conn, $createSql)) {
    $error = 'ไม่สามารถเตรียมข้อมูลการมอบหมายผู้สูงอายุได้: ' . mysqli_error($conn);
}

/* รองรับฐานข้อมูลเดิม โดยเตรียมเฉพาะคอลัมน์ที่จำเป็น */
if ($error === '') {
    $requiredColumns = [
        'care_status' => "VARCHAR(30) NOT NULL DEFAULT 'กำลังดูแล'",
        'next_visit_date' => 'DATE NULL',
        'care_end_reason' => 'VARCHAR(120) NULL',
        'care_status_note' => 'VARCHAR(255) NULL',
        'care_status_updated_at' => 'DATETIME NULL',
    ];
    foreach ($requiredColumns as $columnName => $definition) {
        $check = mysqli_query($conn, "SHOW COLUMNS FROM patient_caregiver_assignment LIKE '" . mysqli_real_escape_string($conn, $columnName) . "'");
        if ($check && mysqli_num_rows($check) === 0) {
            if (!mysqli_query($conn, "ALTER TABLE patient_caregiver_assignment ADD COLUMN `$columnName` $definition")) {
                $error = 'ไม่สามารถเตรียมข้อมูลการมอบหมายได้: ' . mysqli_error($conn);
                break;
            }
        }
    }
}

/* =========================================================
   ข้อมูลแคร์กิฟเวอร์ที่กำลังเข้าสู่ระบบ
========================================================= */
$currentCaregiver = [
    'username' => '',
    'display_name' => '',
];

if ($caregiverId > 0) {
    $stmt = mysqli_prepare(
        $conn,
        "SELECT username, display_name
         FROM users
         WHERE user_id=? AND role='caregiver'
         LIMIT 1"
    );

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'i', $caregiverId);
        mysqli_stmt_execute($stmt);
        $res = mysqli_stmt_get_result($stmt);
        if ($row = mysqli_fetch_assoc($res)) {
            $currentCaregiver = $row;
        }
        mysqli_stmt_close($stmt);
    }
}


/* =========================================================
   แคร์กิฟเวอร์ลบผู้สูงอายุออกจากรายการในความดูแล
   (ลบเฉพาะการมอบหมาย ไม่ลบข้อมูลผู้สูงอายุออกจากระบบ)
========================================================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'remove_patient_assignment' && $error === '') {
    $patientId = (int)($_POST['patient_id'] ?? 0);

    if ($patientId <= 0 || $caregiverId <= 0) {
        $error = 'ไม่พบข้อมูลผู้สูงอายุที่ต้องการลบ';
    } else {
        $stmt = mysqli_prepare(
            $conn,
            "DELETE FROM patient_caregiver_assignment
             WHERE patient_id = ? AND caregiver_user_id = ?
             LIMIT 1"
        );

        if (!$stmt) {
            $error = 'ไม่สามารถเตรียมคำสั่งลบได้: ' . mysqli_error($conn);
        } else {
            mysqli_stmt_bind_param($stmt, 'ii', $patientId, $caregiverId);
            if (mysqli_stmt_execute($stmt)) {
                $message = 'ลบผู้สูงอายุออกจากรายการในความดูแลเรียบร้อยแล้ว';
            } else {
                $error = 'ลบข้อมูลไม่สำเร็จ: ' . mysqli_stmt_error($stmt);
            }
            mysqli_stmt_close($stmt);
        }
    }
}

/* =========================================================
   แคร์กิฟเวอร์เพิ่ม / เปลี่ยนรูปผู้สูงอายุในความดูแล
========================================================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'upload_patient_photo' && $error === '') {
    $patientId = (int)($_POST['patient_id'] ?? 0);

    if ($patientId <= 0 || $caregiverId <= 0) {
        $error = 'ไม่พบข้อมูลผู้สูงอายุที่ต้องการเพิ่มรูปภาพ';
    } else {
        $checkStmt = mysqli_prepare(
            $conn,
            "SELECT p.Photo
             FROM patient_caregiver_assignment a
             JOIN patient p ON p.Patient_id = a.patient_id
             WHERE a.patient_id = ?
               AND a.caregiver_user_id = ?
               AND COALESCE(a.care_status,'กำลังดูแล') <> 'สิ้นสุดการดูแล'
             LIMIT 1"
        );

        if (!$checkStmt) {
            $error = 'ไม่สามารถตรวจสอบสิทธิ์การเพิ่มรูปภาพได้: ' . mysqli_error($conn);
        } else {
            mysqli_stmt_bind_param($checkStmt, 'ii', $patientId, $caregiverId);
            mysqli_stmt_execute($checkStmt);
            $checkRes = mysqli_stmt_get_result($checkStmt);
            $patientRow = $checkRes ? mysqli_fetch_assoc($checkRes) : null;
            mysqli_stmt_close($checkStmt);

            if (!$patientRow) {
                $error = 'คุณสามารถเพิ่มรูปได้เฉพาะผู้สูงอายุที่อยู่ในความดูแลของคุณเท่านั้น';
            } else {
                $upload = thonglangHandleImageUpload('patient_photo', 'patients');

                if (!empty($upload['error'])) {
                    $error = (string)$upload['error'];
                } elseif (empty($upload['uploaded']) || empty($upload['path'])) {
                    $error = 'กรุณาเลือกไฟล์รูปภาพก่อนบันทึก';
                } else {
                    $newPhoto = (string)$upload['path'];
                    $oldPhoto = trim((string)($patientRow['Photo'] ?? ''));

                    $updateStmt = mysqli_prepare($conn, "UPDATE patient SET Photo = ? WHERE Patient_id = ?");
                    if (!$updateStmt) {
                        thonglangDeleteUploadedFile($newPhoto);
                        $error = 'ไม่สามารถเตรียมคำสั่งบันทึกรูปภาพได้: ' . mysqli_error($conn);
                    } else {
                        mysqli_stmt_bind_param($updateStmt, 'si', $newPhoto, $patientId);
                        if (mysqli_stmt_execute($updateStmt)) {
                            if ($oldPhoto !== '' && $oldPhoto !== $newPhoto) {
                                thonglangDeleteUploadedFile($oldPhoto);
                            }
                            $message = 'บันทึกรูปภาพผู้สูงอายุเรียบร้อยแล้ว';
                        } else {
                            thonglangDeleteUploadedFile($newPhoto);
                            $error = 'บันทึกรูปภาพไม่สำเร็จ: ' . mysqli_stmt_error($updateStmt);
                        }
                        mysqli_stmt_close($updateStmt);
                    }
                }
            }
        }
    }
}

/* =========================================================
   แคร์กิฟเวอร์เพิ่ม / แก้ไขพิกัดบ้านผู้สูงอายุในความดูแล
========================================================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'update_patient_coordinates' && $error === '') {
    $patientId = (int)($_POST['patient_id'] ?? 0);
    $latitudeRaw = trim((string)($_POST['latitude'] ?? ''));
    $longitudeRaw = trim((string)($_POST['longitude'] ?? ''));

    if ($patientId <= 0 || $caregiverId <= 0) {
        $error = 'ไม่พบข้อมูลผู้สูงอายุที่ต้องการเพิ่มพิกัด';
    } elseif ($latitudeRaw === '' || $longitudeRaw === '') {
        $error = 'กรุณาระบุละติจูดและลองจิจูดให้ครบถ้วน';
    } elseif (!is_numeric($latitudeRaw) || !is_numeric($longitudeRaw)) {
        $error = 'ค่าละติจูดและลองจิจูดต้องเป็นตัวเลข';
    } else {
        $latitude = (float)$latitudeRaw;
        $longitude = (float)$longitudeRaw;

        if ($latitude < -90 || $latitude > 90) {
            $error = 'ละติจูดต้องอยู่ระหว่าง -90 ถึง 90';
        } elseif ($longitude < -180 || $longitude > 180) {
            $error = 'ลองจิจูดต้องอยู่ระหว่าง -180 ถึง 180';
        } else {
            $checkStmt = mysqli_prepare(
                $conn,
                "SELECT a.patient_id
                 FROM patient_caregiver_assignment a
                 WHERE a.patient_id=?
                   AND a.caregiver_user_id=?
                   AND COALESCE(a.care_status,'กำลังดูแล') <> 'สิ้นสุดการดูแล'
                 LIMIT 1"
            );

            if (!$checkStmt) {
                $error = 'ไม่สามารถตรวจสอบสิทธิ์การเพิ่มพิกัดได้: ' . mysqli_error($conn);
            } else {
                mysqli_stmt_bind_param($checkStmt, 'ii', $patientId, $caregiverId);
                mysqli_stmt_execute($checkStmt);
                $owned = mysqli_fetch_assoc(mysqli_stmt_get_result($checkStmt));
                mysqli_stmt_close($checkStmt);

                if (!$owned) {
                    $error = 'คุณสามารถเพิ่มพิกัดได้เฉพาะผู้สูงอายุที่อยู่ในความดูแลของคุณเท่านั้น';
                } else {
                    $updateStmt = mysqli_prepare($conn, 'UPDATE patient SET Latitude=?, Longitude=? WHERE Patient_id=?');
                    if (!$updateStmt) {
                        $error = 'ไม่สามารถเตรียมคำสั่งบันทึกพิกัดได้: ' . mysqli_error($conn);
                    } else {
                        mysqli_stmt_bind_param($updateStmt, 'ddi', $latitude, $longitude, $patientId);
                        if (mysqli_stmt_execute($updateStmt)) {
                            $message = 'บันทึกพิกัดบ้านผู้สูงอายุเรียบร้อยแล้ว';
                        } else {
                            $error = 'บันทึกพิกัดไม่สำเร็จ: ' . mysqli_stmt_error($updateStmt);
                        }
                        mysqli_stmt_close($updateStmt);
                    }
                }
            }
        }
    }
}

/* =========================================================
   รายการผู้สูงอายุที่หมอมอบหมายให้แคร์กิฟเวอร์คนนี้
========================================================= */
$rows = [];

if ($error === '' && $caregiverId > 0) {
    $sql = "SELECT
                a.assignment_id,
                a.patient_id,
                a.caregiver_user_id,
                a.doctor_user_id,
                a.assigned_at,
                a.care_status,
                a.next_visit_date,
                p.Fullname,
                p.Age,
                p.Gender,
                p.Photo,
                p.Village_id,
                p.Latitude,
                p.Longitude,
                v.villagename,
                cg.username AS caregiver_username,
                cg.display_name AS caregiver_name,
                dr.username AS doctor_username,
                dr.display_name AS doctor_name
            FROM patient_caregiver_assignment a
            JOIN patient p
                ON p.Patient_id = a.patient_id
            LEFT JOIN village v
                ON v.village_id = p.Village_id
            LEFT JOIN users cg
                ON cg.user_id = a.caregiver_user_id
               AND cg.role = 'caregiver'
            LEFT JOIN users dr
                ON dr.user_id = a.doctor_user_id
               AND dr.role = 'doctor'
            WHERE a.caregiver_user_id = ?
              AND COALESCE(a.care_status,'กำลังดูแล') <> 'สิ้นสุดการดูแล'
            ORDER BY a.assigned_at DESC, p.Fullname ASC";

    $stmt = mysqli_prepare($conn, $sql);

    if (!$stmt) {
        $error = 'ไม่สามารถเตรียมรายการผู้สูงอายุได้: ' . mysqli_error($conn);
    } else {
        mysqli_stmt_bind_param($stmt, 'i', $caregiverId);
        mysqli_stmt_execute($stmt);
        $res = mysqli_stmt_get_result($stmt);

        if ($res) {
            while ($row = mysqli_fetch_assoc($res)) {
                $rows[] = $row;
            }
        } else {
            $error = 'ไม่สามารถดึงรายการผู้สูงอายุได้: ' . mysqli_stmt_error($stmt);
        }

        mysqli_stmt_close($stmt);
    }
}


/* =========================================================
   ประวัติผู้สูงอายุที่สิ้นสุดการดูแลแล้ว
========================================================= */
$completedRows = [];

if ($error === '' && $caregiverId > 0) {
    $sqlCompleted = "SELECT
                a.assignment_id,
                a.patient_id,
                a.caregiver_user_id,
                a.doctor_user_id,
                a.assigned_at,
                a.care_status,
                a.next_visit_date,
                a.care_end_reason,
                a.care_status_note,
                a.care_status_updated_at,
                p.Fullname,
                p.Age,
                p.Gender,
                p.Photo,
                p.Village_id,
                p.Latitude,
                p.Longitude,
                v.villagename,
                dr.username AS doctor_username,
                dr.display_name AS doctor_name
            FROM patient_caregiver_assignment a
            JOIN patient p
                ON p.Patient_id = a.patient_id
            LEFT JOIN village v
                ON v.village_id = p.Village_id
            LEFT JOIN users dr
                ON dr.user_id = a.doctor_user_id
               AND dr.role = 'doctor'
            WHERE a.caregiver_user_id = ?
              AND COALESCE(a.care_status,'') = 'สิ้นสุดการดูแล'
            ORDER BY COALESCE(a.care_status_updated_at, a.assigned_at) DESC, p.Fullname ASC";

    $stmtCompleted = mysqli_prepare($conn, $sqlCompleted);
    if ($stmtCompleted) {
        mysqli_stmt_bind_param($stmtCompleted, 'i', $caregiverId);
        mysqli_stmt_execute($stmtCompleted);
        $resCompleted = mysqli_stmt_get_result($stmtCompleted);
        if ($resCompleted) {
            while ($row = mysqli_fetch_assoc($resCompleted)) {
                $completedRows[] = $row;
            }
        }
        mysqli_stmt_close($stmtCompleted);
    }
}

function personLabel(array $row, string $codeKey, string $nameKey, string $fallback = '-'): string
{
    $code = trim((string)($row[$codeKey] ?? ''));
    $name = trim((string)($row[$nameKey] ?? ''));

    if ($code !== '' && $name !== '') {
        return $code . ' - ' . $name;
    }
    if ($code !== '') {
        return $code;
    }
    if ($name !== '') {
        return $name;
    }
    return $fallback;
}

function thaiDateOnly(?string $value): string
{
    $value = trim((string)$value);
    if ($value === '') return '-';
    $ts = strtotime($value);
    if (!$ts) return '-';
    return date('d/m/Y', $ts);
}

function thaiDateTime(?string $value): string
{
    if (!$value) return '-';

    $timestamp = strtotime($value);
    if (!$timestamp) return (string)$value;

    $year = (int)date('Y', $timestamp) + 543;
    return date('d/m/', $timestamp) . $year . date(' H:i', $timestamp) . ' น.';
}

$caregiverUsername = trim((string)($currentCaregiver['username'] ?? ''));
$caregiverDisplayName = trim((string)($currentCaregiver['display_name'] ?? ''));
$caregiverHeading = $caregiverUsername;
if ($caregiverUsername !== '' && $caregiverDisplayName !== '') {
    $caregiverHeading .= ' - ' . $caregiverDisplayName;
} elseif ($caregiverHeading === '') {
    $caregiverHeading = $caregiverDisplayName !== '' ? $caregiverDisplayName : 'บัญชีแคร์กิฟเวอร์';
}
?>
<!doctype html>
<html lang="th">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>ผู้สูงอายุที่อยู่ในความดูแล | <?= e(appName()) ?></title>
<?php renderPastelTheme(); ?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Thai:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<style>
    html,body{max-width:100%;overflow-x:hidden;}
    .patients-shell{
        background:#fff;
        border:1px solid #dbe9e7;
        border-radius:18px;
        box-shadow:0 5px 18px rgba(43,91,74,.045);
        overflow:hidden;
    }

    .patients-head{
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:18px;
        padding:18px 22px;
        border-bottom:1px solid #edf3f1;
    }

    .patients-title-wrap h2{
        margin:0;
        color:#203d33;
        font-size:20px;
        line-height:1.3;
        font-weight:800;
    }

    .patients-title-wrap p{
        margin:4px 0 0;
        color:#7b8a85;
        font-size:12px;
        line-height:1.5;
    }

    .patients-head-count{
        flex:0 0 auto;
        display:inline-flex;
        align-items:center;
        gap:6px;
        min-height:34px;
        padding:6px 11px;
        border:1px solid #d5e8e3;
        border-radius:10px;
        background:#f5fbf9;
        color:#60736c;
        font-size:12px;
        font-weight:700;
        white-space:nowrap;
    }

    .patients-head-count strong{
        color:#1f6659;
        font-size:16px;
    }

    .patients-toolbar{
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:14px;
        padding:16px 26px;
        background:#fbfdfc;
        border-bottom:1px solid #edf3f0;
    }

    .total-text{
        color:#667a72;
        font-size:12px;
        font-weight:600;
        white-space:nowrap;
    }

    .total-text strong{
        color:#245f49;
        font-size:15px;
    }


    .patients-search-outside{
        width:100%;
        margin:0 0 10px;
        padding:0;
        background:transparent;
        display:flex;
        justify-content:flex-start;
    }
    .completed-search-outside{margin:18px 0;}
    .patients-search-outside{align-items:center;gap:12px;flex-wrap:wrap;justify-content:flex-start;}
    .patients-month-control{display:inline-flex;align-items:center;gap:9px;flex-wrap:wrap;}
    .patients-month-control label{font-size:12px;font-weight:800;color:#466e68;white-space:nowrap;}
    .patients-month-control select{min-width:190px;height:40px;border:1px solid #dbe8e4;border-radius:10px;background:#fff;color:#285653;padding:0 12px;font:inherit;font-size:13px;cursor:pointer;outline:none;}
    .patients-month-control select:focus{border-color:#8fc8b4;box-shadow:0 0 0 3px rgba(119,188,163,.12);}
    .filtered-empty-row td{padding:24px 12px!important;text-align:center;color:#788e89;font-size:13px;background:#fff;}
    .patient-search-wrap{
        position:relative;
        width:min(500px,100%);
    }
    .patient-search-wrap::before{
        content:'⌕';
        position:absolute;
        left:14px;
        top:50%;
        transform:translateY(-52%);
        color:#7c9690;
        font-size:19px;
        line-height:1;
        pointer-events:none;
    }
    .patient-search{
        width:100%;
        height:40px;
        border:1px solid #dbe8e4;
        border-radius:10px;
        background:#fff;
        padding:0 14px 0 40px;
        color:#263f36;
        font:inherit;
        font-size:13px;
        outline:none;
        box-shadow:0 2px 8px rgba(43,91,74,.025);
        transition:.18s ease;
    }

    .patient-search:focus{
        border-color:#8fc8b4;
        box-shadow:0 0 0 3px rgba(119,188,163,.12);
    }

    .patients-table-wrap{
        width:100%;
        overflow-x:visible;
    }

    .table-pagination{
        display:flex;
        align-items:center;
        justify-content:center;
        gap:6px;
        padding:14px 18px 16px;
        border-top:1px solid #edf3f0;
        background:#fff;
    }
    .table-pagination[hidden]{display:none;}
    .page-btn{
        min-width:34px;
        height:34px;
        padding:0 10px;
        border:1px solid #d8e7e3;
        border-radius:8px;
        background:#fff;
        color:#3f6259;
        font:inherit;
        font-size:13px;
        font-weight:700;
        cursor:pointer;
        transition:.16s ease;
    }
    .page-btn:hover:not(:disabled){
        border-color:#9fcfc0;
        background:#f3faf8;
    }
    .page-btn.active{
        background:#dff3ee;
        border-color:#9bcfbe;
        color:#1f6659;
    }
    .page-btn:disabled{
        opacity:.38;
        cursor:default;
    }
    .page-ellipsis{
        min-width:24px;
        text-align:center;
        color:#789088;
        font-weight:700;
    }

    .patients-table{
        width:100%;
        min-width:0;
        border-collapse:separate;
        border-spacing:0;
        table-layout:fixed;
    }

    .patients-table th{
        padding:12px 10px;
        background:#f1f8f6;
        color:#3a6256;
        border-bottom:1px solid #dceae6;
        text-align:left;
        font-size:12px;
        font-weight:800;
        white-space:normal;
        line-height:1.35;
        word-break:break-word;
    }

    .patients-table th.center,
    .patients-table td.center{
        text-align:center;
    }

    .patients-table td{
        padding:12px 10px;
        background:#fff;
        border-bottom:1px solid #edf2ef;
        color:#263b33;
        font-size:13px;
        vertical-align:middle;
        word-break:break-word;
    }

    .patients-table tbody tr:last-child td{
        border-bottom:0;
    }

    .patients-table tbody tr:hover td{
        background:#fbfefc;
    }

    .patient-name{
        display:block;
        color:#203a31;
        font-size:14px;
        font-weight:800;
        line-height:1.42;
    }

    .patient-meta{
        display:block;
        margin-top:4px;
        color:#82918b;
        font-size:11px;
        font-weight:500;
        line-height:1.4;
    }

    .patient-photo-cell,
    .patient-photo-head{
        width:78px;
        text-align:center;
    }

    .patient-photo-box{
        width:54px;
        height:54px;
        margin:0 auto;
        border-radius:18px;
        border:1px solid #d8e8e2;
        overflow:hidden;
        background:linear-gradient(135deg,#eef9fb 0%,#f3faf8 100%);
        display:flex;
        align-items:center;
        justify-content:center;
        color:#738780;
        font-size:11px;
        font-weight:700;
        text-align:center;
        line-height:1.35;
    }

    .patient-photo-box img{
        width:100%;
        height:100%;
        object-fit:cover;
        display:block;
    }

    .patient-photo-action{
        text-align:center;
        vertical-align:middle;
    }

    .patient-photo-form{
        margin:0 auto;
        width:100%;
        display:flex;
        justify-content:center;
        align-items:center;
    }

    .patient-photo-input{
        position:absolute;
        width:1px;
        height:1px;
        opacity:0;
        pointer-events:none;
    }

    .patient-photo-btn{
        display:inline-flex;
        margin:0 auto;
        align-items:center;
        justify-content:center;
        width:102px;
        min-width:102px;
        height:38px;
        min-height:38px;
        padding:8px 10px;
        border:1px solid #bfe2dc;
        border-radius:11px;
        background:#eef9f7;
        color:#24665f;
        font:inherit;
        font-size:12px;
        font-weight:800;
        cursor:pointer;
        transition:.18s ease;
        white-space:nowrap;
    }

    .patient-photo-btn:hover{
        background:#ddf3ef;
        border-color:#9fd3ca;
        transform:translateY(-1px);
    }

    .patient-photo-btn.has-photo{
        background:#f4f8fb;
        border-color:#d3e1e8;
        color:#3f6777;
    }

    .person-stack{
        display:flex;
        flex-direction:column;
        gap:4px;
        line-height:1.4;
    }

    .person-code{
        color:#265d49;
        font-size:12px;
        font-weight:800;
    }

    .person-name{
        color:#5e7169;
        font-size:11px;
        line-height:1.4;
    }

    .date-text{
        color:#42574f;
        font-size:12px;
        white-space:normal;
        line-height:1.45;
    }

    .status-form{
        margin:0;
        display:flex;
        justify-content:center;
    }

    .status-select{
        min-width:132px;
        height:38px;
        padding:0 34px 0 13px;
        border-radius:999px;
        border:1px solid #c8e3d6;
        background:#eef8f3;
        color:#2b624d;
        font:inherit;
        font-size:12px;
        font-weight:800;
        outline:none;
        cursor:pointer;
        transition:.18s ease;
    }

    .status-select:hover,
    .status-select:focus{
        border-color:#8fc8b4;
        box-shadow:0 0 0 3px rgba(119,188,163,.12);
    }

    .status-select[data-status="พักการดูแล"]{
        background:#fff8e7;
        border-color:#ead7a4;
        color:#7b6221;
    }

    .status-select[data-status="สิ้นสุดการดูแล"]{
        background:#f4f5f5;
        color:#68736e;
    }

    .status-note{
        display:block;
        margin-top:5px;
        color:#8a9791;
        font-size:11px;
        text-align:center;
    }

    .empty-state{
        padding:54px 20px!important;
        text-align:center!important;
        color:#7f8f88!important;
        font-size:14px!important;
    }

    .no-doctor{
        color:#8b7a57;
        font-size:12px;
        font-weight:700;
    }

    @media (max-width: 760px){
        .patients-head,
        .patients-toolbar{
            align-items:flex-start;
            flex-direction:column;
            padding-left:18px;
            padding-right:18px;
        }

        .patients-search-outside{justify-content:stretch;}
        .patient-search-wrap{width:100%;}
        .patient-search{width:100%;}
        .patients-head-count{align-self:flex-start;}
    }

.patient-map-link{display:inline-flex;align-items:center;justify-content:center;min-height:36px;padding:8px 11px;border-radius:10px;border:1px solid #cfe4ea;background:#eef7fb;color:#39708f;text-decoration:none;font-size:11px;font-weight:800;white-space:nowrap}.patient-map-link:hover{background:#e2f2f8}.patient-map-link.disabled{background:#f5f7f7;border-color:#e3eaea;color:#9aa8a5;pointer-events:none}
.patient-location-actions{display:flex;align-items:center;justify-content:center;gap:7px;flex-wrap:wrap;width:100%;text-align:center}.patient-coordinate-btn{display:inline-flex;align-items:center;justify-content:center;width:102px;min-width:102px;height:38px;min-height:38px;padding:8px 10px;border-radius:11px;border:1px solid #bfe2dc;background:#eef9f7;color:#24665f;font:inherit;font-size:12px;font-weight:800;cursor:pointer;white-space:nowrap;transition:.18s ease}.patient-coordinate-btn:hover{background:#ddf3ef;border-color:#9fd3ca;transform:translateY(-1px)}.coordinate-modal{position:fixed;inset:0;z-index:5000;display:none;align-items:center;justify-content:center;padding:24px;background:rgba(35,65,58,.34)}.coordinate-modal.is-open{display:flex}.coordinate-dialog{width:min(980px,100%);max-height:calc(100vh - 48px);overflow:auto;background:#fff;border:1px solid #d8e8e4;border-radius:24px;box-shadow:0 28px 70px rgba(36,108,115,.18)}.coordinate-head{display:flex;align-items:flex-start;justify-content:space-between;gap:14px;padding:20px 22px;border-bottom:1px solid #e5efec}.coordinate-head h3{margin:0;color:#203d33;font-size:20px}.coordinate-head p{margin:5px 0 0;color:#7b8a85;font-size:12px;line-height:1.55}.coordinate-close{width:38px;height:38px;border:1px solid #d4e6e1;border-radius:50%;background:#fff;color:#41665d;font-size:22px;cursor:pointer}.coordinate-body{padding:20px 22px}.coordinate-map-actions{display:flex;justify-content:flex-end;gap:10px;flex-wrap:wrap;margin-bottom:12px}.coordinate-action-btn{min-height:40px;padding:9px 14px;border:1px solid #cfe5e2;border-radius:12px;background:#fff;color:#2d6669;font:inherit;font-size:12px;font-weight:800;cursor:pointer}.coordinate-action-btn.primary{background:#61c2c6;border-color:#61c2c6;color:#fff}#caregiverPatientMap{width:100%;height:320px;border:1px solid #d7e8e5;border-radius:16px;overflow:hidden;background:#eef7f6}#caregiverPatientMap iframe{display:block;width:100%;height:100%;border:0}.coordinate-section-label{margin:14px 0 0;font-size:13px;font-weight:900;color:#2f625f}.coordinate-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:14px}.coordinate-field{display:grid;gap:7px}.coordinate-field label{font-size:12px;font-weight:800;color:#365f5d}.coordinate-field input{width:100%;height:44px;padding:0 13px;border:1px solid #cfe4e1;border-radius:12px;background:#fff;color:#244846;font:inherit;font-size:13px;outline:none}.coordinate-field input:focus{border-color:#74c6c6;box-shadow:0 0 0 3px rgba(88,191,192,.12)}.coordinate-footer{display:flex;justify-content:flex-end;gap:10px;padding:0 22px 22px}.coordinate-save{min-height:42px;padding:10px 18px;border:0;border-radius:12px;background:linear-gradient(135deg,#67c8c3,#4fb4b9);color:#fff;font:inherit;font-weight:900;cursor:pointer}.coordinate-cancel{min-height:42px;padding:10px 18px;border:1px solid #d7e6e3;border-radius:12px;background:#fff;color:#466966;font:inherit;font-weight:800;cursor:pointer}@media(max-width:700px){.coordinate-grid{grid-template-columns:1fr}#caregiverPatientMap{height:250px}.coordinate-modal{padding:10px}}

.patient-manage-actions{display:flex;align-items:center;justify-content:center;gap:8px;flex-wrap:wrap}.patient-manage-actions form{margin:0}.patient-edit-btn,.patient-delete-btn{display:inline-flex;align-items:center;justify-content:center;min-width:68px;height:38px;padding:8px 13px;border-radius:11px;font:inherit;font-size:12px;font-weight:800;text-decoration:none;cursor:pointer;transition:.18s ease}.patient-edit-btn{border:1px solid #e7d8a8;background:#fff8e7;color:#7c6423}.patient-edit-btn:hover{background:#fdf0c8;border-color:#dcc36f;transform:translateY(-1px)}.patient-delete-btn{border:1px solid #efc9c9;background:#fff1f1;color:#a34d4d}.patient-delete-btn:hover{background:#ffe3e3;border-color:#e6aaaa;transform:translateY(-1px)}
.completed-shell{margin-top:0}.completed-title-note{margin-top:4px;color:#7c8c86;font-size:12px}.completed-count{font-weight:800;color:#2b665f}.completed-table th{background:#f4f7f6!important}.completed-badge{display:inline-flex;align-items:center;padding:5px 9px;border-radius:8px;border:0;background:#f7f8f8;color:#61716c;font-size:11px;font-weight:800}.completed-reason{display:block;margin-top:4px;color:#6a7c76;font-size:11px;line-height:1.4}.completed-note{display:block;margin-top:2px;color:#8a9894;font-size:10.5px}.completed-empty{padding:24px;text-align:center;color:#7a8b85}.date-ended{font-weight:700;color:#526b64}

/* FINAL OVERRIDE: care status should look like plain text */
.status-select,
.status-select[data-status="พักการดูแล"],
.status-select[data-status="สิ้นสุดการดูแล"],
.completed-badge{
    display:inline!important;
    min-width:0!important;
    width:auto!important;
    height:auto!important;
    padding:0!important;
    margin:0!important;
    border:0!important;
    outline:0!important;
    border-radius:0!important;
    background:transparent!important;
    box-shadow:none!important;
    appearance:none!important;
    -webkit-appearance:none!important;
    -moz-appearance:none!important;
    text-align:center!important;
    text-align-last:center!important;
}
.status-select{color:#2b624d!important;font-size:13px!important;font-weight:800!important;cursor:pointer!important}
.status-select[data-status="พักการดูแล"]{color:#7b6221!important}
.status-select[data-status="สิ้นสุดการดูแล"]{color:#a15252!important}
.completed-badge{color:#61716c!important;font-size:13px!important;font-weight:800!important}
.status-select:hover,.status-select:focus{box-shadow:none!important}


/* Month + search controls match the visit-report layout while retaining independent filters. */
.patients-filter-bar{display:flex;justify-content:flex-end;align-items:center;margin:0 0 14px;min-height:64px}
.patients-month-control{display:flex;align-items:center;gap:12px;position:relative}
.patients-month-control label{display:none}
.month-select-shell{position:relative;display:block;min-width:304px;width:304px}
.month-select-hidden{position:absolute;opacity:0;pointer-events:none;width:1px;height:1px}
.month-picker-trigger{display:flex;align-items:center;justify-content:space-between;gap:16px;width:100%;height:72px;padding:0 24px;border:1px solid #6fc7ca;border-radius:26px;background:#fff;color:#21484d;font:inherit;font-size:18px;font-weight:900;cursor:pointer;box-shadow:none;transition:.18s ease}
.month-picker-trigger:hover,.month-picker-trigger:focus-visible{background:#fbffff;box-shadow:0 0 0 3px rgba(111,199,202,.12);outline:none}
.month-picker-label{display:inline-flex;align-items:center;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.month-calendar-icon{display:inline-flex;align-items:center;justify-content:center;width:24px;height:24px;color:#24565d;line-height:1;flex:0 0 24px}.month-calendar-icon svg{display:block;width:24px;height:24px;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
.month-picker-dropdown{position:absolute;top:calc(100% + 12px);right:0;left:auto;z-index:50;width:392px;max-width:min(92vw,392px);padding:18px 18px 16px;border:1px solid #cfe1df;border-radius:24px;background:#fff;box-shadow:0 22px 44px rgba(33,72,77,.14);display:none}
.month-picker-dropdown.is-open{display:block}
.month-picker-head{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:14px}
.month-picker-year{font-size:18px;font-weight:900;color:#21484d}
.month-picker-nav{display:flex;align-items:center;gap:10px}
.month-nav-btn{display:inline-flex;align-items:center;justify-content:center;min-width:94px;height:40px;border:1px solid #d7e6e3;border-radius:14px;background:#f7fbfb;color:#6c8380;font:inherit;font-size:13px;font-weight:800;cursor:pointer;transition:.15s ease}
.month-nav-btn:hover:not(:disabled){background:#eff7f6;color:#315a5d}.month-nav-btn:disabled{opacity:.42;cursor:not-allowed}
.month-picker-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;padding:14px 0;border-top:1px solid #ebf1f0;border-bottom:1px solid #ebf1f0}
.month-chip{display:flex;align-items:center;justify-content:center;height:52px;border:1px solid transparent;border-radius:16px;background:transparent;color:#2b5558;font:inherit;font-size:14px;font-weight:900;cursor:pointer;transition:.15s ease}
.month-chip:hover:not(:disabled){background:#f3fbfa}
.month-chip.active{background:#485359;color:#fff}
.month-chip:disabled{color:#bac8c6;cursor:not-allowed}
.month-picker-footer{display:flex;justify-content:flex-end;padding-top:12px}
.month-picker-today{border:0;background:transparent;color:#1f7f87;font:inherit;font-size:14px;font-weight:900;cursor:pointer;padding:6px 0}
.month-picker-today:hover{text-decoration:underline}
.patients-search-outside{display:flex;justify-content:flex-start;align-items:stretch;flex-wrap:wrap;gap:12px;margin:0 0 18px}
.patients-search-outside.completed-search-outside{margin-top:24px;margin-bottom:18px}
.patients-search-outside .patient-search-wrap{width:min(720px,calc(100% - 110px));flex:0 1 720px}
.patients-search-outside .patient-search{height:48px;border-radius:14px;font-size:14px}
.patients-search-button{min-width:90px;min-height:48px;border:0;border-radius:14px;background:#46acae;color:#fff;font:inherit;font-size:14px;font-weight:800;cursor:pointer;transition:background .15s ease}
.patients-search-button:hover,.patients-search-button:focus-visible{background:#34989a}
.patients-shell{border-radius:24px;box-shadow:0 9px 28px rgba(43,91,74,.045)}
.patients-head{padding:20px 24px}
.patients-head-count{min-height:39px;border-radius:999px;padding:6px 13px}
.completed-filter-bar{margin-top:22px}
    .patients-table .person-stack,.patients-table .completed-reason,.patients-table .completed-note{overflow-wrap:anywhere;}
    .patients-table .patient-map-link{font-size:11px;padding:7px 10px;}
    .patients-table td.center strong{font-size:14px;}

@media(max-width:760px){
  .patients-filter-bar{min-height:auto;justify-content:stretch}
  .patients-month-control{width:100%;justify-content:space-between;flex-wrap:wrap}
  .month-select-shell{min-width:0;width:100%;max-width:420px}.month-picker-dropdown{right:0;left:0;width:100%;max-width:none}
  .patients-search-outside{flex-direction:row;align-items:stretch;gap:8px}
  .patients-search-outside .patient-search-wrap{width:auto;flex:1 1 180px;min-width:0}
  .patients-search-button{min-width:80px}
}
.coordinate-google-head{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:4px 0 10px}.coordinate-google-head strong{display:block;color:#244f48;font-size:14px}.coordinate-google-head span{display:block;margin-top:3px;color:#738983;font-size:12px}.coordinate-google-head a{display:inline-flex;align-items:center;justify-content:center;min-height:38px;padding:8px 13px;border:1px solid #bcded9;border-radius:10px;background:#fff;color:#2f6964;text-decoration:none;font-size:12px;font-weight:800;white-space:nowrap}.coordinate-home-title{margin-top:14px!important;padding-top:14px;border-top:1px solid #dcebe8}@media(max-width:760px){.coordinate-google-head{align-items:stretch;flex-direction:column}.coordinate-google-head a{width:100%}}
</style>
</head>
<body class="role-page">
<?php renderSidebar(); ?>

<main class="main">
    <?php renderUserTopbar(); ?>

    <?php if ($error): ?>
        <div class="alert alert-error"><?= e($error) ?></div>
    <?php endif; ?>
    <?php if ($message): ?>
        <div class="alert alert-ok"><?= e($message) ?></div>
    <?php endif; ?>

    <div class="patients-filter-bar">
        <div class="patients-month-control">
            <label for="patientMonth">เดือนที่เริ่มมอบหมาย</label>
            <div class="month-select-shell" data-month-picker-shell>
                <select id="patientMonth" class="month-select-hidden" aria-label="เลือกเดือนที่เริ่มมอบหมาย">
                    <option value="">ทุกเดือน</option>
                </select>
                <button type="button" class="month-picker-trigger" id="patientMonthTrigger" aria-haspopup="dialog" aria-expanded="false" aria-controls="patientMonthDropdown">
                    <span class="month-picker-label" id="patientMonthLabel">ทุกเดือน</span>
                    <span class="month-calendar-icon" aria-hidden="true"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3.5" y="4.5" width="17" height="16" rx="2.5"></rect><line x1="8" y1="2.8" x2="8" y2="6.2"></line><line x1="16" y1="2.8" x2="16" y2="6.2"></line><line x1="3.5" y1="8.5" x2="20.5" y2="8.5"></line></svg></span>
                </button>
                <div class="month-picker-dropdown" id="patientMonthDropdown" hidden>
                    <div class="month-picker-head">
                        <div class="month-picker-year" id="patientMonthYear">-</div>
                        <div class="month-picker-nav">
                            <button type="button" class="month-nav-btn" id="patientMonthPrev">ปีก่อนหน้า</button>
                            <button type="button" class="month-nav-btn" id="patientMonthNext">ปีถัดไป</button>
                        </div>
                    </div>
                    <div class="month-picker-grid" id="patientMonthGrid"></div>
                    <div class="month-picker-footer">
                        <button type="button" class="month-picker-today" id="patientMonthCurrent">เดือนปัจจุบัน</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="patients-search-outside">
        <div class="patient-search-wrap">
            <input
                type="search"
                id="patientSearch"
                class="patient-search"
                placeholder="ค้นหาผู้สูงอายุ หมอ หรือหมู่บ้าน"
                autocomplete="off"
            >
        </div>
        <button class="patients-search-button" id="patientSearchButton" type="button">ค้นหา</button>
    </div>

    <section class="patients-shell">
        <div class="patients-head">
            <div class="patients-title-wrap">
                <h2>ผู้สูงอายุที่อยู่ในความดูแล</h2>
            </div>
            <div class="patients-head-count">ทั้งหมด <strong id="visiblePatientCount"><?= count($rows) ?></strong> คน</div>
        </div>

        <div class="patients-table-wrap">
            <table class="patients-table" id="patientsTable">
                <colgroup>
                    <col style="width:7%">
                    <col style="width:19%">
                    <col style="width:6%">
                    <col style="width:16%">
                    <col style="width:12%">
                    <col style="width:12%">
                    <col style="width:9%">
                    <col style="width:9%">
                    <col style="width:10%">
                </colgroup>
                <thead>
                    <tr>
                        <th class="patient-photo-head">รูปภาพ</th>
                        <th>ผู้สูงอายุในความดูแล</th>
                        <th class="center">อายุ</th>
                        <th>หมอผู้มอบหมาย</th>
                        <th class="center">วันที่เริ่มมอบหมาย</th>
                        <th class="center">กำหนดวันที่เข้าเยี่ยม</th>
                        <th class="center">ตำแหน่ง</th>
                        <th class="center">เพิ่มรูปภาพ</th>
                        <th class="center">การดำเนินการ</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (!$rows): ?>
                    <tr class="empty-row">
                        <td colspan="9" class="empty-state">ยังไม่มีผู้สูงอายุที่หมอมอบหมายให้อยู่ในความดูแลของคุณ</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($rows as $r): ?>
                        <?php
                            $doctorUsername = trim((string)($r['doctor_username'] ?? ''));
                            $doctorName = trim((string)($r['doctor_name'] ?? ''));
                            $caregiverRowUsername = trim((string)($r['caregiver_username'] ?? ''));
                            $caregiverRowName = trim((string)($r['caregiver_name'] ?? ''));
                            $villageName = trim((string)($r['villagename'] ?? ''));
                            $searchText = implode(' ', [
                                (string)($r['Fullname'] ?? ''),
                                $doctorUsername,
                                $doctorName,
                                $caregiverRowUsername,
                                $caregiverRowName,
                                $villageName,
                                (string)($r['care_status'] ?? 'กำลังดูแล'),
                            ]);
                        ?>
                        <tr class="patient-row" data-month="<?= e(substr((string)($r['assigned_at'] ?? ''), 0, 7)) ?>" data-search="<?= e(mb_strtolower($searchText, 'UTF-8')) ?>">
                            <td class="patient-photo-cell">
                                <?php $patientPhotoUrl = thonglangUploadedImageUrl($r['Photo'] ?? ''); ?>
                                <div class="patient-photo-box">
                                    <?php if ($patientPhotoUrl !== ''): ?>
                                        <img src="<?= e($patientPhotoUrl) ?>" alt="รูปผู้สูงอายุ">
                                    <?php else: ?>
                                        <span>ไม่มีรูป</span>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td>
                                <span class="patient-name"><?= e($r['Fullname'] ?? '-') ?></span>
                                <span class="patient-meta">
                                    <?= $villageName !== '' ? e($villageName) : 'ไม่ระบุหมู่บ้าน' ?>
                                </span>
                            </td>
                            <td class="center"><strong><?= (int)($r['Age'] ?? 0) ?></strong> ปี</td>
                            <td>
                                <?php if ($doctorUsername !== '' || $doctorName !== ''): ?>
                                    <div class="person-stack">
                                        <?php if ($doctorUsername !== ''): ?><span class="person-code"><?= e($doctorUsername) ?></span><?php endif; ?>
                                        <?php if ($doctorName !== ''): ?><span class="person-name"><?= e($doctorName) ?></span><?php endif; ?>
                                    </div>
                                <?php else: ?>
                                    <span class="no-doctor">ยังไม่ระบุหมอผู้มอบหมาย</span>
                                <?php endif; ?>
                            </td>
                            <td class="center"><span class="date-text"><?= e(thaiDateTime($r['assigned_at'] ?? null)) ?></span></td>
                            <td class="center"><span class="date-text"><?= e(thaiDateOnly($r['next_visit_date'] ?? null)) ?></span></td>
                            <td class="center">
                                <?php
                                    $patientLat = trim((string)($r['Latitude'] ?? ''));
                                    $patientLng = trim((string)($r['Longitude'] ?? ''));
                                ?>
                                <div class="patient-location-actions">
                                    <?php if ($patientLat !== '' && $patientLng !== ''): ?>
                                        <a class="patient-map-link" target="_blank" rel="noopener" href="https://www.google.com/maps/dir/?api=1&destination=<?= rawurlencode($patientLat . ',' . $patientLng) ?>">เปิดแผนที่</a>
                                    <?php endif; ?>
                                    <button
                                        type="button"
                                        class="patient-coordinate-btn"
                                        data-coordinate-button
                                        data-patient-id="<?= (int)($r['patient_id'] ?? 0) ?>"
                                        data-patient-name="<?= e($r['Fullname'] ?? '-') ?>"
                                        data-latitude="<?= e($patientLat) ?>"
                                        data-longitude="<?= e($patientLng) ?>"
                                    ><?= ($patientLat !== '' && $patientLng !== '') ? 'แก้ไขพิกัด' : '+ เพิ่มพิกัด' ?></button>
                                </div>
                            </td>
                            <td class="patient-photo-action">
                                <form method="post" enctype="multipart/form-data" class="patient-photo-form">
                                    <input type="hidden" name="action" value="upload_patient_photo">
                                    <input type="hidden" name="patient_id" value="<?= (int)($r['patient_id'] ?? 0) ?>">
                                    <input
                                        type="file"
                                        name="patient_photo"
                                        class="patient-photo-input"
                                        id="patientPhoto<?= (int)($r['patient_id'] ?? 0) ?>"
                                        accept="image/jpeg,image/png,image/gif,image/webp"
                                        onchange="this.form.submit()"
                                    >
                                    <label
                                        for="patientPhoto<?= (int)($r['patient_id'] ?? 0) ?>"
                                        class="patient-photo-btn <?= thonglangUploadedImageUrl($r['Photo'] ?? '') !== '' ? 'has-photo' : '' ?>"
                                    >
                                        <?= thonglangUploadedImageUrl($r['Photo'] ?? '') !== '' ? 'เปลี่ยนรูป' : '+ เพิ่มรูปภาพ' ?>
                                    </label>
                                </form>
                            </td>
                            <td class="center">
                                <div class="patient-manage-actions">
                                    <a class="patient-edit-btn" href="caregiver_patient_edit.php?patient_id=<?= (int)($r['patient_id'] ?? 0) ?>">แก้ไข</a>
                                    <form method="post" onsubmit="return confirm('ต้องการลบผู้สูงอายุรายนี้ออกจากรายการในความดูแลหรือไม่?');">
                                        <input type="hidden" name="action" value="remove_patient_assignment">
                                        <input type="hidden" name="patient_id" value="<?= (int)($r['patient_id'] ?? 0) ?>">
                                        <button type="submit" class="patient-delete-btn">ลบ</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="table-pagination" id="patientsPagination" hidden></div>

    </section>

    <div class="patients-search-outside completed-search-outside">
        <div class="patient-search-wrap">
            <input
                type="search"
                id="completedPatientSearch"
                class="patient-search"
                placeholder="ค้นหาประวัติผู้สูงอายุ หมอ หรือหมู่บ้าน"
                autocomplete="off"
            >
        </div>
        <button class="patients-search-button" id="completedPatientSearchButton" type="button">ค้นหา</button>
    </div>

    <section class="patients-shell completed-shell">
        <div class="patients-head">
            <div class="patients-title-wrap">
                <h2>ผู้สูงอายุที่สิ้นสุดการดูแลแล้ว</h2>
            </div>
            <div class="patients-head-count">ทั้งหมด <strong class="completed-count"><?= count($completedRows) ?></strong> คน</div>
        </div>

        <div class="patients-table-wrap">
            <table class="patients-table completed-table" id="completedPatientsTable">
                <colgroup>
                    <col style="width:8%">
                    <col style="width:21%">
                    <col style="width:7%">
                    <col style="width:17%">
                    <col style="width:14%">
                    <col style="width:33%">
                </colgroup>
                <thead>
                    <tr>
                        <th class="patient-photo-head">รูปภาพ</th>
                        <th>ผู้สูงอายุ</th>
                        <th class="center">อายุ</th>
                        <th>หมอผู้มอบหมาย</th>
                        <th class="center">วันที่สิ้นสุดการดูแล</th>
                        <th>รายละเอียด</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (!$completedRows): ?>
                    <tr class="empty-row">
                        <td colspan="6" class="completed-empty">ยังไม่มีรายชื่อผู้สูงอายุที่สิ้นสุดการดูแล</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($completedRows as $r): ?>
                        <?php
                            $doctorUsername = trim((string)($r['doctor_username'] ?? ''));
                            $doctorName = trim((string)($r['doctor_name'] ?? ''));
                            $villageName = trim((string)($r['villagename'] ?? ''));
                            $endReason = trim((string)($r['care_end_reason'] ?? ''));
                            $statusNote = trim((string)($r['care_status_note'] ?? ''));
                            $completedSearchText = implode(' ', [
                                (string)($r['Fullname'] ?? ''),
                                $doctorUsername,
                                $doctorName,
                                $villageName,
                                $endReason,
                                $statusNote,
                            ]);
                        ?>
                        <tr class="completed-patient-row" data-month="<?= e(substr((string)(($r['care_status_updated_at'] ?: $r['assigned_at']) ?? ''), 0, 7)) ?>" data-search="<?= e(mb_strtolower($completedSearchText, 'UTF-8')) ?>">
                            <td class="patient-photo-cell">
                                <?php $patientPhotoUrl = thonglangUploadedImageUrl($r['Photo'] ?? ''); ?>
                                <div class="patient-photo-box">
                                    <?php if ($patientPhotoUrl !== ''): ?>
                                        <img src="<?= e($patientPhotoUrl) ?>" alt="รูปผู้สูงอายุ">
                                    <?php else: ?>
                                        <span>ไม่มีรูป</span>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td>
                                <span class="patient-name"><?= e($r['Fullname'] ?? '-') ?></span>
                                <span class="patient-meta"><?= $villageName !== '' ? e($villageName) : 'ไม่ระบุหมู่บ้าน' ?></span>
                            </td>
                            <td class="center"><strong><?= (int)($r['Age'] ?? 0) ?></strong> ปี</td>
                            <td>
                                <?php if ($doctorUsername !== '' || $doctorName !== ''): ?>
                                    <div class="person-stack">
                                        <?php if ($doctorUsername !== ''): ?><span class="person-code"><?= e($doctorUsername) ?></span><?php endif; ?>
                                        <?php if ($doctorName !== ''): ?><span class="person-name"><?= e($doctorName) ?></span><?php endif; ?>
                                    </div>
                                <?php else: ?>
                                    <span class="no-doctor">ไม่ระบุ</span>
                                <?php endif; ?>
                            </td>
                            <td class="center"><span class="date-text date-ended"><?= e(thaiDateTime($r['care_status_updated_at'] ?? $r['assigned_at'] ?? null)) ?></span></td>
                            <td>
                                <span class="completed-badge">สิ้นสุดการดูแล</span>
                                <?php if ($endReason !== ''): ?><span class="completed-reason">เหตุผล: <?= e($endReason) ?></span><?php endif; ?>
                                <?php if ($statusNote !== ''): ?><span class="completed-note">หมายเหตุ: <?= e($statusNote) ?></span><?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="table-pagination" id="completedPatientsPagination" hidden></div>
    </section>

    <div class="coordinate-modal" id="coordinateModal" aria-hidden="true">
        <form method="post" class="coordinate-dialog" id="coordinateForm">
            <input type="hidden" name="action" value="update_patient_coordinates">
            <input type="hidden" name="patient_id" id="coordinatePatientId" value="">
            <div class="coordinate-head">
                <div>
                    <h3>เพิ่มพิกัดบ้านผู้สูงอายุ</h3>
                    <p id="coordinatePatientName">กำหนดตำแหน่งบ้านของผู้สูงอายุ</p>
                </div>
                <button type="button" class="coordinate-close" id="coordinateClose" aria-label="ปิด">×</button>
            </div>
            <div class="coordinate-body">
                <div class="coordinate-map-actions">
                    <button type="button" class="coordinate-action-btn primary" id="coordinateUseCurrent">ใช้ตำแหน่งปัจจุบัน</button>
                    <button type="button" class="coordinate-action-btn" id="coordinateClear">ล้างตำแหน่ง</button>
                </div>
                <div class="coordinate-google-head">
                    <div>
                        <strong>Google Maps ตำบลทองหลาง</strong>
                        <span>แผนที่อ้างอิงตำบลทองหลาง อำเภอจักราช จังหวัดนครราชสีมา</span>
                    </div>
                    <a href="https://www.google.com/maps/place/Thong+Lang,+Chakkarat+District,+Nakhon+Ratchasima+30230/@15.0510075,102.3122145,13z/data=!3m1!4b1!4m6!3m5!1s0x311940b16b6ffbbb:0x40469cfc8dee620!8m2!3d15.0547605!4d102.3578423!16s%2Fg%2F11t1sfh_8l?authuser=0&entry=ttu" target="_blank" rel="noopener">เปิดใน Google Maps</a>
                </div>
                <div id="caregiverPatientMap" aria-label="Google Maps ตำบลทองหลาง"><iframe id="caregiverGoogleMapFrame" title="Google Maps ตำบลทองหลาง" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen></iframe></div>
                <div class="coordinate-section-label coordinate-home-title">พิกัดบ้าน</div>
                <div class="coordinate-grid">
                    <div class="coordinate-field">
                        <label for="coordinateLatitude">ละติจูด</label>
                        <input type="text" inputmode="decimal" name="latitude" id="coordinateLatitude" placeholder="เช่น 14.9799000" required>
                    </div>
                    <div class="coordinate-field">
                        <label for="coordinateLongitude">ลองจิจูด</label>
                        <input type="text" inputmode="decimal" name="longitude" id="coordinateLongitude" placeholder="เช่น 102.3157000" required>
                    </div>
                </div>
            </div>
            <div class="coordinate-footer">
                <button type="button" class="coordinate-cancel" id="coordinateCancel">ยกเลิก</button>
                <button type="submit" class="coordinate-save">บันทึกพิกัด</button>
            </div>
        </form>
    </div>
</main>

<script>
(function () {
    const PAGE_SIZE = 10;
    const monthNames = ['มกราคม','กุมภาพันธ์','มีนาคม','เมษายน','พฤษภาคม','มิถุนายน',
                        'กรกฎาคม','สิงหาคม','กันยายน','ตุลาคม','พฤศจิกายน','ธันวาคม'];

    function initCustomMonthPicker(config) {
        const select = document.getElementById(config.selectId);
        const trigger = document.getElementById(config.triggerId);
        const label = document.getElementById(config.labelId);
        const dropdown = document.getElementById(config.dropdownId);
        const yearEl = document.getElementById(config.yearId);
        const grid = document.getElementById(config.gridId);
        const prevBtn = document.getElementById(config.prevId);
        const nextBtn = document.getElementById(config.nextId);
        const currentBtn = document.getElementById(config.currentId);
        if (!select || !trigger || !label || !dropdown || !yearEl || !grid || !prevBtn || !nextBtn || !currentBtn) return;

        const monthShort = ['ม.ค.','ก.พ.','มี.ค.','เม.ย.','พ.ค.','มิ.ย.','ก.ค.','ส.ค.','ก.ย.','ต.ค.','พ.ย.','ธ.ค.'];
        const options = Array.from(select.options).filter(opt => /^\d{4}-(0[1-9]|1[0-2])$/.test(opt.value));
        if (!options.length) {
            trigger.disabled = true;
            label.textContent = 'ไม่มีข้อมูล';
            return;
        }
        const monthMap = new Map(options.map(opt => [opt.value, opt.textContent]));
        const years = Array.from(new Set(options.map(opt => Number(opt.value.slice(0,4))))).sort((a,b)=>a-b);
        const latestValue = options[0].value;
        if (!select.value || !monthMap.has(select.value)) select.value = latestValue;
        let viewYear = Number(select.value.slice(0,4));

        function syncLabel() {
            label.textContent = monthMap.get(select.value) || 'ทุกเดือน';
        }
        function closeDropdown() {
            dropdown.hidden = true;
            dropdown.classList.remove('is-open');
            trigger.setAttribute('aria-expanded', 'false');
        }
        function openDropdown() {
            render();
            dropdown.hidden = false;
            dropdown.classList.add('is-open');
            trigger.setAttribute('aria-expanded', 'true');
        }
        function render() {
            yearEl.textContent = String(viewYear + 543);
            prevBtn.disabled = viewYear <= years[0];
            nextBtn.disabled = viewYear >= years[years.length - 1];
            grid.replaceChildren();
            monthShort.forEach((name, index) => {
                const monthNum = String(index + 1).padStart(2, '0');
                const value = viewYear + '-' + monthNum;
                const btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'month-chip';
                btn.textContent = name;
                if (!monthMap.has(value)) {
                    btn.disabled = true;
                } else {
                    if (select.value === value) btn.classList.add('active');
                    btn.addEventListener('click', () => {
                        select.value = value;
                        syncLabel();
                        select.dispatchEvent(new Event('change', {bubbles:true}));
                        closeDropdown();
                    });
                }
                grid.appendChild(btn);
            });
        }
        trigger.addEventListener('click', (event) => {
            event.stopPropagation();
            if (dropdown.classList.contains('is-open')) closeDropdown(); else openDropdown();
        });
        prevBtn.addEventListener('click', () => { if (viewYear > years[0]) { viewYear -= 1; render(); } });
        nextBtn.addEventListener('click', () => { if (viewYear < years[years.length - 1]) { viewYear += 1; render(); } });
        currentBtn.addEventListener('click', () => {
            const currentValue = latestValue;
            viewYear = Number(currentValue.slice(0,4));
            select.value = currentValue;
            syncLabel();
            select.dispatchEvent(new Event('change', {bubbles:true}));
            closeDropdown();
        });
        select.addEventListener('change', () => {
            if (/^\d{4}-(0[1-9]|1[0-2])$/.test(select.value)) viewYear = Number(select.value.slice(0,4));
            syncLabel();
            render();
        });
        document.addEventListener('click', (event) => {
            if (!dropdown.hidden && !dropdown.contains(event.target) && !trigger.contains(event.target)) closeDropdown();
        });
        document.addEventListener('keydown', (event) => { if (event.key === 'Escape') closeDropdown(); });
        syncLabel();
        render();
    }


    function setupPagedTable(options) {
        const input = document.getElementById(options.inputId);
        const monthInput = document.getElementById(options.monthId);
        const searchButton = document.getElementById(options.searchButtonId);
        const table = document.getElementById(options.tableId);
        const pager = document.getElementById(options.pagerId);
        const count = options.countSelector ? document.querySelector(options.countSelector) : null;
        if (!input || !table || !pager) return;
        const body = table.tBodies[0];
        const rows = Array.from(body.querySelectorAll(options.rowSelector));
        const noDataRow = body.querySelector('.empty-row');
        if (!rows.length) return; // retain the original no-data message

        // Only show months which actually exist in this table. No invented dates.
        const months = Array.from(new Set(rows.map(row => row.dataset.month || '')
            .filter(month => /^\d{4}-(0[1-9]|1[0-2])$/.test(month)))).sort().reverse();
        if (monthInput) {
            monthInput.innerHTML = '';
            months.forEach(month => {
                const [year, number] = month.split('-').map(Number);
                const option = document.createElement('option');
                option.value = month;
                option.textContent = monthNames[number - 1] + ' ' + (year + 543);
                monthInput.appendChild(option);
            });
            monthInput.disabled = months.length === 0;
            if (months.length) monthInput.value = months[0];
        }
        let currentPage = 1;
        const empty = document.createElement('tr');
        empty.className = 'filtered-empty-row';
        empty.hidden = true;
        const cell = document.createElement('td');
        cell.colSpan = table.tHead ? table.tHead.rows[0].cells.length : 1;
        cell.textContent = 'ไม่พบข้อมูลในเดือนหรือคำค้นหาที่เลือก';
        empty.appendChild(cell);
        body.appendChild(empty);

        function getFilteredRows() {
            const keyword = input.value.trim().toLocaleLowerCase('th-TH');
            const month = monthInput ? monthInput.value : '';
            return rows.filter(row => (!keyword || (row.dataset.search || '').toLocaleLowerCase('th-TH').includes(keyword))
                && (!month || row.dataset.month === month));
        }

        function pageItems(totalPages, page) {
            if (totalPages <= 7) return Array.from({length: totalPages}, (_, i) => i + 1);
            if (page <= 4) return [1,2,3,4,5,'…',totalPages];
            if (page >= totalPages - 3) return [1,'…',totalPages-4,totalPages-3,totalPages-2,totalPages-1,totalPages];
            return [1,'…',page-1,page,page+1,'…',totalPages];
        }

        function renderPager(totalPages) {
            pager.replaceChildren();
            if (totalPages <= 1) { pager.hidden = true; return; }
            pager.hidden = false;
            function makeButton(label, target, disabled, active, ariaLabel) {
                const btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'page-btn' + (active ? ' active' : '');
                btn.textContent = label;
                btn.disabled = disabled;
                btn.setAttribute('aria-label', ariaLabel);
                if (active) btn.setAttribute('aria-current', 'page');
                btn.addEventListener('click', () => {currentPage = target; render();});
                pager.appendChild(btn);
            }
            makeButton('<', currentPage - 1, currentPage === 1, false, 'หน้าก่อนหน้า');
            pageItems(totalPages, currentPage).forEach(item => {
                if (item === '…') {
                    const dots = document.createElement('span');
                    dots.className = 'page-ellipsis';
                    dots.textContent = '...';
                    pager.appendChild(dots);
                } else {
                    makeButton(String(item), item, false, item === currentPage, 'หน้า ' + item);
                }
            });
            makeButton('>', currentPage + 1, currentPage === totalPages, false, 'หน้าถัดไป');
        }

        function render() {
            const filtered = getFilteredRows();
            const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
            if (currentPage > totalPages) currentPage = totalPages;
            rows.forEach(row => {row.hidden = true; row.style.display = 'none';});
            const start = (currentPage - 1) * PAGE_SIZE;
            filtered.slice(start, start + PAGE_SIZE).forEach(row => {
                row.hidden = false; row.style.display = '';
            });
            empty.hidden = filtered.length !== 0;
            empty.style.display = filtered.length === 0 ? '' : 'none';
            if (noDataRow) noDataRow.hidden = true;
            if (count) count.textContent = filtered.length.toLocaleString('th-TH');
            renderPager(totalPages);
        }

        function resetAndRender() {currentPage = 1; render();}
        input.addEventListener('input', resetAndRender);
        if (searchButton) {
            searchButton.addEventListener('click', resetAndRender);
            input.addEventListener('keydown', event => {
                if (event.key === 'Enter') { event.preventDefault(); resetAndRender(); }
            });
        }
        if (monthInput) monthInput.addEventListener('change', resetAndRender);
        render();
    }

    setupPagedTable({
        inputId: 'patientSearch',
        searchButtonId: 'patientSearchButton',
        monthId: 'patientMonth',
        tableId: 'patientsTable',
        rowSelector: '.patient-row',
        pagerId: 'patientsPagination',
        countSelector: '#visiblePatientCount'
    });
    initCustomMonthPicker({
        selectId: 'patientMonth',
        triggerId: 'patientMonthTrigger',
        labelId: 'patientMonthLabel',
        dropdownId: 'patientMonthDropdown',
        yearId: 'patientMonthYear',
        gridId: 'patientMonthGrid',
        prevId: 'patientMonthPrev',
        nextId: 'patientMonthNext',
        currentId: 'patientMonthCurrent'
    });
    setupPagedTable({
        inputId: 'completedPatientSearch',
        searchButtonId: 'completedPatientSearchButton',
        monthId: 'completedPatientMonth',
        tableId: 'completedPatientsTable',
        rowSelector: '.completed-patient-row',
        pagerId: 'completedPatientsPagination',
        countSelector: '.completed-count'
    });
})();

(function(){
    const modal=document.getElementById('coordinateModal');
    const form=document.getElementById('coordinateForm');
    const patientId=document.getElementById('coordinatePatientId');
    const patientName=document.getElementById('coordinatePatientName');
    const latInput=document.getElementById('coordinateLatitude');
    const lngInput=document.getElementById('coordinateLongitude');
    const mapFrame=document.getElementById('caregiverGoogleMapFrame');
    const closeBtn=document.getElementById('coordinateClose');
    const cancelBtn=document.getElementById('coordinateCancel');
    const useCurrent=document.getElementById('coordinateUseCurrent');
    const clearBtn=document.getElementById('coordinateClear');
    const buttons=Array.from(document.querySelectorAll('[data-coordinate-button]'));
    if(!modal||!form||!latInput||!lngInput||!mapFrame) return;

    const defaultLat=15.0547605;
    const defaultLng=102.3578423;

    function mapUrl(lat,lng,zoom){
        const la=Number(lat), lo=Number(lng), z=Number(zoom)||15;
        return 'https://www.google.com/maps?q='+encodeURIComponent(la+','+lo)+'&z='+z+'&output=embed';
    }

    function updateMap(lat,lng,zoom){
        const la=parseFloat(lat), lo=parseFloat(lng);
        if(!Number.isFinite(la)||!Number.isFinite(lo)) return;
        mapFrame.src=mapUrl(la,lo,zoom||16);
    }

    function setCoordinate(lat,lng,focus){
        const la=parseFloat(lat), lo=parseFloat(lng);
        if(!Number.isFinite(la)||!Number.isFinite(lo)) return;
        latInput.value=la.toFixed(7);
        lngInput.value=lo.toFixed(7);
        updateMap(la,lo,focus===false?15:17);
    }

    function clearCoordinate(){
        latInput.value=''; lngInput.value='';
        updateMap(defaultLat,defaultLng,13);
    }

    function openModal(btn){
        patientId.value=btn.dataset.patientId||'';
        patientName.textContent=(btn.dataset.patientName||'ผู้สูงอายุ')+' — ตำแหน่งบ้านของผู้สูงอายุ';
        latInput.value=btn.dataset.latitude||'';
        lngInput.value=btn.dataset.longitude||'';
        modal.classList.add('is-open');
        modal.setAttribute('aria-hidden','false');
        document.body.style.overflow='hidden';
        if(latInput.value.trim()!==''&&lngInput.value.trim()!=='') setCoordinate(latInput.value,lngInput.value,true);
        else clearCoordinate();
    }

    function closeModal(){
        modal.classList.remove('is-open');
        modal.setAttribute('aria-hidden','true');
        document.body.style.overflow='';
    }

    buttons.forEach(btn=>btn.addEventListener('click',()=>openModal(btn)));
    closeBtn&&closeBtn.addEventListener('click',closeModal);
    cancelBtn&&cancelBtn.addEventListener('click',closeModal);
    modal.addEventListener('click',e=>{if(e.target===modal)closeModal();});
    document.addEventListener('keydown',e=>{if(e.key==='Escape'&&modal.classList.contains('is-open'))closeModal();});

    [latInput,lngInput].forEach(input=>input.addEventListener('change',function(){
        if(latInput.value.trim()!==''&&lngInput.value.trim()!=='') setCoordinate(latInput.value,lngInput.value,true);
    }));

    clearBtn&&clearBtn.addEventListener('click',clearCoordinate);
    useCurrent&&useCurrent.addEventListener('click',function(){
        if(!navigator.geolocation){alert('อุปกรณ์นี้ไม่รองรับการระบุตำแหน่ง');return;}
        navigator.geolocation.getCurrentPosition(
            pos=>setCoordinate(pos.coords.latitude,pos.coords.longitude,true),
            ()=>alert('ไม่สามารถดึงตำแหน่งปัจจุบันได้'),
            {enableHighAccuracy:true,timeout:10000,maximumAge:0}
        );
    });
})();
</script>
</body>
</html>
