<?php
/**
 * Dedicated caregiver ADL assessment page.
 * Reuses the existing assessment workflow while hiding the patient list/dashboard.
 */
define('CAREGIVER_ADL_FORM_ONLY', true);
require __DIR__ . '/caregiver_adl.php';
