<?php
header('Location: caregiver.php');
exit;
