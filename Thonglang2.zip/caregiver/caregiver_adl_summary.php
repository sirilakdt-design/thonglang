<?php
require_once __DIR__ . '/../connect.php';
requireRole('caregiver');
mysqli_set_charset($conn, 'utf8mb4');

$caregiverId = (int)($_SESSION['user_id'] ?? 0);
$selectedId = (int)($_GET['adl_id'] ?? 0);

function adlGroupCaregiver(int $score): string
{
    if ($score >= 12) return 'กลุ่มติดสังคม';
    if ($score >= 5) return 'กลุ่มติดบ้าน';
    return 'กลุ่มติดเตียง';
}

$rows = [];
$sql = "SELECT a.adl_id, a.assessment_date, a.total_score, a.caregiver_total_score, a.handoff_status,
               a.result_returned_at, a.caregiver_completed_at,
               p.Fullname, p.Age, p.Gender,
               v.villagename,
               d.display_name AS doctor_name, d.username AS doctor_username,
               cg.display_name AS caregiver_name, cg.username AS caregiver_username
        FROM adl_assessment a
        JOIN patient p ON p.Patient_id = a.patient_id
        LEFT JOIN village v ON v.village_id = p.Village_id
        LEFT JOIN users d ON d.user_id = a.doctor_user_id AND d.role='doctor'
        LEFT JOIN users cg ON cg.user_id = a.caregiver_user_id AND cg.role='caregiver'
        WHERE a.caregiver_user_id = ?
          AND a.caregiver_total_score IS NOT NULL
        ORDER BY COALESCE(a.result_returned_at, a.caregiver_completed_at, a.assessment_date) DESC, a.adl_id DESC";
$stmt = mysqli_prepare($conn, $sql);
if ($stmt) {
    mysqli_stmt_bind_param($stmt, 'i', $caregiverId);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    while ($row = mysqli_fetch_assoc($res)) {
        $rows[] = $row;
    }
    mysqli_stmt_close($stmt);
}

$historyMap = [];
if (!empty($rows)) {
    $adlIds = array_map(fn($r) => (int)($r['adl_id'] ?? 0), $rows);
    $adlIds = array_values(array_filter(array_unique($adlIds)));
    if (!empty($adlIds)) {
        $historySql = "SELECT adl_id, assessment_round, caregiver_total_score, caregiver_group, assessed_at
                       FROM caregiver_adl_history
                       WHERE adl_id IN (" . implode(',', $adlIds) . ")
                       ORDER BY assessment_round ASC, assessed_at ASC, history_id ASC";
        $historyRes = mysqli_query($conn, $historySql);
        if ($historyRes) {
            while ($history = mysqli_fetch_assoc($historyRes)) {
                $hid = (int)($history['adl_id'] ?? 0);
                if (!isset($historyMap[$hid])) $historyMap[$hid] = [];
                $historyMap[$hid][] = $history;
            }
            mysqli_free_result($historyRes);
        }
    }
}
?>
<!doctype html>
<html lang="th">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>สรุปผลการประเมิน | <?= e(appName()) ?></title>
<?php renderPastelTheme(); ?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Thai:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<style>
:root{
  --adl-bg:#f4fbfb;--adl-surface:#ffffff;--adl-soft:#f8fcfc;--adl-line:#d9ebe8;
  --adl-primary:#55bdc0;--adl-primary-dark:#2f7475;--adl-ink:#173d42;--adl-muted:#6f8483;
  --adl-success:#2f7d62;--adl-success-bg:#eaf7f1;--adl-shadow:0 16px 44px rgba(38,90,88,.08);
}
body.role-page{background:linear-gradient(180deg,#f5fbfb 0%,#eef8f8 100%)}
.main{padding-bottom:40px}
.summary-page{display:grid;gap:18px;max-width:1500px;margin:0 auto}
.page-head-card,.summary-list-card{border-radius:24px;overflow:hidden}
.page-head-card{background:rgba(255,255,255,.96);border:1px solid var(--adl-line);box-shadow:var(--adl-shadow);padding:24px 30px;position:relative}
.summary-list-card{background:transparent;border:0;box-shadow:none;overflow:visible}
.page-head-card:after{content:"";position:absolute;right:-80px;top:-90px;width:230px;height:230px;border-radius:50%;background:radial-gradient(circle,rgba(85,189,192,.16),rgba(85,189,192,0) 68%);pointer-events:none}
.page-head-title{display:flex;align-items:center;gap:16px;position:relative;z-index:1}.page-head-mark{width:6px;height:50px;border-radius:999px;background:linear-gradient(180deg,#61c8ca,#42aeb1);box-shadow:0 0 0 5px rgba(85,189,192,.08)}
.page-head-card h1{margin:0;color:var(--adl-ink);font-size:30px;font-weight:900;letter-spacing:-.3px}.page-head-sub{margin:7px 0 0;color:var(--adl-muted);font-size:13.5px;line-height:1.65}
.summary-list-head{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;padding:24px 28px 20px;border-bottom:1px solid #e7f0ee;background:linear-gradient(180deg,#fcfefe,#f9fdfc)}
.section-kicker{display:inline-flex;align-items:center;gap:7px;font-size:11px;font-weight:900;letter-spacing:.6px;color:#5e8982;text-transform:uppercase;margin-bottom:5px}.section-kicker:before{content:"";width:7px;height:7px;border-radius:50%;background:var(--adl-primary)}
.summary-list-head h2{margin:0;color:#1c4345;font-size:23px;font-weight:900}.summary-list-head p{margin:6px 0 0;color:#748886;font-size:13px}
.search-toolbar{padding:20px 28px 10px;display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap}
.search-input-wrap{position:relative;flex:1 1 560px;min-width:260px}.search-input{width:100%;box-sizing:border-box;border:1px solid #cfe3df;border-radius:15px;padding:13px 44px;font:inherit;background:#fff;color:var(--adl-ink);transition:.2s ease;box-shadow:0 4px 14px rgba(45,94,88,.03)}
.search-input:hover{border-color:#b8d9d4}.search-input:focus{outline:none;border-color:#79cdce;box-shadow:0 0 0 4px rgba(85,189,192,.12)}.search-input::placeholder{color:#9aa9a7}
.search-icon{position:absolute;left:16px;top:50%;transform:translateY(-50%);font-size:18px;color:#6f9993}.search-clear{position:absolute;right:12px;top:50%;transform:translateY(-50%);width:26px;height:26px;border:0;border-radius:50%;background:#edf7f5;color:#4d7a71;font-weight:900;cursor:pointer;display:none}.search-clear:hover{background:#def1ee}
.search-result{margin-left:auto;color:#617a77;font-size:12.5px;font-weight:800;padding:8px 12px;border-radius:999px;background:#f1f8f7;border:1px solid #e0efec;white-space:nowrap}
.summary-list{display:grid;gap:14px;padding:2px 0 0}.summary-item{display:grid;grid-template-columns:minmax(300px,1.55fr) minmax(360px,1fr) minmax(190px,.58fr);gap:18px;align-items:center;padding:18px 20px;border:1px solid #dceae7;border-radius:20px;background:linear-gradient(180deg,#fff,#fbfefe);box-shadow:0 5px 16px rgba(37,78,66,.035);transition:transform .18s ease,box-shadow .18s ease,border-color .18s ease}
.summary-item:hover{transform:translateY(-2px);border-color:#b9ded9;box-shadow:0 12px 28px rgba(47,102,96,.09)}.summary-item.active{border-color:#7fcfd0;background:#f6fcfc;box-shadow:0 12px 28px rgba(88,191,192,.12)}
.patient-name{font-size:19px;font-weight:900;color:#173e3c;line-height:1.35}.patient-meta{margin-top:6px;color:#738783;font-size:12.5px;line-height:1.65}.status-chip{display:inline-flex;align-items:center;gap:6px;padding:6px 10px;border-radius:999px;border:1px solid #cbe5dc;background:var(--adl-success-bg);color:var(--adl-success);font-size:11.5px;font-weight:900;margin-top:9px}.status-chip:before{content:"✓";font-size:11px}
.mini-stat{display:grid;gap:4px;justify-items:center;text-align:center;padding:13px 12px;border:1px solid #e1eeeb;border-radius:16px;background:#fff}.mini-stat-link{display:grid;gap:4px;justify-items:center;text-align:center;padding:13px 12px;border:1px solid #e1eeeb;border-radius:16px;background:#fff;text-decoration:none;transition:.18s ease;box-shadow:0 4px 10px rgba(37,78,66,.03)}.mini-stat-link:hover{transform:translateY(-1px);border-color:#9ed7cf;background:#f9fdfc;box-shadow:0 8px 18px rgba(37,78,66,.07)}.mini-stat-link:focus{outline:none;border-color:#79cdce;box-shadow:0 0 0 3px rgba(85,189,192,.12)}.mini-stat-link span,.mini-stat span{font-size:11px;color:#6e8480;font-weight:800}.mini-stat-link strong,.mini-stat strong{font-size:26px;line-height:1.15;color:var(--adl-primary-dark);font-weight:900;letter-spacing:-.5px}.mini-stat-link small,.mini-stat small{font-size:11.5px;color:#4d6d66;font-weight:800}
.item-actions{display:flex;gap:9px;justify-content:flex-end;flex-wrap:wrap}.action-btn,.print-btn,.secondary-btn{min-height:42px;display:inline-flex;align-items:center;justify-content:center;gap:7px;text-decoration:none;padding:0 16px;border-radius:12px;font:inherit;font-size:13px;font-weight:900;cursor:pointer;white-space:nowrap;transition:.18s ease;box-sizing:border-box}.secondary-btn{border:1px solid #bfded8;background:#fff;color:#315d57}.secondary-btn:hover{background:#f0f9f7;border-color:#99cfc6}.action-btn,.print-btn{border:1px solid transparent;background:linear-gradient(180deg,#62c7c9,#50b7ba);color:#fff;box-shadow:0 7px 14px rgba(78,178,181,.18)}.print-btn{width:76px;min-width:76px;min-height:46px;font-size:14px;padding:0 8px}.action-btn:hover,.print-btn:hover{background:linear-gradient(180deg,#55bdc0,#45a9ac);transform:translateY(-1px)}
.score-strip{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;align-items:stretch}

.empty-state{padding:46px 24px;text-align:center;color:#748882;background:#fbfdfd;border:1px dashed #d8e7e4;border-radius:16px}
@media(max-width:1180px){.summary-item{grid-template-columns:1.2fr 1fr}.item-actions{grid-column:1/-1;justify-content:flex-end}.score-strip{grid-column:1/-1}}
@media(max-width:850px){.summary-page{gap:14px}.page-head-card{padding:20px}.page-head-card h1{font-size:25px}.summary-list-head{padding:20px}.search-toolbar{padding-left:20px;padding-right:20px}.summary-item{grid-template-columns:1fr}.summary-item>div:first-child,.score-strip,.item-actions{grid-column:1/-1}.item-actions{justify-content:flex-start}.mini-stat{justify-items:center}.score-strip{grid-template-columns:1fr 1fr}}
@media(max-width:560px){.summary-item{grid-template-columns:1fr}.summary-item>div:first-child,.score-strip,.item-actions{grid-column:auto}.mini-stat{justify-items:start;text-align:left}.item-actions{justify-content:stretch}.secondary-btn,.print-btn{flex:1}.score-strip{grid-template-columns:1fr}.search-result{margin-left:0;width:100%;box-sizing:border-box;text-align:center}.page-head-mark{height:44px}.page-head-card h1{font-size:22px}}

.summary-search-outside{margin:0 0 14px;background:transparent;padding:0}.summary-search-outside .search-toolbar{margin:0;padding:0;background:transparent;border:0;box-shadow:none}.summary-search-outside .search-input-wrap{flex:1 1 auto;max-width:none}.summary-search-outside .search-input{width:100%;background:#fff}.summary-search-outside .search-result{margin-left:auto}
.summary-pagination{display:flex;align-items:center;justify-content:center;gap:10px;flex-wrap:wrap;padding:18px 0 4px}.summary-pagination[hidden]{display:none!important}
.pagination-summary{font-size:12.5px;color:#6c8480;font-weight:800}
.pagination-controls{display:flex;align-items:center;justify-content:center;gap:8px;flex-wrap:wrap}
.page-btn,.page-number-btn,.page-ellipsis{display:inline-flex;align-items:center;justify-content:center;min-width:38px;height:38px;padding:0 12px;border-radius:10px;border:1px solid #d7e7e2;background:#fff;color:#335f57;text-decoration:none;font-weight:800;font-size:13px;transition:background .16s ease,border-color .16s ease,color .16s ease,opacity .16s ease}
.page-btn:hover,.page-number-btn:hover{background:#f4faf8;border-color:#c9ded7}.page-btn[disabled],.page-number-btn[disabled]{opacity:.45;cursor:default;pointer-events:none}.page-number-btn.is-active{background:#5ebfc0;border-color:#5ebfc0;color:#fff}.page-ellipsis{border-color:transparent;background:transparent;color:#7b918c;min-width:24px;padding:0 2px}

/* Consistent "รายละเอียดเพิ่มเติม" action */
.secondary-btn{min-height:46px!important;padding:0 18px!important;border:1px solid #bcdedb!important;border-radius:14px!important;background:#fff!important;color:#215a60!important;font-size:13px!important;font-weight:900!important;box-shadow:none!important}
.secondary-btn:hover{background:#f6fbfb!important;border-color:#9fd1cd!important}

</style>
</head>
<body class="role-page">
<?php renderSidebar(); ?>
<main class="main">
<?php renderUserTopbar(); ?>
<div class="summary-page">
    
    <div class="summary-search-outside">
<div class="search-toolbar">
            <div class="search-input-wrap">
                <span class="search-icon">⌕</span>
                <input type="text" id="summaryPatientSearch" class="search-input" placeholder="ค้นหาชื่อผู้สูงอายุ...">
                <button type="button" class="search-clear" id="summarySearchClear">×</button>
            </div>
            <div class="search-result" id="summarySearchResult">แสดงทั้งหมด <?= count($rows) ?> รายการ</div>
        </div>
    </div>

    <section class="summary-list-card">
        <?php if (!empty($rows)): ?>

        <div class="summary-list" id="summaryPatientList">
            <?php foreach ($rows as $row):
                $rowId = (int)$row['adl_id'];
                $isActive = $selectedId > 0 && $rowId === $selectedId;
                $doctorScore = (int)($row['total_score'] ?? 0);
                $caregiverScore = (int)($row['caregiver_total_score'] ?? 0);
                $statusText = trim((string)($row['handoff_status'] ?? 'ส่งผลกลับหมอแล้ว')) ?: 'ส่งผลกลับหมอแล้ว';
            ?>
            <article class="summary-item<?= $isActive ? ' active' : '' ?>" data-patient-name="<?= e($row['Fullname']) ?>">
                <div>
                    <div class="patient-name"><?= e($row['Fullname']) ?></div>
                </div>
                <?php
                    $historyRounds = $historyMap[$rowId] ?? [];
                    $totalRounds = 1 + count($historyRounds);
                    $latestRoundNo = 1;
                    if (!empty($historyRounds)) {
                        $lastHistory = end($historyRounds);
                        $latestRoundNo = max(1, (int)($lastHistory['assessment_round'] ?? 1));
                        reset($historyRounds);
                    }
                ?>
                <div class="score-strip">
                    <a class="mini-stat-link" href="caregiver_adl_round_detail.php?adl_id=<?= $rowId ?>&round=1" title="ดูรายละเอียดการประเมิน">
                        <span>ครั้งที่ 1 ● หมอ</span>
                        <strong><?= $doctorScore ?>/20</strong>
                        <small><?= e(adlGroupCaregiver($doctorScore)) ?></small>
                    </a>
                    <?php foreach (array_slice($historyRounds, 0, 2) as $hist):
                        $roundNo = (int)($hist['assessment_round'] ?? 0);
                        $roundScore = (int)($hist['caregiver_total_score'] ?? 0);
                    ?>
                    <a class="mini-stat-link" href="caregiver_adl_round_detail.php?adl_id=<?= $rowId ?>&round=<?= $roundNo ?>" title="ดูรายละเอียดการประเมิน">
                        <span>ครั้งที่ <?= $roundNo ?> ● แคร์กิฟเวอร์</span>
                        <strong><?= $roundScore ?>/20</strong>
                        <small><?= e(trim((string)($hist['caregiver_group'] ?? '')) ?: adlGroupCaregiver($roundScore)) ?></small>
                    </a>
                    <?php endforeach; ?>
                </div>
                <div class="item-actions">
                    <a class="secondary-btn" href="caregiver_adl_summary_view.php?adl_id=<?= $rowId ?>">รายละเอียดเพิ่มเติม</a>
                </div>
            </article>
            <?php endforeach; ?>
            <div class="empty-state" id="summarySearchEmpty" style="display:none;">ไม่พบชื่อผู้สูงอายุตามคำค้นหา</div>
        </div>
        <div class="summary-pagination" id="summaryPagination" hidden>
            <div class="pagination-summary" id="summaryPaginationSummary">แสดง 1-10 จาก 10 รายการ</div>
            <div class="pagination-controls" id="summaryPaginationControls"></div>
        </div>
        <?php else: ?>
            <div class="empty-state">ยังไม่มีผลการประเมิน ADL ครั้งที่ 2 ที่พร้อมสรุปผล</div>
        <?php endif; ?>
    </section>
</div>
</main>
<script>
(function(){
    const input = document.getElementById('summaryPatientSearch');
    if (!input) return;
    const list = Array.from(document.querySelectorAll('#summaryPatientList .summary-item'));
    const result = document.getElementById('summarySearchResult');
    const empty = document.getElementById('summarySearchEmpty');
    const clearBtn = document.getElementById('summarySearchClear');
    const pagination = document.getElementById('summaryPagination');
    const paginationSummary = document.getElementById('summaryPaginationSummary');
    const paginationControls = document.getElementById('summaryPaginationControls');
    const normalize = v => (v || '').toLocaleLowerCase('th-TH').replace(/\s+/g, ' ').trim();
    const ITEMS_PER_PAGE = 10;
    let currentPage = 1;

    function buildPageSequence(current, total){
        const pages = [];
        if (total <= 7){
            for (let i = 1; i <= total; i++) pages.push(i);
            return pages;
        }
        pages.push(1);
        const start = Math.max(2, current - 1);
        const end = Math.min(total - 1, current + 1);
        if (start > 2) pages.push('ellipsis');
        for (let i = start; i <= end; i++) pages.push(i);
        if (end < total - 1) pages.push('ellipsis');
        pages.push(total);
        return pages;
    }

    function renderPagination(totalVisible, totalPages, startIndex, endIndex){
        if (!pagination || !paginationSummary || !paginationControls) return;
        const shouldShow = totalVisible > ITEMS_PER_PAGE;
        pagination.hidden = !shouldShow;
        paginationSummary.textContent = totalVisible === 0
            ? 'ไม่พบรายการ'
            : `แสดง ${startIndex + 1}-${endIndex} จาก ${totalVisible} รายการ`;
        paginationControls.innerHTML = '';
        if (!shouldShow) return;

        const prev = document.createElement('button');
        prev.type = 'button';
        prev.className = 'page-btn';
        prev.textContent = '<';
        prev.disabled = currentPage === 1;
        prev.addEventListener('click', function(){
            currentPage -= 1;
            filterList(false);
        });
        paginationControls.appendChild(prev);

        buildPageSequence(currentPage, totalPages).forEach(function(item){
            if (item === 'ellipsis'){
                const span = document.createElement('span');
                span.className = 'page-ellipsis';
                span.textContent = '...';
                paginationControls.appendChild(span);
            } else {
                const btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'page-number-btn' + (item === currentPage ? ' is-active' : '');
                btn.textContent = String(item);
                if (item === currentPage) btn.setAttribute('aria-current', 'page');
                btn.addEventListener('click', function(){
                    currentPage = item;
                    filterList(false);
                });
                paginationControls.appendChild(btn);
            }
        });

        const next = document.createElement('button');
        next.type = 'button';
        next.className = 'page-btn';
        next.textContent = '>';
        next.disabled = currentPage === totalPages;
        next.addEventListener('click', function(){
            currentPage += 1;
            filterList(false);
        });
        paginationControls.appendChild(next);
    }

    function filterList(resetPage = true){
        const q = normalize(input.value);
        const filtered = list.filter(item => {
            const name = normalize(item.dataset.patientName || '');
            return !q || name.includes(q);
        });
        const visible = filtered.length;
        const totalPages = Math.max(1, Math.ceil(visible / ITEMS_PER_PAGE));
        if (resetPage) currentPage = 1;
        if (currentPage > totalPages) currentPage = totalPages;
        if (currentPage < 1) currentPage = 1;
        const startIndex = visible ? ((currentPage - 1) * ITEMS_PER_PAGE) : 0;
        const endIndex = Math.min(startIndex + ITEMS_PER_PAGE, visible);

        list.forEach(item => item.style.display = 'none');
        filtered.forEach((item, index) => {
            item.style.display = (index >= startIndex && index < endIndex) ? '' : 'none';
        });

        if (result) result.textContent = q ? `พบ ${visible} รายการ` : `แสดงทั้งหมด ${list.length} รายการ`;
        if (empty) empty.style.display = visible === 0 ? 'block' : 'none';
        if (clearBtn) clearBtn.style.display = input.value ? 'block' : 'none';
        renderPagination(visible, totalPages, startIndex, endIndex);
    }
    input.addEventListener('input', function(){ filterList(true); });
    if (clearBtn) clearBtn.addEventListener('click', function(){ input.value=''; filterList(true); input.focus(); });
    filterList(true);
})();
</script>
</body>
</html>
