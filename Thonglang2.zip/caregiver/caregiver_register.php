<?php
require_once __DIR__ . '/../connect.php';
requireRole('doctor', 'admin', 'caregiver');
ensureThonglangCoreSchema($conn);
mysqli_set_charset($conn, 'utf8mb4');

$message = '';
$messageType = '';

function caregiverRegisterUsernameExists(mysqli $connection, string $username): bool
{
    $statement = mysqli_prepare($connection, 'SELECT user_id FROM users WHERE username=? LIMIT 1');
    if (!$statement) return false;
    mysqli_stmt_bind_param($statement, 's', $username);
    mysqli_stmt_execute($statement);
    $exists = mysqli_fetch_assoc(mysqli_stmt_get_result($statement));
    mysqli_stmt_close($statement);
    return (bool)$exists;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $firstname = trim((string)($_POST['firstname'] ?? ''));
    $lastname = trim((string)($_POST['lastname'] ?? ''));
    $displayName = trim($firstname . ' ' . $lastname);
    $phoneNumber = trim((string)($_POST['phone_number'] ?? ''));
    $responsibleVillageId = (int)($_POST['responsible_village_id'] ?? 0);
    $username = trim((string)($_POST['username'] ?? ''));
    $password = (string)($_POST['password'] ?? '');
    $confirmPassword = (string)($_POST['confirm_password'] ?? '');
    $createdDate = date('Y-m-d');

    if ($firstname === '' || $lastname === '' || $phoneNumber === '' || $responsibleVillageId <= 0 || $username === '' || $password === '') {
        $message = 'กรุณากรอกข้อมูลที่จำเป็นให้ครบทุกช่อง';
        $messageType = 'error';
    } elseif (strlen($password) < 4) {
        $message = 'รหัสผ่านต้องมีอย่างน้อย 4 ตัวอักษร';
        $messageType = 'error';
    } elseif ($password !== $confirmPassword) {
        $message = 'ยืนยันรหัสผ่านไม่ตรงกัน';
        $messageType = 'error';
    } elseif (isRemovedUsername($username)) {
        $message = 'ชื่อผู้ใช้งานนี้ถูกยกเลิกแล้ว กรุณาใช้ชื่ออื่น';
        $messageType = 'error';
    } elseif (caregiverRegisterUsernameExists($conn, $username)) {
        $message = 'ชื่อผู้ใช้งานนี้มีอยู่แล้ว กรุณาใช้ชื่ออื่น';
        $messageType = 'error';
    } else {
        $role = 'caregiver';
        $passwordHash = password_hash($password, PASSWORD_DEFAULT);
        $isActive = 1;
        $statement = mysqli_prepare(
            $conn,
            'INSERT INTO users (username, password_hash, role, display_name, phone_number, responsible_village_id, is_active, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
        );
        if ($statement) {
            mysqli_stmt_bind_param($statement, 'sssssiis', $username, $passwordHash, $role, $displayName, $phoneNumber, $responsibleVillageId, $isActive, $createdDate);
            if (mysqli_stmt_execute($statement)) {
                $message = 'สมัครแคร์กิฟเวอร์สำเร็จ สามารถใช้บัญชีนี้เข้าสู่ระบบได้ทันที';
                $messageType = 'success';
                $_POST = [];
            } else {
                $message = 'ไม่สามารถบันทึกข้อมูลได้: ' . mysqli_stmt_error($statement);
                $messageType = 'error';
            }
            mysqli_stmt_close($statement);
        } else {
            $message = 'ไม่สามารถเตรียมคำสั่งบันทึกข้อมูลได้';
            $messageType = 'error';
        }
    }
}

$villages = [];
$villageResult = mysqli_query($conn, 'SELECT village_id, village_number, villagename FROM village ORDER BY CAST(village_number AS UNSIGNED), village_id');
if ($villageResult) {
    while ($row = mysqli_fetch_assoc($villageResult)) $villages[] = $row;
}
?>
<!doctype html>
<html lang="th">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>การสมัครแคร์กิฟเวอร์ | <?= e(appName()) ?></title>
<?php renderPastelTheme(); ?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Thai:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<style>
body.role-page .register-card{max-width:980px;margin:0 auto}
body.role-page .register-head{margin-bottom:22px}
body.role-page .register-head h1{margin:0;color:#234f53;font-size:28px}
body.role-page .register-head p{margin:7px 0 0;color:#718a87;line-height:1.6}
body.role-page .register-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px}
body.role-page .register-note{font-size:12px;color:#78908c;margin-top:6px;line-height:1.5}
body.role-page .register-actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:22px}
body.role-page .register-success{padding:34px 24px;text-align:center;border:1px solid #cfe8df;border-radius:22px;background:#f3fbf7;margin-top:8px}
body.role-page .register-success-icon{width:72px;height:72px;margin:0 auto 16px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:#dff5ea;color:#27835f;font-size:38px;font-weight:900}
body.role-page .register-success h2{margin:0;color:#25624f;font-size:25px}
body.role-page .register-success p{margin:10px auto 0;color:#68817b;line-height:1.65;max-width:650px}
body.role-page .register-success-actions{display:flex;justify-content:center;gap:10px;flex-wrap:wrap;margin-top:22px}
@media(max-width:760px){body.role-page .register-grid{grid-template-columns:1fr}}
</style>
</head>
<body class="role-page">
<?php renderSidebar(); ?>
<div class="main">
    <?php renderUserTopbar(); ?>

    <section class="card register-card">
        <div class="register-head">
            <h1>การสมัครแคร์กิฟเวอร์</h1>
            <p>กรอกข้อมูลเพื่อสร้างบัญชีแคร์กิฟเวอร์สำหรับเข้าสู่ระบบและรับผิดชอบผู้สูงอายุในพื้นที่ที่กำหนด</p>
        </div>

        <?php if ($messageType === 'success'): ?>
            <div class="register-success">
                <div class="register-success-icon">✓</div>
                <h2>สมัครสำเร็จ</h2>
                <p><?= e($message) ?></p>
                <div class="register-success-actions">
                    <a class="btn btn-primary" href="caregiver_register.php">สมัครแคร์กิฟเวอร์เพิ่ม</a>
                    <a class="btn btn-secondary" href="<?= e(appUrl('home.php')) ?>">กลับหน้าแรก</a>
                </div>
            </div>
        <?php else: ?>
            <?php if ($message !== ''): ?>
                <div class="alert alert-error"><?= e($message) ?></div>
            <?php endif; ?>

        <form method="post" autocomplete="off">
            <div class="register-grid">
                <div class="field">
                    <label>ชื่อ *</label>
                    <input name="firstname" required value="<?= e($_POST['firstname'] ?? '') ?>" placeholder="กรอกชื่อ">
                </div>
                <div class="field">
                    <label>นามสกุล *</label>
                    <input name="lastname" required value="<?= e($_POST['lastname'] ?? '') ?>" placeholder="กรอกนามสกุล">
                </div>
                <div class="field">
                    <label>หมายเลขโทรศัพท์ *</label>
                    <input name="phone_number" required value="<?= e($_POST['phone_number'] ?? '') ?>" placeholder="ตัวอย่าง 0812345678">
                </div>
                <div class="field">
                    <label>หมู่บ้านหรือพื้นที่รับผิดชอบ *</label>
                    <select name="responsible_village_id" required>
                        <option value="">-- เลือกหมู่บ้านหรือพื้นที่รับผิดชอบ --</option>
                        <?php $selectedVillage=(int)($_POST['responsible_village_id'] ?? 0); foreach($villages as $village): ?>
                            <option value="<?= (int)$village['village_id'] ?>" <?= $selectedVillage===(int)$village['village_id']?'selected':'' ?>><?= e(($village['village_number'] ? 'หมู่ที่ '.$village['village_number'].' ' : '').$village['villagename']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="field">
                    <label>ชื่อผู้ใช้งาน *</label>
                    <input name="username" required value="<?= e($_POST['username'] ?? '') ?>" placeholder="กำหนดชื่อสำหรับเข้าสู่ระบบ">
                </div>
                <div class="field">
                    <label>รหัสผ่าน *</label>
                    <input type="password" name="password" required minlength="4" autocomplete="new-password" placeholder="อย่างน้อย 4 ตัวอักษร">
                </div>
                <div class="field">
                    <label>ยืนยันรหัสผ่าน *</label>
                    <input type="password" name="confirm_password" required minlength="4" autocomplete="new-password" placeholder="กรอกรหัสผ่านอีกครั้ง">
                </div>
            </div>

            <div class="register-actions">
                <button class="btn btn-primary" type="submit">สมัครแคร์กิฟเวอร์</button>
                <button class="btn btn-secondary" type="reset">ล้างข้อมูล</button>
            </div>
        </form>
        <?php endif; ?>
    </section>
</div>
</body>
</html>
