<?php
require_once __DIR__ . '/../connect.php';
requireRole('caregiver');
mysqli_set_charset($conn, 'utf8mb4');

$caregiverId = (int)($_SESSION['user_id'] ?? 0);
$message = '';
$error = '';
$sentDetails = null;
$formOnly = defined('CAREGIVER_ADL_FORM_ONLY') && CAREGIVER_ADL_FORM_ONLY;

function ensureCaregiverAdlColumn(mysqli $conn, string $column, string $definition): void
{
    $safe = preg_replace('/[^a-zA-Z0-9_]/', '', $column);
    $res = mysqli_query($conn, "SHOW COLUMNS FROM adl_assessment WHERE Field='" . mysqli_real_escape_string($conn, $safe) . "'");
    if ($res && mysqli_num_rows($res) === 0) {
        mysqli_query($conn, "ALTER TABLE adl_assessment ADD COLUMN `$safe` $definition");
    }
}

function ensureCaregiverAdlHistoryTable(mysqli $conn): void
{
    $sql = "CREATE TABLE IF NOT EXISTS caregiver_adl_history (
        history_id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        adl_id INT NOT NULL,
        patient_id INT NULL,
        caregiver_user_id INT NULL,
        assessment_round INT NOT NULL,
        assessed_at DATETIME NOT NULL,
        doctor_total_score TINYINT NULL,
        caregiver_total_score TINYINT NULL,
        caregiver_group VARCHAR(80) NULL,
        feeding TINYINT NULL,
        grooming TINYINT NULL,
        transfer_score TINYINT NULL,
        toilet_use TINYINT NULL,
        mobility TINYINT NULL,
        dressing TINYINT NULL,
        stairs TINYINT NULL,
        bathing TINYINT NULL,
        bowels TINYINT NULL,
        bladder TINYINT NULL,
        health_assessment_date DATE NULL,
        health_weight_kg DECIMAL(7,2) NULL,
        health_waist_cm DECIMAL(7,2) NULL,
        health_hip_cm DECIMAL(7,2) NULL,
        health_waist_hip_ratio DECIMAL(7,3) NULL,
        health_body_fat_pct DECIMAL(7,2) NULL,
        health_visceral_fat DECIMAL(7,2) NULL,
        health_bmr DECIMAL(9,2) NULL,
        health_bmi DECIMAL(7,2) NULL,
        health_body_age DECIMAL(7,2) NULL,
        health_subfat_total DECIMAL(7,2) NULL,
        health_subfat_trunk DECIMAL(7,2) NULL,
        health_subfat_arms DECIMAL(7,2) NULL,
        health_subfat_legs DECIMAL(7,2) NULL,
        health_muscle_total DECIMAL(7,2) NULL,
        health_muscle_trunk DECIMAL(7,2) NULL,
        health_muscle_arms DECIMAL(7,2) NULL,
        health_muscle_legs DECIMAL(7,2) NULL,
        health_fat_free_mass DECIMAL(8,2) NULL,
        health_dtx DECIMAL(8,2) NULL,
        health_bp VARCHAR(40) NULL,
        regular_caregiver VARCHAR(120) NULL,
        welfare_status VARCHAR(60) NULL,
        club_membership VARCHAR(120) NULL,
        note TEXT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        KEY idx_adl_id (adl_id),
        KEY idx_caregiver_user_id (caregiver_user_id),
        KEY idx_assessment_round (assessment_round)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
    mysqli_query($conn, $sql);
}

function caregiverAdlBackfillHistory(mysqli $conn): void
{
    $sql = "INSERT INTO caregiver_adl_history (
                adl_id, patient_id, caregiver_user_id, assessment_round, assessed_at,
                doctor_total_score, caregiver_total_score, caregiver_group,
                feeding, grooming, transfer_score, toilet_use, mobility, dressing, stairs, bathing, bowels, bladder,
                health_assessment_date, health_weight_kg, health_waist_cm, health_hip_cm, health_waist_hip_ratio,
                health_body_fat_pct, health_visceral_fat, health_bmr, health_bmi, health_body_age,
                health_subfat_total, health_subfat_trunk, health_subfat_arms, health_subfat_legs,
                health_muscle_total, health_muscle_trunk, health_muscle_arms, health_muscle_legs,
                health_fat_free_mass, health_dtx, health_bp,
                regular_caregiver, welfare_status, club_membership, note
            )
            SELECT 
                a.adl_id, a.patient_id, a.caregiver_user_id, 2, COALESCE(a.caregiver_completed_at, NOW()),
                a.total_score, a.caregiver_total_score,
                CASE WHEN a.caregiver_total_score >= 12 THEN 'กลุ่มติดสังคม'
                     WHEN a.caregiver_total_score >= 5 THEN 'กลุ่มติดบ้าน'
                     ELSE 'กลุ่มติดเตียง' END,
                a.caregiver_feeding, a.caregiver_grooming, a.caregiver_transfer, a.caregiver_toilet_use, a.caregiver_mobility,
                a.caregiver_dressing, a.caregiver_stairs, a.caregiver_bathing, a.caregiver_bowels, a.caregiver_bladder,
                a.caregiver_health_assessment_date, a.caregiver_health_weight_kg, a.caregiver_health_waist_cm, a.caregiver_health_hip_cm,
                a.caregiver_health_waist_hip_ratio, a.caregiver_health_body_fat_pct, a.caregiver_health_visceral_fat, a.caregiver_health_bmr,
                a.caregiver_health_bmi, a.caregiver_health_body_age, a.caregiver_health_subfat_total, a.caregiver_health_subfat_trunk,
                a.caregiver_health_subfat_arms, a.caregiver_health_subfat_legs, a.caregiver_health_muscle_total, a.caregiver_health_muscle_trunk,
                a.caregiver_health_muscle_arms, a.caregiver_health_muscle_legs, a.caregiver_health_fat_free_mass, a.caregiver_health_dtx,
                a.caregiver_health_bp, a.regular_caregiver, a.welfare_status, a.club_membership, a.note
            FROM adl_assessment a
            WHERE a.caregiver_total_score IS NOT NULL
              AND NOT EXISTS (
                  SELECT 1 FROM caregiver_adl_history h WHERE h.adl_id = a.adl_id
              )";
    mysqli_query($conn, $sql);
}

function adlThaiDate(?string $value): string
{
    if (!$value) return '-';
    $ts = strtotime($value);
    if (!$ts) return (string)$value;
    $months = [1=>'ม.ค.','ก.พ.','มี.ค.','เม.ย.','พ.ค.','มิ.ย.','ก.ค.','ส.ค.','ก.ย.','ต.ค.','พ.ย.','ธ.ค.'];
    return date('j', $ts) . ' ' . $months[(int)date('n', $ts)] . ' ' . ((int)date('Y', $ts) + 543);
}

function adlThaiDateTime(?string $value): string
{
    if (!$value) return '-';
    $ts = strtotime($value);
    if (!$ts) return (string)$value;
    return adlThaiDate(date('Y-m-d', $ts)) . ' ' . date('H:i', $ts) . ' น.';
}

$exists = mysqli_query($conn, "SHOW TABLES LIKE 'adl_assessment'");
if (!$exists || mysqli_num_rows($exists) === 0) {
    $error = 'ยังไม่มีข้อมูลการประเมิน ADL จากหมอ';
} else {
    $columns = [
        'caregiver_user_id' => 'INT NULL',
        'handoff_status' => "VARCHAR(40) NOT NULL DEFAULT 'รอส่งต่อ'",
        'caregiver_completed_at' => 'DATETIME NULL',
        'result_returned_to_doctor' => 'TINYINT(1) NOT NULL DEFAULT 0',
        'result_returned_at' => 'DATETIME NULL',
        'regular_caregiver' => 'VARCHAR(120) NULL',
        'welfare_status' => 'VARCHAR(60) NULL',
        'club_membership' => 'VARCHAR(120) NULL',
        'note' => 'TEXT NULL',
        'caregiver_feeding' => 'TINYINT NULL',
        'caregiver_grooming' => 'TINYINT NULL',
        'caregiver_transfer' => 'TINYINT NULL',
        'caregiver_toilet_use' => 'TINYINT NULL',
        'caregiver_mobility' => 'TINYINT NULL',
        'caregiver_dressing' => 'TINYINT NULL',
        'caregiver_stairs' => 'TINYINT NULL',
        'caregiver_bathing' => 'TINYINT NULL',
        'caregiver_bowels' => 'TINYINT NULL',
        'caregiver_bladder' => 'TINYINT NULL',
        'caregiver_total_score' => 'TINYINT NULL',
        'caregiver_health_assessment_date' => 'DATE NULL',
        'caregiver_health_weight_kg' => 'DECIMAL(7,2) NULL',
        'caregiver_health_waist_cm' => 'DECIMAL(7,2) NULL',
        'caregiver_health_hip_cm' => 'DECIMAL(7,2) NULL',
        'caregiver_health_waist_hip_ratio' => 'DECIMAL(7,3) NULL',
        'caregiver_health_body_fat_pct' => 'DECIMAL(7,2) NULL',
        'caregiver_health_visceral_fat' => 'DECIMAL(7,2) NULL',
        'caregiver_health_bmr' => 'DECIMAL(9,2) NULL',
        'caregiver_health_bmi' => 'DECIMAL(7,2) NULL',
        'caregiver_health_body_age' => 'DECIMAL(7,2) NULL',
        'caregiver_health_subfat_total' => 'DECIMAL(7,2) NULL',
        'caregiver_health_subfat_trunk' => 'DECIMAL(7,2) NULL',
        'caregiver_health_subfat_arms' => 'DECIMAL(7,2) NULL',
        'caregiver_health_subfat_legs' => 'DECIMAL(7,2) NULL',
        'caregiver_health_muscle_total' => 'DECIMAL(7,2) NULL',
        'caregiver_health_muscle_trunk' => 'DECIMAL(7,2) NULL',
        'caregiver_health_muscle_arms' => 'DECIMAL(7,2) NULL',
        'caregiver_health_muscle_legs' => 'DECIMAL(7,2) NULL',
        'caregiver_health_fat_free_mass' => 'DECIMAL(8,2) NULL',
        'caregiver_health_dtx' => 'DECIMAL(8,2) NULL',
        'caregiver_health_bp' => 'VARCHAR(40) NULL',
    ];
    foreach ($columns as $col => $def) ensureCaregiverAdlColumn($conn, $col, $def);
    ensureCaregiverAdlHistoryTable($conn);
    caregiverAdlBackfillHistory($conn);
}

/* ซิงก์ผล ADL จากหมอมายังแคร์กิฟเวอร์ที่รับผิดชอบโดยอัตโนมัติ
   เพื่อให้คะแนนหมอและกลุ่ม ADL แสดงในบัญชีแคร์กิฟเวอร์ทันที แม้รายการเดิมยังไม่ได้ผูก caregiver_user_id */
if ($caregiverId > 0) {
    $assignmentTable = mysqli_query($conn, "SHOW TABLES LIKE 'patient_caregiver_assignment'");
    if ($assignmentTable && mysqli_num_rows($assignmentTable) > 0) {
        $syncSql = "UPDATE adl_assessment a
                    INNER JOIN patient_caregiver_assignment pca
                        ON pca.patient_id=a.patient_id
                       AND pca.caregiver_user_id=?
                       AND pca.care_status='กำลังดูแล'
                    SET a.caregiver_user_id=?,
                        a.handoff_status=CASE
                            WHEN a.handoff_status='ประเมินต่อแล้ว' THEN a.handoff_status
                            ELSE 'รอแคร์กิฟเวอร์ประเมินต่อ'
                        END
                    WHERE a.caregiver_user_id IS NULL OR a.caregiver_user_id=0";
        $syncStmt = mysqli_prepare($conn, $syncSql);
        if ($syncStmt) {
            mysqli_stmt_bind_param($syncStmt, 'ii', $caregiverId, $caregiverId);
            mysqli_stmt_execute($syncStmt);
            mysqli_stmt_close($syncStmt);
        }
    }
}

$adlItems = [
    'feeding' => ['title'=>'1. การรับประทานอาหาร','subtitle'=>'รับประทานอาหารเมื่อเตรียมสำรับไว้ให้เรียบร้อยต่อหน้า','options'=>[0=>'ไม่สามารถตักอาหารเข้าปากได้ ต้องมีคนป้อนให้',1=>'ตักอาหารเองได้แต่ต้องมีคนช่วย เช่น ช่วยเตรียมอาหารให้',2=>'ตักอาหารและช่วยตัวเองได้เป็นปกติ']],
    'grooming' => ['title'=>'2. การดูแลตนเอง','subtitle'=>'ล้างหน้า หวีผม แปรงฟัน โกนหนวด','options'=>[0=>'ต้องการความช่วยเหลือ',1=>'ทำเองได้ รวมทั้งกรณีที่เตรียมอุปกรณ์ไว้ให้']],
    'transfer' => ['title'=>'3. การลุกนั่งและเคลื่อนย้าย','subtitle'=>'ลุกนั่งจากที่นอน หรือจากเตียงไปยังเก้าอี้','options'=>[0=>'ไม่สามารถนั่งได้ หรือต้องใช้คนสองคนช่วยยก',1=>'ต้องการความช่วยเหลืออย่างมาก',2=>'ต้องการความช่วยเหลือบ้างหรือดูแลเพื่อความปลอดภัย',3=>'ทำได้เอง']],
    'toilet_use' => ['title'=>'4. การใช้ห้องน้ำ','subtitle'=>'ใช้ห้องน้ำ','options'=>[0=>'ช่วยตัวเองไม่ได้',1=>'ทำเองได้บ้าง แต่ต้องการความช่วยเหลือบางสิ่ง',2=>'ช่วยตัวเองได้ดี']],
    'mobility' => ['title'=>'5. การเคลื่อนที่','subtitle'=>'การเคลื่อนที่ภายในห้องหรือบ้าน','options'=>[0=>'เคลื่อนที่ไปไหนไม่ได้',1=>'ใช้รถเข็นและเคลื่อนที่ด้วยตนเองได้',2=>'เดินหรือเคลื่อนที่โดยมีคนช่วย',3=>'เดินหรือเคลื่อนที่ได้เอง']],
    'dressing' => ['title'=>'6. การสวมใส่เสื้อผ้า','subtitle'=>'การสวมใส่เสื้อผ้า','options'=>[0=>'ต้องมีคนสวมใส่ให้ ช่วยตัวเองได้น้อย',1=>'ช่วยตัวเองได้ประมาณร้อยละ 50',2=>'ช่วยตัวเองได้ดี']],
    'stairs' => ['title'=>'7. การขึ้นลงบันได','subtitle'=>'การขึ้นลงบันได 1 ชั้น','options'=>[0=>'ไม่สามารถทำได้',1=>'ต้องการคนช่วย',2=>'ขึ้นลงได้เอง']],
    'bathing' => ['title'=>'8. การอาบน้ำ','subtitle'=>'การอาบน้ำ','options'=>[0=>'ต้องมีคนช่วยหรือทำให้',1=>'อาบน้ำเองได้']],
    'bowels' => ['title'=>'9. การกลั้นอุจจาระ','subtitle'=>'การกลั้นการถ่ายอุจจาระในระยะ 1 สัปดาห์ที่ผ่านมา','options'=>[0=>'กลั้นไม่ได้ หรือต้องสวนอุจจาระอยู่เสมอ',1=>'กลั้นไม่ได้บางครั้ง',2=>'กลั้นได้เป็นปกติ']],
    'bladder' => ['title'=>'10. การกลั้นปัสสาวะ','subtitle'=>'การกลั้นปัสสาวะในระยะ 1 สัปดาห์ที่ผ่านมา','options'=>[0=>'กลั้นไม่ได้ หรือใส่สายสวนแต่ดูแลเองไม่ได้',1=>'กลั้นไม่ได้บางครั้ง',2=>'กลั้นได้เป็นปกติ']],
];

$caregiverOptions = ['ไม่มี ลูกญาติตกทอดทิ้ง', 'ไม่มี อยู่ตามลำพังไม่มีญาติ', 'มี ครอบครัวดูแล', 'มี เพื่อนบ้านดูแล'];
$welfareOptions = ['ไม่ได้รับ', 'ได้รับ', 'ไม่ทราบ'];
$clubOptions = ['ไม่ได้เป็น', 'ชมรมผู้สูงอายุ', 'คลังปัญญา', 'ชมรมผู้สูงอายุและคลังปัญญา', 'อื่นๆ'];

function adlGroupCaregiver(int $score): string
{
    if ($score >= 12) return 'กลุ่มติดสังคม';
    if ($score >= 5) return 'กลุ่มติดบ้าน';
    return 'กลุ่มติดเตียง';
}
function postNullableFloat(string $name): ?float {
    $v = trim((string)($_POST[$name] ?? ''));
    return $v === '' ? null : (float)$v;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $error === '') {
    $adlId = (int)($_POST['adl_id'] ?? 0);
    $scores = [];
    $total = 0;
    foreach ($adlItems as $key => $item) {
        $raw = $_POST['cg_'.$key] ?? null;
        if ($raw === null || $raw === '' || !array_key_exists((int)$raw, $item['options'])) {
            $error = 'กรุณาประเมิน ADL ให้ครบทั้ง 10 ข้อ';
            break;
        }
        $scores[$key] = (int)$raw;
        $total += $scores[$key];
    }

    $regular = trim((string)($_POST['regular_caregiver'] ?? ''));
    $welfare = trim((string)($_POST['welfare_status'] ?? ''));
    $club = trim((string)($_POST['club_membership'] ?? ''));
    $note = trim((string)($_POST['note'] ?? ''));

    if ($error === '' && ($adlId <= 0)) $error = 'ไม่พบรายการประเมินที่เลือก';
    if ($error === '' && (!in_array($regular, $caregiverOptions, true) || !in_array($welfare, $welfareOptions, true) || !in_array($club, $clubOptions, true))) {
        $error = 'กรุณาตอบแบบสอบถามเพิ่มเติมให้ครบทั้ง 3 ข้อ';
    }

    if ($error === '') {
        $healthDate = trim((string)($_POST['health_assessment_date'] ?? '')) ?: date('Y-m-d');
        $hWeight = postNullableFloat('health_weight_kg');
        $hWaist = postNullableFloat('health_waist_cm');
        $hHip = postNullableFloat('health_hip_cm');
        $hRatio = postNullableFloat('health_waist_hip_ratio');
        $hBodyFat = postNullableFloat('health_body_fat_pct');
        $hVisceral = postNullableFloat('health_visceral_fat');
        $hBmr = postNullableFloat('health_bmr');
        $hBmi = postNullableFloat('health_bmi');
        $hBodyAge = postNullableFloat('health_body_age');
        $hSubTotal = postNullableFloat('health_subfat_total');
        $hSubTrunk = postNullableFloat('health_subfat_trunk');
        $hSubArms = postNullableFloat('health_subfat_arms');
        $hSubLegs = postNullableFloat('health_subfat_legs');
        $hMuscleTotal = postNullableFloat('health_muscle_total');
        $hMuscleTrunk = postNullableFloat('health_muscle_trunk');
        $hMuscleArms = postNullableFloat('health_muscle_arms');
        $hMuscleLegs = postNullableFloat('health_muscle_legs');
        $hFfm = postNullableFloat('health_fat_free_mass');
        $hDtx = postNullableFloat('health_dtx');
        $hBp = trim((string)($_POST['health_bp'] ?? ''));
        $caregiverGroupText = adlGroupCaregiver($total);
        $nextAssessmentRound = 2;
        $roundStmt = mysqli_prepare($conn, "SELECT COALESCE(MAX(assessment_round), 1) + 1 AS next_round FROM caregiver_adl_history WHERE adl_id=?");
        if ($roundStmt) {
            mysqli_stmt_bind_param($roundStmt, 'i', $adlId);
            mysqli_stmt_execute($roundStmt);
            $roundRes = mysqli_stmt_get_result($roundStmt);
            $roundRow = $roundRes ? mysqli_fetch_assoc($roundRes) : null;
            if ($roundRow && !empty($roundRow['next_round'])) $nextAssessmentRound = max(2, (int)$roundRow['next_round']);
            mysqli_stmt_close($roundStmt);
        }

        $sql = "UPDATE adl_assessment SET
            caregiver_feeding=?,caregiver_grooming=?,caregiver_transfer=?,caregiver_toilet_use=?,caregiver_mobility=?,caregiver_dressing=?,caregiver_stairs=?,caregiver_bathing=?,caregiver_bowels=?,caregiver_bladder=?,caregiver_total_score=?,
            caregiver_health_assessment_date=?,caregiver_health_weight_kg=?,caregiver_health_waist_cm=?,caregiver_health_hip_cm=?,caregiver_health_waist_hip_ratio=?,caregiver_health_body_fat_pct=?,caregiver_health_visceral_fat=?,caregiver_health_bmr=?,caregiver_health_bmi=?,caregiver_health_body_age=?,caregiver_health_subfat_total=?,caregiver_health_subfat_trunk=?,caregiver_health_subfat_arms=?,caregiver_health_subfat_legs=?,caregiver_health_muscle_total=?,caregiver_health_muscle_trunk=?,caregiver_health_muscle_arms=?,caregiver_health_muscle_legs=?,caregiver_health_fat_free_mass=?,caregiver_health_dtx=?,caregiver_health_bp=?,
            regular_caregiver=?,welfare_status=?,club_membership=?,note=?,handoff_status='ส่งผลกลับหมอแล้ว',caregiver_completed_at=NOW(),result_returned_to_doctor=1,result_returned_at=NOW()
            WHERE adl_id=? AND caregiver_user_id=?";
        $stmt = mysqli_prepare($conn, $sql);
        if ($stmt) {
            $types = 'iiiiiiiiiii' . 's' . str_repeat('d', 19) . 'sssssii';
            mysqli_stmt_bind_param($stmt, $types,
                $scores['feeding'],$scores['grooming'],$scores['transfer'],$scores['toilet_use'],$scores['mobility'],$scores['dressing'],$scores['stairs'],$scores['bathing'],$scores['bowels'],$scores['bladder'],$total,
                $healthDate,$hWeight,$hWaist,$hHip,$hRatio,$hBodyFat,$hVisceral,$hBmr,$hBmi,$hBodyAge,$hSubTotal,$hSubTrunk,$hSubArms,$hSubLegs,$hMuscleTotal,$hMuscleTrunk,$hMuscleArms,$hMuscleLegs,$hFfm,$hDtx,$hBp,
                $regular,$welfare,$club,$note,$adlId,$caregiverId
            );
            if (mysqli_stmt_execute($stmt)) {
                $historySql = "INSERT INTO caregiver_adl_history (
                    adl_id, patient_id, caregiver_user_id, assessment_round, assessed_at,
                    doctor_total_score, caregiver_total_score, caregiver_group,
                    feeding, grooming, transfer_score, toilet_use, mobility, dressing, stairs, bathing, bowels, bladder,
                    health_assessment_date, health_weight_kg, health_waist_cm, health_hip_cm, health_waist_hip_ratio,
                    health_body_fat_pct, health_visceral_fat, health_bmr, health_bmi, health_body_age,
                    health_subfat_total, health_subfat_trunk, health_subfat_arms, health_subfat_legs,
                    health_muscle_total, health_muscle_trunk, health_muscle_arms, health_muscle_legs,
                    health_fat_free_mass, health_dtx, health_bp,
                    regular_caregiver, welfare_status, club_membership, note
                )
                SELECT 
                    adl_id, patient_id, caregiver_user_id, ?, NOW(),
                    total_score, caregiver_total_score, ?,
                    caregiver_feeding, caregiver_grooming, caregiver_transfer, caregiver_toilet_use, caregiver_mobility,
                    caregiver_dressing, caregiver_stairs, caregiver_bathing, caregiver_bowels, caregiver_bladder,
                    caregiver_health_assessment_date, caregiver_health_weight_kg, caregiver_health_waist_cm, caregiver_health_hip_cm, caregiver_health_waist_hip_ratio,
                    caregiver_health_body_fat_pct, caregiver_health_visceral_fat, caregiver_health_bmr, caregiver_health_bmi, caregiver_health_body_age,
                    caregiver_health_subfat_total, caregiver_health_subfat_trunk, caregiver_health_subfat_arms, caregiver_health_subfat_legs,
                    caregiver_health_muscle_total, caregiver_health_muscle_trunk, caregiver_health_muscle_arms, caregiver_health_muscle_legs,
                    caregiver_health_fat_free_mass, caregiver_health_dtx, caregiver_health_bp,
                    regular_caregiver, welfare_status, club_membership, note
                FROM adl_assessment WHERE adl_id=? LIMIT 1";
                $historyStmt = mysqli_prepare($conn, $historySql);
                if ($historyStmt) {
                    mysqli_stmt_bind_param($historyStmt, 'isi', $nextAssessmentRound, $caregiverGroupText, $adlId);
                    mysqli_stmt_execute($historyStmt);
                    mysqli_stmt_close($historyStmt);
                }
                $message = 'เสร็จสิ้นแล้ว';

                // อ่านข้อมูลรายการที่เพิ่งส่งกลับ เพื่อแสดงรายละเอียดให้แคร์กิฟเวอร์ตรวจสอบทันที
                $detailSql = "SELECT a.adl_id,a.caregiver_total_score,a.handoff_status,a.result_returned_at,a.regular_caregiver,a.welfare_status,a.club_membership,a.note,
                                     a.caregiver_completed_at,
                                     p.Fullname,
                                     d.display_name AS doctor_name,d.username AS doctor_username,
                                     cg.display_name AS caregiver_name,cg.username AS caregiver_username
                              FROM adl_assessment a
                              JOIN patient p ON p.Patient_id=a.patient_id
                              LEFT JOIN users d ON d.user_id=a.doctor_user_id AND d.role='doctor'
                              LEFT JOIN users cg ON cg.user_id=a.caregiver_user_id AND cg.role='caregiver'
                              WHERE a.adl_id=? AND a.caregiver_user_id=? LIMIT 1";
                $detailStmt = mysqli_prepare($conn, $detailSql);
                if ($detailStmt) {
                    mysqli_stmt_bind_param($detailStmt, 'ii', $adlId, $caregiverId);
                    mysqli_stmt_execute($detailStmt);
                    $detailRes = mysqli_stmt_get_result($detailStmt);
                    $sentDetails = $detailRes ? mysqli_fetch_assoc($detailRes) : null;
                    mysqli_stmt_close($detailStmt);
                }
            } else $error = 'บันทึกไม่สำเร็จ: '.mysqli_stmt_error($stmt);
            mysqli_stmt_close($stmt);
        } else $error = 'ไม่สามารถเตรียมคำสั่งบันทึกได้: '.mysqli_error($conn);
    }
}

$rows = [];
if ($error === '' || $message !== '') {
    $sql = "SELECT a.*,p.Fullname,p.Age,p.Gender,p.Height_cm,p.Weight_kg,v.villagename,
                   d.username AS doctor_username,d.display_name AS doctor_name
            FROM adl_assessment a
            JOIN patient p ON p.Patient_id=a.patient_id
            LEFT JOIN village v ON v.village_id=p.Village_id
            LEFT JOIN users d ON d.user_id=a.doctor_user_id AND d.role='doctor'
            WHERE a.caregiver_user_id=?
            ORDER BY CASE WHEN a.handoff_status IN ('ประเมินต่อแล้ว','ส่งผลกลับหมอแล้ว','ส่งผลกลับแพทย์แล้ว') THEN 1 ELSE 0 END,a.assessment_date DESC,a.adl_id DESC";
    $stmt = mysqli_prepare($conn, $sql);
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'i', $caregiverId); mysqli_stmt_execute($stmt);
        $res = mysqli_stmt_get_result($stmt); while ($r=mysqli_fetch_assoc($res)) $rows[]=$r; mysqli_stmt_close($stmt);
    }
}
$historyStatsByAdl = [];
$selectedHistory = [];
if ($rows) {
    $historyStatSql = "SELECT adl_id, COUNT(*) AS history_count, MAX(assessment_round) AS latest_round, MAX(assessed_at) AS latest_assessed_at FROM caregiver_adl_history GROUP BY adl_id";
    $historyStatRes = mysqli_query($conn, $historyStatSql);
    if ($historyStatRes) {
        while ($h = mysqli_fetch_assoc($historyStatRes)) {
            $historyStatsByAdl[(int)$h['adl_id']] = $h;
        }
    }
    foreach ($rows as &$rowRef) {
        $stat = $historyStatsByAdl[(int)$rowRef['adl_id']] ?? null;
        $rowRef['history_count'] = (int)($stat['history_count'] ?? 0);
        $rowRef['latest_round'] = (int)($stat['latest_round'] ?? ($rowRef['caregiver_total_score'] !== null ? 2 : 1));
        $rowRef['latest_assessed_at'] = $stat['latest_assessed_at'] ?? ($rowRef['caregiver_completed_at'] ?? null);
    }
    unset($rowRef);
}
$selectedId=(int)($_GET['adl_id']??0); $selected=null;
foreach($rows as $r){ if((int)$r['adl_id']===$selectedId){$selected=$r;break;} }
if ($selectedId > 0) {
    $historyStmt = mysqli_prepare($conn, "SELECT * FROM caregiver_adl_history WHERE adl_id=? ORDER BY assessment_round DESC, assessed_at DESC, history_id DESC");
    if ($historyStmt) {
        mysqli_stmt_bind_param($historyStmt, 'i', $selectedId);
        mysqli_stmt_execute($historyStmt);
        $historyRes = mysqli_stmt_get_result($historyStmt);
        while ($historyRes && ($historyRow = mysqli_fetch_assoc($historyRes))) $selectedHistory[] = $historyRow;
        mysqli_stmt_close($historyStmt);
    }
}
$selectedNextRound = $selected ? max(2, (int)($selected['latest_round'] ?? 1) + 1) : 2;
$requestedStep = (int)($_GET['step'] ?? 1);
if ($requestedStep < 1) $requestedStep = 1;
if ($formOnly && $requestedStep > 2) $requestedStep = 2;
if (!$formOnly && $requestedStep > 3) $requestedStep = 3;
$showSuccessScreen = $message !== '' && $sentDetails !== null;

$totalAssessments = count($rows);
$doneAssessments = 0;
foreach ($rows as $__rowCount) {
    if (in_array(($__rowCount['handoff_status'] ?? ''), ['ประเมินต่อแล้ว','ส่งผลกลับหมอแล้ว','ส่งผลกลับแพทย์แล้ว'], true)) {
        $doneAssessments++;
    }
}
$pendingAssessments = max(0, $totalAssessments - $doneAssessments);
$totalHistoryRecords = 0;
foreach ($rows as $__histRow) $totalHistoryRecords += (int)($__histRow['history_count'] ?? 0);
$pendingRows = [];
$doneRows = [];
foreach ($rows as $__row) {
    if (in_array(($__row['handoff_status'] ?? ''), ['ประเมินต่อแล้ว','ส่งผลกลับหมอแล้ว','ส่งผลกลับแพทย์แล้ว'], true)) {
        $doneRows[] = $__row;
    } else {
        $pendingRows[] = $__row;
    }
}
?>
<!doctype html>
<html lang="th"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>แบบประเมิน | <?= e(appName()) ?></title><?php renderPastelTheme(); ?>
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Thai:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<style>
.adl-forward-wrap{display:grid;gap:18px}.handoff-card{background:#fff;border:1px solid #d9ebe5;border-radius:20px;box-shadow:0 10px 28px rgba(43,91,74,.06);overflow:hidden}.handoff-head{padding:22px 24px;border-bottom:1px solid #edf3f0}.handoff-head h2{margin:0;color:#203d33;font-size:22px}.handoff-head p{margin:6px 0 0;color:#6e8078}.handoff-list{display:grid;gap:10px;padding:18px}.handoff-item{display:grid;grid-template-columns:minmax(220px,1fr) 120px 150px 120px 150px 130px;gap:14px;align-items:center;padding:15px 16px;border:1px solid #deece7;border-radius:14px;background:#fbfefd}.patient-name{font-weight:800;color:#203d33}.meta{font-size:12px;color:#7b8c85;margin-top:4px}.score{font-size:22px;font-weight:900;color:#255d4b;text-align:center}.score-label{display:block;font-size:11px;color:#7b8c85;font-weight:700;margin-bottom:3px}.group{font-weight:800;color:#46675b;text-align:center}.caregiver-score{color:#4b6f68}.badge{display:inline-flex;padding:7px 10px;border-radius:999px;background:#eaf8f3;color:#2b6652;font-size:12px;font-weight:800}.badge.done{background:#eef1f0;color:#68766f}.btn-go,.btn-next,.btn-back,.btn-save{display:inline-flex;justify-content:center;align-items:center;text-decoration:none;padding:11px 18px;border-radius:11px;font:inherit;font-weight:800;cursor:pointer}.btn-go,.btn-next,.btn-save{border:0;background:#61c2c6;color:#fff}.btn-back{border:1px solid #cfe2dc;background:#fff;color:#315d50}.assessment-card{padding:22px 24px}.stepper{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin:0 0 22px}.step-pill{padding:12px;border:1px solid #dcebe6;border-radius:13px;background:#f8fbfa;text-align:center;font:inherit;font-weight:800;color:#70817b;cursor:pointer;width:100%}.step-pill.active{background:#dff5f2;border-color:#9fded8;color:#24584d}.step{display:none}.step.active{display:block}.adl-q{padding:18px 0;border-top:1px solid #edf3f0}.adl-q:first-child{border-top:0}.adl-q h3{margin:0 0 4px;color:#203d33;font-size:17px}.adl-sub{color:#71827c;font-size:13px;margin:0 0 12px}.score-options{display:grid;gap:8px}.score-opt{display:flex;align-items:flex-start;gap:10px;padding:10px 12px;border:1px solid #e2ece8;border-radius:11px}.score-opt:hover{background:#f7fcfa}.score-num{font-weight:900;color:#286553;min-width:24px}.health-title{font-size:20px;font-weight:900;color:#203d33;margin-bottom:5px}.health-note{color:#70817b;margin-bottom:16px}.health-table-wrap{overflow:auto;border:1px solid #dce9e5;border-radius:14px}.health-table{width:100%;border-collapse:collapse;min-width:820px}.health-table th,.health-table td{border-bottom:1px solid #e4eeeb;padding:10px 11px;text-align:left;vertical-align:middle}.health-table th{background:#f0faf7;color:#284d42}.health-table input{width:100%;box-sizing:border-box;border:1px solid #d5e5e0;border-radius:8px;padding:8px}.health-group td{font-weight:900;background:#f8fbfa;color:#315d50}.summary{display:flex;gap:12px;flex-wrap:wrap;margin-bottom:20px}.summary-box{padding:12px 16px;border-radius:14px;background:#f4fbf8;border:1px solid #d8ece4;min-width:130px}.summary-box strong{display:block;font-size:22px;color:#244e40}.q{padding:18px 0;border-top:1px solid #edf3f0}.q h3{margin:0 0 12px;font-size:17px;color:#203d33}.opts{display:flex;flex-wrap:wrap;gap:12px 22px}.opt{display:flex;gap:8px;align-items:center}.note{width:100%;min-height:100px;border:1px solid #d8e7e1;border-radius:12px;padding:12px;font:inherit;box-sizing:border-box}.actions{display:flex;justify-content:space-between;gap:10px;margin-top:22px}.actions.right{justify-content:flex-end}.notice{padding:12px 15px;border-radius:12px;margin-bottom:16px}.ok{background:#eaf8ef;color:#2b624a}.err{background:#fff0f0;color:#9b3434}.empty{padding:34px;text-align:center;color:#75877f}.mini-info{display:flex;gap:18px;flex-wrap:wrap;margin:0 0 18px;color:#587168}.mini-info b{color:#23483d}@media(max-width:820px){.handoff-item{grid-template-columns:1fr}.score{text-align:left}.stepper{grid-template-columns:1fr}.actions{flex-wrap:wrap}}

/* ===== Formal healthcare assessment presentation ===== */
.formal-page-head{margin-bottom:20px;padding:20px 24px;background:#fff;border:1px solid #d9e8e4;border-radius:18px;box-shadow:0 6px 18px rgba(38,75,65,.05)}
.formal-page-title{display:flex;align-items:center;gap:14px}
.formal-title-mark{width:5px;height:44px;border-radius:999px;background:#55b9b7}
.formal-page-title h1{margin:0;color:#193f3d;font-size:26px;font-weight:800;letter-spacing:-.2px}
.formal-title-line{width:54px;height:2px;background:#9dd8d3;margin-top:9px;border-radius:999px}
.formal-card{border-color:#d8e7e2;box-shadow:0 8px 24px rgba(38,75,65,.05)}
.formal-section-head{display:flex;align-items:center;justify-content:space-between;gap:16px;padding:22px 24px;background:#fbfefd;border-bottom:1px solid #e4efec}
.formal-section-head h2{margin:3px 0 0;font-size:21px;color:#1e4542}
.section-kicker{display:block;font-size:12px;font-weight:800;letter-spacing:.4px;color:#5f8a82;text-transform:uppercase}
.section-rule{width:80px;height:2px;background:#8bcfc8;border-radius:999px}
.handoff-list{padding:20px}
.handoff-item{border-color:#dfece8;background:#fff;border-radius:16px;padding:17px 18px;box-shadow:0 2px 8px rgba(37,78,66,.03)}
.patient-name{font-size:16px;color:#173f3b}
.score{font-size:20px;color:#255e57}
.score-label{color:#768b85;letter-spacing:.1px}
.group{color:#365d57}
.btn-go,.btn-save{background:#56b8ba;border-radius:10px;box-shadow:none;transition:.16s ease}
.btn-go:hover,.btn-save:hover{background:#459fa2;transform:translateY(-1px)}
.badge{border:1px solid #cfe6df;background:#eef8f5;color:#35665a}
.badge.done{background:#f3f5f4;color:#68766f;border-color:#dfe6e3}
.formal-assessment{padding:0;overflow:hidden}
.assessment-formal-head{display:flex;align-items:center;justify-content:space-between;padding:22px 24px;background:#fbfefd;border-bottom:1px solid #e5efec}
.assessment-formal-head h2{margin:4px 0 0;color:#1d4541;font-size:22px}
.formal-mini-info{margin:0;padding:14px 24px;background:#fff;border-bottom:1px solid #edf3f1;gap:12px 22px}
.formal-mini-info span{padding:7px 10px;border:1px solid #e0ebe8;border-radius:9px;background:#fbfefd;color:#607872}
.formal-mini-info b{color:#244e48}
.stepper{margin:0;padding:18px 24px 20px;background:#fff;border-bottom:1px solid #edf3f1}
.step-pill{border-radius:10px;background:#f8fbfa;border-color:#d8e8e3;color:#607a74;box-shadow:none;padding:13px 12px}
.step-pill.active{background:#e7f6f3;border-color:#9fd4cc;color:#245a54;box-shadow:inset 0 -2px 0 #5db9b3}
.step{padding:24px}
.adl-q{padding:18px 16px;border:1px solid #e2ece9;border-radius:14px;margin-bottom:12px;background:#fff}
.adl-q:first-child{border-top:1px solid #e2ece9}
.score-opt{border-radius:10px;background:#fbfefd}
.score-opt:hover{background:#f2f9f7;border-color:#c9e1db}
.health-table-wrap{border-radius:12px;border-color:#d9e8e4}
.health-table th{background:#edf7f5;color:#234e48;font-weight:800}
.health-table th,.health-table td{padding:11px 12px}
.health-table input,.note{border-radius:9px}
.summary-box{border-radius:12px;background:#f8fcfb;border-color:#d9e9e4}
.q{padding:18px 0}
.notice{border-radius:10px}
@media(max-width:820px){
  .formal-page-head{padding:16px 18px}.formal-page-title h1{font-size:22px}.formal-title-mark{height:36px}.formal-section-head{padding:18px}.section-rule{display:none}.assessment-formal-head{padding:18px}.formal-mini-info{padding:12px 18px}.stepper{padding:14px 18px}.step{padding:18px}
}

.step-next-actions{display:flex;justify-content:flex-end;margin-top:22px;padding-top:18px;border-top:1px solid #e3ece9}.step-next-btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;min-width:220px;min-height:46px;padding:11px 20px;border:1px solid #356f67;border-radius:9px;background:#3f7d73;color:#fff;font:inherit;font-weight:800;cursor:pointer;transition:.18s ease}.step-next-btn:hover{background:#356f67;transform:translateY(-1px)}.step-next-btn .arrow{font-size:18px;line-height:1}
/* Bottom-navigation workflow: hide old top tabs */
.stepper{display:none!important}
.step-bottom-nav{display:flex;justify-content:flex-end;align-items:center;gap:10px;margin-top:22px;padding-top:18px;border-top:1px solid #e2ece8}
.step-bottom-nav.between{justify-content:space-between}
.step-nav-btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;min-height:46px;padding:0 20px;border-radius:12px;border:1px solid #cfe2dc;background:#fff;color:#315d50;font:inherit;font-weight:800;cursor:pointer}
.step-nav-btn.primary{border-color:#5dbec2;background:#5dbec2;color:#fff;box-shadow:0 7px 16px rgba(64,164,169,.18)}
.step-nav-btn:hover{filter:brightness(.98)}
.return-doctor-note{margin:18px 0 0;padding:14px 16px;border:1px solid #d6e9e4;border-radius:14px;background:#f7fbfa;color:#456861;font-size:13px;line-height:1.65}
.return-doctor-note strong{color:#244f47}
.send-result-card{margin:0 0 18px;padding:18px 20px;border:1px solid #bfe3dc;border-radius:16px;background:#f3fbf9;box-shadow:0 6px 18px rgba(44,111,98,.06)}.send-result-head{display:flex;align-items:center;gap:10px;margin-bottom:14px}.send-result-check{width:34px;height:34px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;background:#5dbbb7;color:#fff;font-weight:900}.send-result-title{font-size:18px;font-weight:900;color:#214f49}.send-result-sub{font-size:12px;color:#6b837d;margin-top:2px}.send-result-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}.send-result-item{padding:11px 13px;border:1px solid #d8ebe6;border-radius:11px;background:#fff}.send-result-item span{display:block;font-size:11px;color:#78908a;margin-bottom:4px}.send-result-item strong{display:block;color:#244f48;font-size:14px}.send-result-wide{grid-column:1/-1}.send-result-status{color:#2f7667!important}@media(max-width:820px){.send-result-grid{grid-template-columns:1fr}}
.patient-search-wrap{padding:16px 18px 0}.patient-search-box{position:relative;max-width:460px}.patient-search-box input{width:100%;height:44px;box-sizing:border-box;border:1px solid #cfe4df;border-radius:12px;background:#fff;padding:0 44px 0 42px;font:inherit;color:#23483d;outline:none;transition:.18s ease}.patient-search-box input:focus{border-color:#61c2c6;box-shadow:0 0 0 3px rgba(97,194,198,.14)}.patient-search-icon{position:absolute;left:14px;top:50%;transform:translateY(-50%);color:#5d8178;font-size:18px;pointer-events:none}.patient-search-clear{position:absolute;right:9px;top:50%;transform:translateY(-50%);width:30px;height:30px;border:0;border-radius:8px;background:transparent;color:#7a918b;font-size:20px;cursor:pointer;display:none}.patient-search-clear:hover{background:#eef8f6;color:#2f6258}.search-result-note{margin-top:7px;font-size:12px;color:#71877f}.search-empty{display:none;margin:4px 18px 18px;padding:24px;text-align:center;border:1px dashed #cfe2dc;border-radius:14px;background:#fbfefd;color:#6f837b}@media(max-width:820px){.patient-search-box{max-width:none}.patient-search-wrap{padding:14px 14px 0}}

.result-form{border:1px solid #d7e9e4;border-radius:18px;background:#fff;overflow:hidden}.result-form-head{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;padding:20px 22px;background:#f3fbf9;border-bottom:1px solid #dcece7}.result-form-head h3{margin:3px 0 4px;font-size:22px;color:#203d33}.result-form-head p{margin:0;color:#6e8078;font-size:13px}.result-preview-note{display:inline-flex;align-items:center;padding:8px 12px;border-radius:999px;background:#eef8f6;color:#416864;font-size:11px;font-weight:800}.result-print-btn{border:1px solid #a9d8d2;background:#fff;color:#2d6258;border-radius:10px;padding:9px 14px;font:inherit;font-weight:800;cursor:pointer;white-space:nowrap}.result-section{padding:18px 22px;border-top:1px solid #edf3f0}.result-section:first-of-type{border-top:0}.result-section-title{font-weight:900;color:#274f46;margin-bottom:12px;font-size:15px}.result-info-grid,.result-health-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px}.result-info,.result-health-grid>div{padding:11px 13px;border:1px solid #dcebe6;border-radius:11px;background:#fbfefd}.result-info span,.result-health-grid span{display:block;font-size:11px;color:#788c85;margin-bottom:4px}.result-info strong,.result-health-grid strong{display:block;color:#244f48;font-size:14px}.result-score-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}.result-score-card{padding:16px;border:1px solid #d7e8e3;border-radius:14px;background:#f8fcfb}.result-score-card.emphasis{background:#eaf8f6;border-color:#b9e2dc}.result-score-card span{display:block;font-size:12px;color:#71867f}.result-score-card strong{display:block;font-size:24px;color:#244f48;margin:5px 0 2px}.result-score-card em{display:block;font-style:normal;color:#587168;font-size:12px}.result-form .q{padding:14px 0}.result-form .q:first-of-type{border-top:0}@media(max-width:980px){.result-info-grid,.result-health-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.result-score-grid{grid-template-columns:1fr}}@media(max-width:620px){.result-form-head{display:block}.result-print-btn{margin-top:12px;width:100%}.result-info-grid,.result-health-grid{grid-template-columns:1fr}}

.google-form-shell{max-width:980px;margin:0 auto;background:#eef9f8;border-radius:16px;padding:0 14px 20px}.google-form-accent{height:10px;background:#58bfc1;border-radius:16px 16px 0 0;margin:0 -14px 14px}.google-form-title-card,.google-question-card,.google-section-card{background:#fff;border:1px solid #d9e8e5;border-radius:13px;margin:0 0 14px;box-shadow:0 1px 2px rgba(35,74,65,.04)}.google-form-title-card{padding:22px 24px;border-top:6px solid #58bfc1}.google-form-title-row{display:flex;justify-content:space-between;gap:18px;align-items:flex-start}.google-form-title-card h3{font-size:28px;margin:4px 0 7px;color:#203d33}.google-form-title-card p{margin:0;color:#657a73;line-height:1.55}.google-required-note{border-top:1px solid #edf3f1;margin-top:18px;padding-top:12px;font-size:12px;color:#74867f}.google-required-note span,.required-star{color:#d93025}.google-question-card{padding:20px 24px}.google-question-title{font-size:17px;font-weight:800;color:#263f38;margin-bottom:15px}.google-info-lines{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px 22px}.google-info-lines>div{border-bottom:1px solid #dfe8e5;padding:2px 0 9px}.google-info-lines span{display:block;color:#778982;font-size:12px;margin-bottom:4px}.google-info-lines strong{font-size:15px;color:#243f37}.google-section-card{overflow:hidden}.google-section-head{background:#5fc2c4;color:#fff;padding:13px 20px;font-size:17px;font-weight:800}.google-section-desc{padding:12px 20px 0;color:#70817b;font-size:13px}.google-section-body{padding:20px}.google-score-summary{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}.google-score-summary>div{border:1px solid #dfe9e6;border-radius:11px;padding:15px;background:#fbfdfd}.google-score-summary>div.current{border-color:#95d8d5;background:#effafa}.google-score-summary span{display:block;font-size:12px;color:#73847e}.google-score-summary strong{display:block;font-size:22px;color:#245247;margin:4px 0}.google-score-summary small{color:#657a73}.google-adl-list{display:grid;gap:12px}.google-adl-card{border:1px solid #dfe8e5;border-radius:12px;padding:17px 18px;background:#fff}.google-adl-question{display:flex;gap:12px;align-items:flex-start}.google-adl-number{width:30px;height:30px;border-radius:50%;background:#e4f6f4;color:#2b7169;display:flex;align-items:center;justify-content:center;font-weight:900;flex:0 0 30px}.google-adl-question h4{margin:2px 0 3px;font-size:16px;color:#213f37}.google-adl-question p{margin:0;color:#75867f;font-size:12px;line-height:1.45}.google-answer-line{display:flex;gap:11px;align-items:flex-start;margin:14px 0 0 42px;padding-top:12px;border-top:1px solid #edf2f0}.google-radio-dot{width:18px;height:18px;border:2px solid #58bfc1;border-radius:50%;position:relative;flex:0 0 18px;margin-top:1px}.google-radio-dot:after{content:'';position:absolute;width:8px;height:8px;background:#58bfc1;border-radius:50%;left:3px;top:3px}.google-answer-text{display:flex;justify-content:space-between;gap:14px;width:100%}.google-answer-text strong{font-size:14px;color:#344d45;font-weight:600}.google-answer-text span{font-size:13px;font-weight:800;color:#2c6c61;white-space:nowrap}.health-lines{grid-template-columns:repeat(4,minmax(0,1fr))}.google-social-questions{display:grid;gap:16px}.google-form-question{border-bottom:1px solid #edf2f0;padding-bottom:18px}.google-form-question:last-child{border-bottom:0;padding-bottom:0}.google-form-question h4{font-size:15px;font-weight:700;margin:0 0 13px;color:#2a413a}.google-radio-options{display:grid;gap:11px}.google-radio-options label{display:flex;align-items:center;gap:10px;cursor:pointer;font-size:14px;color:#3d514b}.google-radio-options input[type=radio]{width:18px;height:18px;accent-color:#58bfc1}.google-long-answer{width:100%;min-height:78px;resize:vertical;border:0;border-bottom:1px solid #98aaa4;border-radius:0;padding:9px 2px;font:inherit;outline:none;box-sizing:border-box;background:transparent}.google-long-answer:focus{border-bottom:2px solid #58bfc1}.google-submit-note{display:flex;gap:10px;align-items:flex-start;background:#fff;border:1px solid #d9e8e5;border-radius:12px;padding:15px 18px;color:#526a62;font-size:13px}.google-submit-note strong{color:#275c52;white-space:nowrap}.google-form-actions{max-width:980px;margin:14px auto 0}.google-submit-btn{background:#58bfc1}.google-submit-btn:hover{background:#47aeb0}@media(max-width:820px){.google-form-title-row{display:block}.google-form-title-row .result-print-btn{margin-top:12px;width:100%}.google-info-lines,.health-lines,.google-score-summary{grid-template-columns:1fr}.google-answer-text{display:block}.google-answer-text span{display:block;margin-top:5px}.google-form-shell{padding-left:8px;padding-right:8px}.google-form-accent{margin-left:-8px;margin-right:-8px}}


/* Google Forms style for caregiver ADL assessment */
.adl-google-shell{max-width:980px;margin:0 auto;background:#eef9f8;padding:14px;border-radius:16px}
.adl-google-topline{height:10px;background:#58bfc1;border-radius:16px 16px 0 0;margin:-14px -14px 14px}
.adl-google-title{background:#fff;border:1px solid #d9e8e5;border-top:6px solid #58bfc1;border-radius:13px;padding:22px 24px;margin-bottom:14px;box-shadow:0 1px 2px rgba(35,74,65,.04)}
.adl-google-title h3{margin:3px 0 8px;font-size:27px;color:#203d33;font-weight:800}
.adl-google-title p{margin:0;color:#657a73;line-height:1.6}
.adl-google-title .doctor-result{margin-top:16px;padding-top:13px;border-top:1px solid #edf3f1;font-size:13px;color:#536d65}
.adl-google-title .doctor-result strong{color:#275c52}
.adl-google-required{margin-top:10px;font-size:12px;color:#74867f}.adl-google-required span{color:#d93025}
.adl-google-question{background:#fff;border:1px solid #d9e8e5;border-radius:13px;padding:20px 24px;margin-bottom:14px;box-shadow:0 1px 2px rgba(35,74,65,.04)}
.adl-google-question:focus-within{border-left:5px solid #58bfc1;padding-left:20px;box-shadow:0 2px 6px rgba(35,74,65,.07)}
.adl-google-question-head{margin-bottom:15px}.adl-google-question-head h3{margin:0 0 5px;font-size:17px;color:#263f38;font-weight:800}.adl-google-question-head .required-star{margin-left:4px;color:#d93025}.adl-google-question-head p{margin:0;color:#75867f;font-size:13px;line-height:1.5}
.adl-google-options{display:grid;gap:4px}.adl-google-option{display:flex;align-items:flex-start;gap:12px;padding:10px 6px;border-radius:8px;cursor:pointer;transition:.15s ease;color:#344d45}.adl-google-option:hover{background:#f7fbfa}.adl-google-option input[type=radio]{width:19px;height:19px;accent-color:#58bfc1;flex:0 0 19px;margin:1px 0 0}.adl-google-option .option-score{font-weight:800;color:#275c52;min-width:72px}.adl-google-option .option-text{line-height:1.45}
.adl-google-footer{display:flex;justify-content:flex-end;align-items:center;padding:4px 2px 0}.adl-google-footer .step-next-btn{min-width:210px;background:#58bfc1;border-color:#58bfc1;border-radius:8px}.adl-google-footer .step-next-btn:hover{background:#47aeb0;border-color:#47aeb0}
@media(max-width:720px){.adl-google-shell{padding:8px}.adl-google-topline{margin:-8px -8px 12px}.adl-google-title,.adl-google-question{padding:18px}.adl-google-title h3{font-size:23px}.adl-google-question:focus-within{padding-left:14px}.adl-google-option{gap:9px}.adl-google-option .option-score{min-width:64px}.adl-google-footer .step-next-btn{width:100%}}

body.adl-submit-success-body{background:linear-gradient(180deg,#F7FBFC 0%,#EFF8F7 100%)}
.adl-submit-success-main{margin:0!important;padding:44px 22px!important;min-height:100vh;display:flex;justify-content:center;align-items:flex-start}
.adl-submit-success-wrap{width:100%;max-width:980px;margin:0 auto}
.adl-submit-success-card{background:#fff;border:1px solid #d6ecea;border-radius:28px;overflow:hidden;box-shadow:0 18px 40px rgba(50,118,121,.10)}
.adl-submit-success-accent{height:10px;background:linear-gradient(90deg,#75CFCA 0%,#55B8BD 100%)}
.adl-submit-success-content{padding:34px 36px 30px}
.adl-submit-success-head{display:flex;align-items:flex-start;gap:22px;margin-bottom:24px}
.adl-submit-success-icon{width:76px;height:76px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#6cc7c9 0%,#56b8bd 100%);color:#fff;font-size:48px;font-weight:900;line-height:1;flex:0 0 76px}
.adl-submit-success-head h1{margin:0 0 10px;font-size:28px;line-height:1.25;color:#1f4f58;font-weight:900}
.adl-submit-success-sub{margin:0;color:#698481;line-height:1.7;font-size:16px}
.adl-submit-success-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px;margin-top:10px}
.adl-submit-success-item{padding:18px 20px;border:1px solid #dcebe7;border-radius:18px;background:#fff}
.adl-submit-success-item span{display:block;font-size:13px;color:#718883;margin-bottom:9px;font-weight:700}
.adl-submit-success-item strong{display:block;font-size:19px;color:#1e5960;line-height:1.4;font-weight:900}
.adl-submit-success-actions{display:flex;gap:14px;justify-content:center;flex-wrap:wrap;margin-top:28px}
.adl-submit-summary-btn,.adl-submit-back-btn{display:inline-flex;align-items:center;justify-content:center;min-width:210px;min-height:46px;padding:0 22px;border-radius:14px;text-decoration:none;font-weight:900;font-size:16px}
.adl-submit-summary-btn{background:linear-gradient(90deg,#75CFCA 0%,#55B8BD 100%);color:#fff;box-shadow:0 7px 15px rgba(68,157,159,.12)}
.adl-submit-summary-btn:hover{background:#459FA7;color:#fff}
.adl-submit-back-btn{background:#fff;color:#1f4f58;border:1px solid #cfe3df}
.adl-submit-back-btn:hover{background:#f7fbfa}
@media(max-width:720px){.adl-submit-success-main{padding:26px 14px!important}.adl-submit-success-content{padding:26px 18px 22px}.adl-submit-success-head{flex-direction:column;align-items:flex-start;gap:14px}.adl-submit-success-icon{width:64px;height:64px;font-size:40px;flex-basis:64px}.adl-submit-success-head h1{font-size:24px}.adl-submit-success-grid{grid-template-columns:1fr}.adl-submit-success-actions{flex-direction:column}.adl-submit-summary-btn,.adl-submit-back-btn{width:100%}}

@media print{.sidebar,.user-topbar,.page-head,.notice,.handoff-card:first-of-type,.step-bottom-nav,.result-print-btn{display:none!important}.main{margin:0!important;padding:0!important}.assessment-card{border:0!important;box-shadow:none!important;padding:0!important}.assessment-formal-head,.formal-mini-info{display:none!important}.step{display:none!important}.step[data-step="3"]{display:block!important}.result-form{border:1px solid #bbb!important}.result-form-head{background:#fff!important}.return-doctor-note{display:none!important}body{background:#fff!important}}

/* ===== Premium ADL Forward List Refresh ===== */
.formal-page-head{
    background:linear-gradient(135deg,#e7f8f5 0%,#edf8fb 100%)!important;
    border:1px solid #d7ece8!important;
    border-radius:28px!important;
    box-shadow:0 20px 50px rgba(36,108,115,.07)!important;
    padding:24px 28px!important;
}
.formal-page-title h1{font-size:34px!important;letter-spacing:-.3px}
.formal-title-line{width:66px!important;height:3px!important;background:linear-gradient(90deg,#58bfc0,#93d8d4)!important}
.formal-title-mark{height:50px!important;width:6px!important;background:linear-gradient(180deg,#58bfc0 0%,#83d5d1 100%)!important;box-shadow:0 10px 20px rgba(88,191,192,.18)}
.section-kicker{color:#5f8a82!important;letter-spacing:.6px!important}
.formal-section-head{
    padding:26px 28px!important;
    background:linear-gradient(180deg,#fbfefe 0%,#f7fcfc 100%)!important;
}
.formal-section-head h2{font-size:30px!important;letter-spacing:-.3px}
.patient-search-wrap{display:flex;justify-content:space-between;align-items:flex-end;gap:16px;flex-wrap:wrap;padding:22px 24px 8px!important}
.patient-search-box{max-width:560px!important;flex:1 1 420px}
.patient-search-box input{
    height:52px!important;border-radius:16px!important;border:1px solid #d6eae7!important;
    background:#fff!important;box-shadow:0 8px 24px rgba(36,108,115,.05)!important;
    padding:0 48px 0 46px!important;font-size:15px!important
}
.patient-search-icon{left:16px!important;font-size:18px!important;color:#78a09a!important}
.search-result-note{margin-top:10px!important;font-size:13px!important;color:#6b8782!important;font-weight:600}
.adl-dashboard-stats{
    display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;padding:6px 24px 18px;
}
.adl-stat-card{
    position:relative;overflow:hidden;background:linear-gradient(135deg,#ffffff 0%,#f7fcfc 100%);border:1px solid #d9ebe8;
    border-radius:20px;padding:18px 18px 16px;box-shadow:0 12px 30px rgba(36,108,115,.06)
}
.adl-stat-card:before{content:'';position:absolute;left:0;top:0;width:100%;height:4px;background:linear-gradient(90deg,#58bfc0,#9adfdb)}
.adl-stat-card.pending:before{background:linear-gradient(90deg,#f2b766,#f6d79b)}
.adl-stat-card.success:before{background:linear-gradient(90deg,#68c7a5,#92dfbe)}
.adl-stat-label{font-size:12px;font-weight:800;letter-spacing:.4px;color:#698680;text-transform:uppercase}
.adl-stat-value{margin-top:8px;font-size:34px;line-height:1;font-weight:900;color:#1e5960}
.adl-stat-sub{margin-top:8px;font-size:13px;color:#77908b}
.assessment-sections{display:grid;gap:18px;padding:6px 24px 24px!important}
.assessment-section{background:linear-gradient(180deg,#ffffff 0%,#fbfefe 100%);border:1px solid #dcecea;border-radius:22px;box-shadow:0 10px 24px rgba(36,108,115,.04);overflow:hidden}
.assessment-section-head{display:flex;justify-content:space-between;align-items:center;gap:14px;padding:18px 24px 10px}
.assessment-section-title{display:flex;align-items:center;gap:10px;min-width:0}
.assessment-section-dot{width:12px;height:12px;border-radius:999px;flex:0 0 12px}
.assessment-section.pending .assessment-section-dot{background:#efc06d}
.assessment-section.done .assessment-section-dot{background:#72c8ab}
.assessment-section h3{margin:0;font-size:22px;line-height:1.2;color:#183f45;letter-spacing:-.2px}
.assessment-section-sub{margin-top:4px;font-size:13px;color:#6f8782}
.section-search-wrap{display:flex;align-items:flex-end;justify-content:space-between;gap:16px;flex-wrap:wrap;padding:8px 24px 16px;border-bottom:1px solid #edf4f2}.section-search-wrap .patient-search-box{max-width:560px;flex:1 1 420px}.section-search-wrap .search-result-note{margin:0 0 3px;font-size:13px;color:#6b8782;font-weight:600;white-space:nowrap}.section-search-empty{margin:14px 24px 20px!important}.assessment-section.pending .section-search-wrap .patient-search-box input:focus{border-color:#e9bb69;box-shadow:0 0 0 3px rgba(233,187,105,.14)}.assessment-section.done .section-search-wrap .patient-search-box input:focus{border-color:#72c8ab;box-shadow:0 0 0 3px rgba(114,200,171,.14)}
.section-count-badge{display:inline-flex;align-items:center;justify-content:center;min-height:36px;padding:7px 14px;border-radius:999px;background:#f4fbfb;border:1px solid #d9ece9;color:#285d60;font-size:12px;font-weight:900;white-space:nowrap}
.assessment-section.pending .section-count-badge{background:#fff8eb;border-color:#f0dcc0;color:#9b6f1a}
.assessment-section.done .section-count-badge{background:#eef9f4;border-color:#d0eadf;color:#2f745b}
.section-empty{margin:0 24px 24px!important}
.handoff-list{padding:0 24px 24px!important;gap:14px!important}
.handoff-item{
    position:relative;display:grid!important;grid-template-columns:minmax(260px,1.25fr) repeat(4,minmax(118px,.72fr)) minmax(148px,.9fr)!important;
    gap:14px!important;align-items:stretch!important;padding:18px 18px!important;border-radius:20px!important;
    border:1px solid #dcecea!important;background:linear-gradient(180deg,#ffffff 0%,#fbfefe 100%)!important;box-shadow:0 10px 24px rgba(36,108,115,.05)!important;
    transition:transform .16s ease, box-shadow .16s ease, border-color .16s ease
}
.handoff-item:hover{transform:translateY(-2px);box-shadow:0 18px 30px rgba(36,108,115,.10);border-color:#c6e6e3!important}
.handoff-item.is-pending{border-left:5px solid #efc06d!important}
.handoff-item.is-done{border-left:5px solid #72c8ab!important}
.patient-name{font-size:24px!important;line-height:1.18!important;font-weight:900!important;color:#173f3b!important;margin-bottom:8px}
.meta{font-size:13px!important;line-height:1.45!important;color:#748c87!important;margin-top:4px}
.meta-soft{display:inline-flex;align-items:center;gap:8px;padding:7px 12px;border-radius:999px;background:#f4fbfa;border:1px solid #deedeb;color:#587772;margin-top:10px}
.score,.group{
    display:flex!important;flex-direction:column;justify-content:center;align-items:center;text-align:center!important;
    background:#f9fdfd;border:1px solid #e1efed;border-radius:18px;padding:14px 10px;min-height:108px
}
.score{font-size:18px!important;font-weight:900!important;color:#174f53!important}
.score-label{display:block!important;font-size:12px!important;line-height:1.35!important;margin-bottom:7px!important;color:#728883!important;font-weight:800!important}
.group{font-size:14px!important;font-weight:800!important;color:#365c57!important;line-height:1.45!important}
.caregiver-score{background:linear-gradient(180deg,#effbfb 0%,#ffffff 100%)!important}
.handoff-item > div:last-child{display:flex;flex-direction:column;align-items:flex-end;justify-content:center;gap:10px}
.handoff-item > div:last-child > div{margin-top:0!important}
.badge{padding:8px 12px!important;border-radius:999px!important;font-size:12px!important;font-weight:900!important;border:1px solid #cfe6df!important;background:#fff8eb!important;color:#9b6f1a!important}
.badge.done{background:#eef9f4!important;color:#2f745b!important;border-color:#d0eadf!important}
.btn-go,.btn-save,.btn-next{
    min-height:44px;padding:11px 18px!important;border-radius:14px!important;background:linear-gradient(135deg,#58bfc0 0%,#4aaeb0 100%)!important;
    color:#fff!important;font-weight:900!important;box-shadow:0 10px 20px rgba(88,191,192,.20)!important
}
.btn-go:hover,.btn-save:hover,.btn-next:hover{background:linear-gradient(135deg,#4aaeb0 0%,#419fa2 100%)!important;transform:translateY(-1px)}
.empty{padding:48px 24px!important;border:1px dashed #d6e7e5!important;border-radius:18px!important;background:#fbfefe!important}
.search-empty{margin:0 24px 24px!important;border-radius:18px!important;background:#fbfefe!important}

/* ===== Assessment list redesign: 5-column cards + 10 items pagination ===== */
.assessment-sections{gap:28px!important;padding:10px 24px 24px!important}
.assessment-section{background:transparent!important;border:0!important;border-radius:0!important;box-shadow:none!important;overflow:visible!important}
.assessment-section-head{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:0 0 10px!important;border-bottom:0!important}
.assessment-section-sub{display:none!important}
.section-search-wrap{padding:0 0 14px!important;border-bottom:0!important;align-items:center!important}
.section-search-wrap .patient-search-box{max-width:none!important;flex:1 1 100%!important}
.section-search-wrap .patient-search-box input{height:46px!important;border-radius:12px!important;box-shadow:none!important;background:#fff!important}
.section-search-wrap .search-result-note{display:none!important}
.section-empty,.section-search-empty{margin:0!important}
.search-empty{margin-top:12px!important;border-radius:18px!important;background:#fbfefe!important}

.handoff-list{display:grid!important;grid-template-columns:repeat(5,minmax(0,1fr));gap:14px!important;padding:0!important;align-items:stretch}
.handoff-item{display:flex!important;flex-direction:column!important;gap:12px!important;padding:16px!important;border:1px solid #dbe9e6!important;border-radius:18px!important;background:#fbfefd!important;box-shadow:0 6px 18px rgba(37,78,66,.04)!important;min-width:0;position:relative;overflow:hidden}
.handoff-item::before{content:"";position:absolute;left:0;top:0;right:0;height:4px;background:#5fbfc0}
.handoff-item.is-done::before{background:#7fcfb1}
.handoff-item.is-pending::before{background:#f0c067}
.handoff-item > div:last-child{display:block!important}
.assessment-card-date{display:inline-flex;align-items:center;justify-content:center;min-height:34px;padding:0 12px;border-radius:999px;background:#eef8f8;color:#2b6267;font-size:12px;font-weight:900;align-self:flex-start}
.assessment-card-date.done{background:#eef8f3;color:#2d6a58}
.assessment-card-date.pending{background:#fff6e7;color:#916412}
.patient-name{font-weight:900!important;color:#1f4647!important;font-size:18px!important;line-height:1.35!important}
.meta{font-size:12px!important;line-height:1.5!important;color:#748c87!important;margin-top:2px}
.meta-soft{display:none!important}
.assessment-card-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}
.assessment-stat{padding:10px 11px;border:1px solid #e2efec;border-radius:13px;background:#fff;min-width:0}
.assessment-stat span{display:block;font-size:11px;color:#7a908c;margin-bottom:4px;line-height:1.35}
.assessment-stat strong{display:block;color:#254c50;font-size:13px;line-height:1.45;word-break:break-word}
.assessment-actions{display:flex;flex-direction:column;gap:10px;margin-top:auto;padding-top:4px}
.badge{display:inline-flex!important;align-items:center;justify-content:center;align-self:flex-start;padding:7px 12px!important;border-radius:999px!important;font-size:12px!important;font-weight:900!important;border:1px solid #cfe6df!important;background:#fff8eb!important;color:#9b6f1a!important}
.badge.done{background:#eef9f4!important;color:#2f745b!important;border-color:#d0eadf!important}
.item-action-buttons{display:flex;gap:8px;flex-wrap:wrap;width:100%}
.item-action-buttons a{flex:1 1 calc(50% - 4px)}
.btn-go,.btn-save,.btn-next{min-height:42px;padding:10px 14px!important;border-radius:12px!important;background:linear-gradient(135deg,#58bfc0 0%,#4aaeb0 100%)!important;color:#fff!important;font-weight:900!important;box-shadow:0 10px 20px rgba(88,191,192,.18)!important;text-align:center}
.btn-go:hover,.btn-save:hover,.btn-next:hover{background:linear-gradient(135deg,#4aaeb0 0%,#419fa2 100%)!important;transform:translateY(-1px)}
.btn-secondary-lite{display:inline-flex;align-items:center;justify-content:center;min-height:42px;padding:0 14px;border-radius:12px;border:1px solid #d7e7e2;background:#fff;color:#335f57;text-decoration:none;font-weight:800;font-size:13px;text-align:center}
.btn-secondary-lite:hover{background:#f4faf8}
.list-pagination{display:flex;justify-content:center;align-items:center;gap:10px;flex-wrap:wrap;margin-top:14px;padding:2px 0 4px!important}
.pagination-summary{font-size:12px;color:#6f8782;font-weight:700;white-space:nowrap}
.pagination-controls{display:flex;align-items:center;justify-content:center;gap:8px;flex-wrap:wrap}
.page-btn,.page-number-btn,.page-ellipsis{display:inline-flex;align-items:center;justify-content:center;min-width:38px;height:38px;padding:0 12px;border-radius:10px;border:1px solid #d7e7e2;background:#fff;color:#335f57;text-decoration:none;font-weight:800;font-size:13px;transition:background .16s ease,border-color .16s ease,color .16s ease,opacity .16s ease}
.page-btn:hover,.page-number-btn:hover{background:#f4faf8;border-color:#c9ded7}
.page-btn[disabled],.page-number-btn[disabled]{opacity:.45;cursor:default;pointer-events:none}
.page-number-btn.is-active{background:#5ebfc0;border-color:#5ebfc0;color:#fff}
.page-ellipsis{border-color:transparent;background:transparent;color:#7b918c;min-width:24px;padding:0 2px}
.empty{padding:48px 24px!important;border:1px dashed #d6e7e5!important;border-radius:18px!important;background:#fbfefe!important}
@media(max-width:1500px){.handoff-list{grid-template-columns:repeat(4,minmax(0,1fr))}}
@media(max-width:1240px){.adl-dashboard-stats{grid-template-columns:repeat(2,minmax(0,1fr))}.handoff-list{grid-template-columns:repeat(3,minmax(0,1fr))}}
@media(max-width:920px){.handoff-list{grid-template-columns:repeat(2,minmax(0,1fr))}.assessment-card-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.item-action-buttons a{flex:1 1 100%}}
@media(max-width:700px){.formal-page-head{padding:18px 18px!important;border-radius:22px!important}.formal-page-title h1{font-size:26px!important}.formal-section-head h2{font-size:24px!important}.assessment-sections{padding:6px 16px 18px!important;gap:22px!important}.assessment-section-head{padding:0 0 8px!important;align-items:flex-start!important;flex-direction:column!important}.section-search-wrap{padding:0 0 12px!important;align-items:stretch!important}.handoff-list{grid-template-columns:1fr;padding:0!important}.assessment-card-grid{grid-template-columns:1fr}.item-action-buttons{flex-direction:column}.item-action-buttons a{flex:1 1 100%}.list-pagination{justify-content:center!important}}

.adl-stat-card.history{background:linear-gradient(180deg,#f7fbff 0%,#eef6fd 100%);border-color:#d7e6f1}
.adl-stat-card.history .adl-stat-label{color:#4c6b83}.adl-stat-card.history .adl-stat-value{color:#2a5a83}.adl-stat-card.history .adl-stat-sub{color:#758da0}
.adl-form-page-nav{display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap;margin:4px 24px 16px;padding:12px 14px;border:1px solid #d9ebe8;border-radius:14px;background:#f8fcfb;color:#5d7974;font-size:13px}.adl-form-page-nav strong{color:#214d48}
.selected-assessment-summary{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;padding:18px 24px 0;background:#fff}
.selected-summary-card{padding:16px 18px;border:1px solid #deebe7;border-radius:16px;background:#fbfefd}
.selected-summary-card.emphasis{background:#effafa;border-color:#b9e4df}
.selected-summary-card span{display:block;font-size:12px;color:#6f8884;margin-bottom:5px}.selected-summary-card strong{display:block;font-size:22px;color:#214b48}.selected-summary-card small{display:block;margin-top:6px;color:#6f8580;line-height:1.5}
.assessment-workspace{display:grid;grid-template-columns:minmax(0,1fr);gap:18px;padding:18px 24px 24px;background:#f9fdfc}
.assessment-main-pane{min-width:0}
.assessment-history-pane{min-width:0}
.history-pane-card{height:100%;border:1px solid #dceae6;border-radius:18px;background:#fff;box-shadow:0 6px 18px rgba(37,78,66,.04);overflow:hidden;position:sticky;top:18px}
.history-pane-head{display:flex;justify-content:space-between;align-items:flex-start;gap:12px;padding:20px 20px 14px;border-bottom:1px solid #edf3f0;background:#fbfefd}
.history-pane-head h3{margin:4px 0 6px;color:#1e4542;font-size:20px}.history-pane-head p{margin:0;color:#728680;font-size:13px;line-height:1.65}
.history-total-badge{display:inline-flex;align-items:center;justify-content:center;min-width:84px;padding:9px 12px;border-radius:999px;background:#eef8f5;border:1px solid #cfe6df;color:#35665a;font-weight:900}
.history-timeline{display:grid;gap:12px;padding:16px}
.history-card{border:1px solid #dcebe7;border-radius:16px;background:#fcfefe;padding:15px 15px 14px;box-shadow:0 2px 8px rgba(37,78,66,.03)}
.history-card-top{display:flex;justify-content:space-between;align-items:flex-start;gap:12px}.history-round{font-size:15px;font-weight:900;color:#214d48}.history-date{margin-top:4px;font-size:12px;color:#708681}.history-score-badge{display:inline-flex;align-items:center;justify-content:center;min-width:78px;padding:10px 12px;border-radius:14px;background:#ecf9f7;color:#245d56;font-size:18px;font-weight:900}
.history-card-grid,.history-health-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin-top:14px}.history-card-grid>div,.history-health-grid>div{padding:10px 12px;border:1px solid #e3efec;border-radius:12px;background:#fff}.history-card-grid span,.history-health-grid span{display:block;font-size:11px;color:#7b908b;margin-bottom:4px}.history-card-grid strong,.history-health-grid strong{display:block;color:#244e48;font-size:13px;line-height:1.5}
.history-detail-toggle{margin-top:12px;border-top:1px dashed #d7e7e2;padding-top:10px}.history-detail-toggle summary{cursor:pointer;font-weight:800;color:#315d55;list-style:none}.history-detail-toggle summary::-webkit-details-marker{display:none}.history-note{margin-top:10px;padding:11px 12px;border-radius:12px;background:#f7fbfa;color:#557069;line-height:1.65;font-size:13px}.history-empty{margin:16px}
@media(max-width:1240px){.assessment-workspace{grid-template-columns:1fr}.history-pane-card{position:static}.selected-assessment-summary{grid-template-columns:1fr 1fr}}
@media(max-width:760px){.selected-assessment-summary{grid-template-columns:1fr;padding:16px 16px 0}.assessment-workspace{padding:16px}.history-card-grid,.history-health-grid{grid-template-columns:1fr}}

.section-search-outside{margin:0 0 12px;padding:0;background:transparent}.section-search-outside + .assessment-section{margin-top:0}.section-search-outside .section-search-wrap{padding:0!important;margin:0!important;border:0!important;background:transparent!important}.section-search-outside .patient-search-box{max-width:none!important;flex:1 1 100%!important}.section-search-outside .patient-search-box input{width:100%!important;background:#fff!important}

/* ===== Assessment entry menu — same visual pattern as visit entry ===== */
.adl-entry-wrap{max-width:860px;margin:0 auto;padding:18px 0 34px}
.adl-entry-card{border:1px solid #d8ebe8;border-radius:26px;background:linear-gradient(180deg,#ffffff 0%,#f8fcfb 100%);box-shadow:0 14px 34px rgba(36,108,115,.07);padding:24px}
.adl-entry-head{text-align:center;margin-bottom:20px}.adl-entry-head h1{margin:0;color:#1d4f53;font-size:28px;line-height:1.2}
.adl-patient-select{max-width:580px;margin:0 auto 20px;padding:16px 18px;border:1px solid #d9ebe8;border-radius:20px;background:#f8fcfc}
.adl-patient-select label{display:block;margin-bottom:8px;color:#254f53;font-size:14px;font-weight:900}
.adl-search-box{position:relative}.adl-search-input{width:100%;min-height:48px;padding:0 48px 0 14px;border:1px solid #cfe3e0;border-radius:14px;background:#fff;color:#214e50;font:inherit;font-weight:700;outline:none;box-sizing:border-box}
.adl-search-input:focus{border-color:#59bfc0;box-shadow:0 0 0 3px rgba(89,191,192,.12)}
.adl-search-toggle{position:absolute;top:50%;right:10px;transform:translateY(-50%);width:32px;height:32px;border:none;border-radius:10px;background:#f1f9f8;color:#2b686a;font-size:15px;cursor:pointer}
.adl-search-clear{position:absolute;top:50%;right:46px;transform:translateY(-50%);width:28px;height:28px;border:none;border-radius:999px;background:transparent;color:#7b918d;font-size:17px;cursor:pointer;display:none}.adl-search-clear.is-visible{display:inline-flex;align-items:center;justify-content:center}
.adl-search-options{position:absolute;left:0;right:0;top:calc(100% + 8px);padding:8px;border:1px solid #d9ebe8;border-radius:16px;background:#fff;box-shadow:0 14px 28px rgba(36,108,115,.10);display:none;max-height:260px;overflow:auto;z-index:50}.adl-search-options.is-open{display:block}
.adl-search-option{display:block;width:100%;padding:11px 12px;border:none;border-radius:12px;background:transparent;text-align:left;color:#214e50;font:inherit;font-weight:700;cursor:pointer}.adl-search-option:hover,.adl-search-option.is-active{background:#eef8f7}
.adl-search-empty{padding:11px 12px;border-radius:12px;color:#7a908d;font-size:12px;background:#fbfefe;display:none}.adl-search-empty.is-visible{display:block}.adl-native-select{display:none}
.adl-entry-grid{display:grid;grid-template-columns:repeat(3,minmax(170px,210px));justify-content:center;gap:14px;max-width:680px;margin:0 auto}.adl-entry-link{display:flex;align-items:center;justify-content:center;min-height:74px;padding:12px 14px;border-radius:16px;border:1px solid #d9ebe8;background:#fff;text-decoration:none;transition:.18s ease;box-shadow:0 6px 16px rgba(36,108,115,.05)}
.adl-entry-link:hover{transform:translateY(-2px);box-shadow:0 12px 26px rgba(36,108,115,.10);border-color:#bfe2dd}.adl-entry-link.primary{background:linear-gradient(135deg,#63c4c6 0%,#56b7ba 100%);border-color:#56b7ba}.adl-entry-link.body{background:linear-gradient(135deg,#8ad6d0 0%,#70c7bf 100%);border-color:#70c7bf}.adl-entry-link.history{background:linear-gradient(135deg,#f4f9ff 0%,#fbfdff 100%)}
.adl-entry-label{font-size:17px;font-weight:900;color:#fff;text-align:center;line-height:1.3}.adl-entry-link.history .adl-entry-label{color:#21585c}.adl-entry-link.is-disabled{opacity:.46;pointer-events:none;filter:grayscale(.15)}
@media(max-width:980px){.adl-entry-grid{grid-template-columns:repeat(2,minmax(190px,220px));max-width:460px}}
@media(max-width:760px){.adl-entry-wrap{padding:14px 0 28px}.adl-entry-card{padding:18px;border-radius:22px}.adl-entry-grid{grid-template-columns:1fr;max-width:100%}.adl-entry-link{min-height:68px;padding:12px 16px}.adl-entry-label{font-size:17px}.adl-entry-head h1{font-size:25px}.adl-patient-select{padding:16px}}


.form-only-simple{padding:0!important;overflow:hidden!important}
.form-only-simple .assessment-workspace{padding:22px 24px 26px!important;background:#fff!important}
.form-only-simple .step{padding:0!important}
.form-only-simple .adl-google-shell,.form-only-simple .body-simple-shell{max-width:1120px;margin:0 auto;background:#fff;border:1px solid #dcebe6;border-radius:18px;overflow:hidden;box-shadow:0 8px 22px rgba(37,78,66,.04)}
.form-only-simple .adl-google-title,.form-only-simple .body-simple-head{padding:22px 24px 18px!important}
.form-only-simple .adl-google-title h3,.form-only-simple .body-simple-head h3{margin:6px 0 8px;font-size:20px;color:#1f4747}
.form-only-simple .adl-google-title p,.form-only-simple .body-simple-head p{margin:0;color:#6d8480;line-height:1.6}
.form-only-simple .doctor-result{margin-top:12px}
.form-only-stepper{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;padding:20px 24px 0;background:#fff}
.form-only-stepper .step-pill{display:flex;align-items:center;justify-content:center;min-height:52px;border-radius:14px;border:1px solid #d9ebe5;background:#f8fbfa;color:#56736f;font-weight:900;cursor:pointer}
.form-only-stepper .step-pill.active{background:#e5f7f4;border-color:#97d6cf;color:#245a54;box-shadow:inset 0 -2px 0 #5db9b3}
.body-simple-head{border-bottom:1px solid #edf3f1;background:#fbfefd}
.body-simple-section{padding:20px 24px 22px;border-top:1px solid #edf3f1}
.body-simple-section:first-of-type{border-top:0}
.body-simple-section h4{margin:0 0 8px;color:#1f4747;font-size:18px}
.body-simple-section p{margin:0 0 14px;color:#6d8480;line-height:1.6}
.form-only-simple .google-section-card{margin:0 0 14px;border-radius:16px}
.form-only-simple .google-section-card:last-child{margin-bottom:0}
.form-only-simple .google-submit-note{margin-top:12px}
.form-only-simple .step-bottom-nav{display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-top:18px}
.form-only-simple .step-nav-btn,.form-only-simple .google-submit-btn{display:inline-flex;align-items:center;justify-content:center;min-height:44px;padding:0 18px;border-radius:12px;font-weight:900;text-decoration:none;border:1px solid #d7e7e2;background:#fff;color:#335f57;cursor:pointer}
.form-only-simple .step-nav-btn.primary,.form-only-simple .google-submit-btn{background:linear-gradient(135deg,#58bfc0 0%,#4aaeb0 100%);border-color:#58bfc0;color:#fff}
.form-only-simple .google-submit-btn{border:0}
.form-only-simple .google-social-questions{display:grid;gap:14px}

.form-only-simple .body-simple-section h4{font-size:16px!important;margin-bottom:6px!important}
.form-only-simple .body-simple-section p{font-size:13px!important;color:#718985!important;margin-bottom:14px!important}
.form-only-simple .google-section-card{background:transparent!important;border:0!important;box-shadow:none!important;padding:0!important}
.form-only-simple .google-section-card .google-section-body.google-social-questions{padding:0!important;display:grid!important;gap:16px!important}
.form-only-simple .google-form-question{
    padding:18px 18px 16px!important;border:1px solid #dcebe7!important;border-radius:18px!important;
    background:linear-gradient(180deg,#ffffff 0%,#fbfefe 100%)!important;box-shadow:0 6px 18px rgba(37,78,66,.04)!important
}
.form-only-simple .google-form-question:last-child{padding-bottom:16px!important}
.form-only-simple .google-form-question h4{font-size:18px!important;line-height:1.45!important;margin:0 0 14px!important;color:#1f4f58!important;font-weight:900!important}
.form-only-simple .google-radio-options{display:grid!important;grid-template-columns:repeat(auto-fit,minmax(220px,1fr))!important;gap:10px!important}
.form-only-simple .google-radio-options label{
    display:flex!important;align-items:flex-start!important;gap:10px!important;min-height:54px!important;
    padding:12px 14px!important;border:1px solid #dcebe7!important;border-radius:14px!important;background:#fff!important;
    cursor:pointer!important;transition:all .16s ease!important;line-height:1.5!important
}
.form-only-simple .google-radio-options label:hover{border-color:#b8dfda!important;background:#f7fbfa!important;transform:translateY(-1px)}
.form-only-simple .google-radio-options label:has(input[type=radio]:checked){background:#ecf9f7!important;border-color:#63c0bd!important;box-shadow:inset 0 0 0 1px #63c0bd!important}
.form-only-simple .google-radio-options input[type=radio]{width:18px!important;height:18px!important;margin-top:2px!important;accent-color:#4eb4b0!important;flex:0 0 18px}
.form-only-simple .google-radio-options span{font-size:14px!important;color:#294f49!important}
.form-only-simple .google-long-answer{
    min-height:110px!important;border:1px solid #dcebe7!important;border-radius:14px!important;padding:14px 15px!important;
    background:#fff!important;line-height:1.65!important;font-size:14px!important
}
.form-only-simple .google-long-answer:focus{border:1px solid #63c0bd!important;box-shadow:0 0 0 3px rgba(99,192,189,.14)!important}
@media(max-width:760px){
  .form-only-simple .google-form-question{padding:16px 14px!important}
  .form-only-simple .google-form-question h4{font-size:17px!important}
  .form-only-simple .google-radio-options{grid-template-columns:1fr!important}
}
@media(max-width:760px){
  .form-only-stepper{grid-template-columns:1fr;padding:16px 16px 0}
  .form-only-simple .assessment-workspace{padding:16px!important}
  .form-only-simple .adl-google-title,.form-only-simple .body-simple-head,.body-simple-section{padding-left:16px!important;padding-right:16px!important}
  .form-only-simple .step-bottom-nav{flex-direction:column}
  .form-only-simple .step-nav-btn,.form-only-simple .google-submit-btn{width:100%}
}

/* ===== Caregiver ADL: match doctor assessment visual style ===== */
.form-only-simple .assessment-workspace{padding:0 0 30px!important;background:transparent!important}
.form-only-simple .assessment-main-pane{max-width:none!important;margin:0!important}
.form-only-simple .adl-google-shell{
    max-width:none!important;margin:0!important;padding:0!important;border:0!important;border-radius:0!important;
    background:transparent!important;box-shadow:none!important;overflow:visible!important
}
.form-only-simple .adl-google-topline{display:none!important}
.form-only-simple .adl-google-title{
    margin:0 0 14px!important;padding:18px 20px!important;border:1px solid #d9ebe8!important;border-radius:18px!important;
    background:#fff!important;box-shadow:0 7px 20px rgba(36,108,115,.035)!important
}
.form-only-simple .adl-google-title .section-kicker{display:none!important}
.form-only-simple .adl-google-title h3{margin:0 0 6px!important;font-size:23px!important;color:#1f5251!important}
.form-only-simple .adl-google-title p{font-size:13px!important;line-height:1.55!important;color:#718985!important}
.form-only-simple .adl-google-title .doctor-result{margin-top:12px!important;padding:11px 13px!important;border:1px solid #e1efed!important;border-radius:12px!important;background:#fbfefd!important}
.form-only-simple .adl-google-required{margin-top:8px!important}
.form-only-simple .adl-google-question{
    margin:0 0 14px!important;padding:18px!important;border:1px solid #dcecea!important;border-radius:18px!important;
    background:linear-gradient(180deg,#fff 0%,#fcfefe 100%)!important;box-shadow:0 7px 20px rgba(36,108,115,.035)!important
}
.form-only-simple .adl-google-question:hover{border-color:#c8e7e2!important;box-shadow:0 10px 24px rgba(36,108,115,.055)!important;transform:none!important}
.form-only-simple .adl-google-question:focus-within{padding-left:18px!important;border:1px solid #c8e7e2!important;box-shadow:0 10px 24px rgba(36,108,115,.055)!important}
.form-only-simple .adl-google-question-head{display:block!important;margin-bottom:12px!important}
.form-only-simple .adl-google-question-head h3{margin:0 0 4px!important;font-size:17px!important;line-height:1.35!important;color:#1f5251!important;font-weight:900!important}
.form-only-simple .adl-google-question-head p{margin:0!important;font-size:13px!important;line-height:1.55!important;color:#738a85!important}
.form-only-simple .adl-google-options{display:grid!important;gap:10px!important}
.form-only-simple .adl-google-option{
    display:grid!important;grid-template-columns:24px 32px 1fr!important;align-items:center!important;gap:10px!important;
    min-height:56px!important;padding:11px 14px!important;border:1px solid #deece9!important;border-radius:13px!important;background:#fff!important
}
.form-only-simple .adl-google-option:hover{background:#f4fbfa!important;border-color:#bfe2dc!important}
.form-only-simple .adl-google-option:has(input[type=radio]:checked){background:#edf9f7!important;border-color:#61c2bd!important;box-shadow:inset 0 0 0 1px #61c2bd!important}
.form-only-simple .adl-google-option input[type=radio]{width:18px!important;height:18px!important;margin:0!important;accent-color:#31a98f!important}
.form-only-simple .adl-google-option .option-score{
    display:inline-flex!important;align-items:center!important;justify-content:center!important;min-width:30px!important;width:30px!important;height:30px!important;
    border-radius:9px!important;background:#eef8f6!important;color:#2f716b!important;font-size:15px!important;font-weight:900!important;white-space:nowrap!important
}
.form-only-simple .adl-google-option .option-text{font-size:14px!important;line-height:1.5!important;color:#294e49!important}
.form-only-simple .adl-google-footer{display:flex!important;justify-content:flex-end!important;padding-top:4px!important}
.form-only-simple .adl-google-footer .step-next-btn{min-width:220px!important;min-height:46px!important;border-radius:14px!important}
.form-only-simple .form-only-stepper{margin:0 0 16px!important;padding:0!important;background:transparent!important}
.form-only-simple .form-only-stepper .step-pill{min-height:46px!important;border-radius:14px!important}
.adl-form-page-nav{margin:0 0 16px!important;padding:0!important;border:0!important;background:transparent!important}
.adl-form-page-nav .btn-secondary-lite{min-height:44px!important;padding:0 18px!important;border-radius:14px!important;background:#fff!important;border:1px solid #cfe4e1!important;color:#286465!important;box-shadow:0 8px 18px rgba(36,108,115,.06)!important}
.adl-form-page-nav .btn-secondary-lite:hover{background:#f5fbfa!important}
@media(max-width:760px){
  .form-only-simple .adl-google-question{padding:16px!important}
  .form-only-simple .adl-google-option{grid-template-columns:22px 30px 1fr!important;padding:10px 12px!important}
}

.form-only-simple .assessment-workspace{padding-top:0!important}
.form-only-simple .adl-google-shell{border-top:0!important;border-radius:0 0 18px 18px!important}

/* Clean Body assessment page: hide redundant top switch tabs and intro blocks */
.form-only-simple .form-only-stepper{display:none!important}
.form-only-simple .body-simple-head{display:none!important}
.form-only-simple .body-simple-section:first-of-type{padding-top:18px!important}
.form-only-simple{background:transparent!important;border:0!important;box-shadow:none!important}
.form-only-simple .body-simple-shell{max-width:none!important;margin:0!important;background:transparent!important;border:0!important;box-shadow:none!important;border-radius:0!important}
.form-only-simple .adl-google-shell{max-width:none!important;margin:0!important;box-shadow:none!important}
.body-health-date-wrap{display:none!important}
</style>
<style>
/* PRINT: compact one-page ADL summary */
@page{size:A4 portrait;margin:6mm}
@media print{
  html,body{width:210mm!important;min-height:0!important;margin:0!important;padding:0!important;background:#fff!important}
  body{font-size:9px!important;line-height:1.15!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}
  .main{width:auto!important;max-width:none!important;margin:0!important;padding:0!important}
  .assessment-card{margin:0!important;padding:0!important;border:0!important;box-shadow:none!important}
  .step[data-step="3"]{display:block!important;margin:0!important;padding:0!important}
  #resultSummaryForm.google-form-shell{max-width:none!important;width:100%!important;margin:0!important;padding:0!important;background:#fff!important;border-radius:0!important}
  .google-form-accent{height:4px!important;margin:0 0 4px!important;border-radius:0!important}
  .google-form-title-card,.google-question-card,.google-section-card{margin:0 0 4px!important;border-radius:5px!important;box-shadow:none!important;break-inside:avoid!important;page-break-inside:avoid!important}
  .google-form-title-card{padding:7px 9px!important;border-top-width:3px!important}
  .google-form-title-card h3{font-size:17px!important;margin:1px 0 2px!important;line-height:1.05!important}
  .google-form-title-card p{font-size:8px!important;line-height:1.2!important;margin:0!important}
  .section-kicker{font-size:7px!important}
  .google-required-note{display:none!important}
  .google-question-card{padding:6px 9px!important}
  .google-question-title{font-size:10px!important;margin:0 0 4px!important}
  .google-info-lines{grid-template-columns:repeat(4,minmax(0,1fr))!important;gap:3px 7px!important}
  .google-info-lines>div{padding:1px 0 3px!important}
  .google-info-lines span{font-size:7px!important;margin:0 0 1px!important}
  .google-info-lines strong{font-size:9px!important;line-height:1.15!important}
  .google-section-head{padding:4px 8px!important;font-size:10px!important;line-height:1.1!important}
  .google-section-desc{display:none!important}
  .google-section-body{padding:5px 8px!important}
  .google-score-summary{grid-template-columns:repeat(3,minmax(0,1fr))!important;gap:4px!important}
  .google-score-summary>div{padding:5px 7px!important;border-radius:5px!important}
  .google-score-summary span{font-size:7px!important}
  .google-score-summary strong{font-size:14px!important;margin:1px 0!important;line-height:1!important}
  .google-score-summary small{font-size:7px!important}
  .adl-summary-section .google-section-body{padding:4px 7px!important}
  .google-adl-list{grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:3px 5px!important}
  .google-adl-card{padding:4px 6px!important;border-radius:4px!important;break-inside:avoid!important;page-break-inside:avoid!important}
  .google-adl-question{gap:4px!important;align-items:center!important}
  .google-adl-number{width:16px!important;height:16px!important;flex:0 0 16px!important;font-size:8px!important}
  .google-adl-question h4{font-size:8px!important;margin:0!important;line-height:1.1!important}
  .google-adl-question p{display:none!important}
  .google-answer-line{margin:2px 0 0 20px!important;padding-top:2px!important;gap:3px!important}
  .google-radio-dot{display:none!important}
  .google-answer-text{display:flex!important;gap:4px!important;align-items:center!important}
  .google-answer-text strong{font-size:7px!important;line-height:1.05!important;font-weight:600!important;overflow:hidden!important;text-overflow:ellipsis!important;white-space:nowrap!important}
  .google-answer-text span{font-size:7px!important;margin:0!important;white-space:nowrap!important}
  .health-lines{grid-template-columns:repeat(4,minmax(0,1fr))!important;gap:3px 7px!important}
  .google-social-questions{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:3px 8px!important}
  .google-form-question{padding:0 0 3px!important;border-bottom:0!important;min-width:0!important}
  .google-form-question h4{font-size:8px!important;margin:0 0 2px!important;line-height:1.1!important}
  .google-radio-options{gap:0!important}
  .google-radio-options label{font-size:8px!important;line-height:1.1!important;gap:3px!important}
  .google-radio-options label:has(input:not(:checked)){display:none!important}
  .google-radio-options input[type=radio]{display:none!important}
  .google-long-answer{min-height:15px!important;height:15px!important;font-size:8px!important;padding:1px!important;overflow:hidden!important}
  .google-submit-note{padding:4px 7px!important;margin:0!important;border-radius:4px!important;font-size:7px!important;line-height:1.15!important;gap:4px!important;break-inside:avoid!important;page-break-inside:avoid!important}
  .google-submit-note strong{font-size:7px!important}
  .google-form-actions{display:none!important}
}
</style>


<style>
/* FORMAL PRINT REPORT — official / clinical document appearance */
@media print{
  :root{--formal-ink:#1f2933;--formal-navy:#244a5a;--formal-line:#9ba8ad;--formal-soft:#f3f6f7}
  #resultSummaryForm.google-form-shell{font-family:"Noto Sans Thai",sans-serif!important;color:var(--formal-ink)!important}
  .google-form-accent{display:none!important}
  .google-form-title-card{border:1.2px solid var(--formal-navy)!important;border-top:4px solid var(--formal-navy)!important;border-radius:0!important;padding:7px 10px!important;text-align:center!important;background:#fff!important}
  .google-form-title-row{display:block!important}
  .google-form-title-card .section-kicker{display:block!important;color:#4b5d64!important;font-size:7px!important;font-weight:700!important;letter-spacing:.3px!important;text-transform:none!important}
  .google-form-title-card h3{font-size:14px!important;line-height:1.12!important;color:#183a46!important;margin:2px 0 2px!important;font-weight:800!important}
  .google-form-title-card p{font-size:7px!important;color:#4f5f65!important;line-height:1.2!important}

  .google-question-card,.google-section-card{border:1px solid #aab6ba!important;border-radius:0!important;background:#fff!important}
  .google-question-title,.google-section-head{background:var(--formal-navy)!important;color:#fff!important;border-radius:0!important;font-weight:800!important;letter-spacing:.15px!important}
  .google-question-title{margin:-6px -9px 5px!important;padding:4px 8px!important;font-size:9px!important}
  .google-section-head{padding:4px 8px!important;font-size:9px!important}
  .google-section-body{background:#fff!important}

  .google-info-lines>div,.health-lines>div{border-bottom:1px solid #c8d0d3!important;padding:1px 0 2px!important}
  .google-info-lines span,.health-lines span{color:#65747a!important;font-weight:600!important}
  .google-info-lines strong,.health-lines strong{color:#1c2f36!important;font-weight:700!important}

  .google-score-summary>div{border:1px solid #b8c2c6!important;border-radius:0!important;background:#fff!important;text-align:center!important}
  .google-score-summary>div.current{background:var(--formal-soft)!important;border-color:#7f959d!important}
  .google-score-summary span{color:#5b6c72!important;font-weight:700!important}
  .google-score-summary strong{color:#173f4d!important;font-weight:800!important}
  .google-score-summary small{color:#4e5e64!important}

  .google-adl-card{border:1px solid #c1c9cc!important;border-radius:0!important;background:#fff!important}
  .google-adl-number{background:#e9eef0!important;color:#183f4d!important;border:1px solid #aebbc0!important;border-radius:50%!important;font-weight:800!important}
  .google-adl-question h4{color:#1f333b!important;font-weight:800!important}
  .google-answer-line{border-top:1px dotted #c8d0d3!important}
  .google-answer-text strong{color:#33464d!important}
  .google-answer-text span{color:#173f4d!important;font-weight:700!important}

  .google-form-question h4{color:#263b43!important;font-weight:800!important}
  .google-long-answer{border:0!important;border-bottom:1px solid #aeb8bc!important;border-radius:0!important;background:#fff!important;color:#263b43!important}
  .required-star{display:none!important}

  .google-submit-note{border:1px solid #9ba8ad!important;border-radius:0!important;background:#f7f9f9!important;color:#3f5056!important}
  .google-submit-note strong{color:#173f4d!important}

  /* Keep the formal report on one A4 page */
  .google-form-title-card,.google-question-card,.google-section-card,.google-submit-note{margin-bottom:3px!important}
  .google-adl-list{gap:2px 4px!important}
  .google-adl-card{padding:3px 5px!important}
  .google-section-body{padding:4px 7px!important}
}


/* ===== ADL FORM VISUAL REFINEMENT ===== */
.formal-assessment{
    background:transparent!important;
    border:0!important;
    box-shadow:none!important;
    overflow:visible!important;
}
.assessment-formal-head{
    padding:22px 28px 16px!important;
    background:#fff!important;
    border:1px solid #d8ebe8!important;
    border-bottom:0!important;
    border-radius:22px 22px 0 0!important;
}
.assessment-formal-head h2{
    margin:4px 0 0!important;
    font-size:27px!important;
    line-height:1.25!important;
    color:#173f45!important;
}
.section-kicker{
    color:#6f8a86!important;
    font-size:12px!important;
    font-weight:900!important;
    letter-spacing:.08em!important;
}
.formal-mini-info{
    display:flex!important;
    flex-wrap:wrap!important;
    gap:10px!important;
    padding:14px 28px 16px!important;
    background:#fff!important;
    border-left:1px solid #d8ebe8!important;
    border-right:1px solid #d8ebe8!important;
    border-bottom:1px solid #e8f1ef!important;
}
.formal-mini-info span{
    padding:8px 12px!important;
    border:1px solid #dcecea!important;
    border-radius:999px!important;
    background:#f8fcfb!important;
    color:#617b77!important;
    font-size:13px!important;
}
.formal-mini-info b{color:#214d50!important}
.selected-assessment-summary{
    grid-template-columns:repeat(3,minmax(0,1fr))!important;
    gap:14px!important;
    padding:18px 28px 22px!important;
    background:#fff!important;
    border-left:1px solid #d8ebe8!important;
    border-right:1px solid #d8ebe8!important;
    border-bottom:1px solid #d8ebe8!important;
    border-radius:0 0 22px 22px!important;
}
.selected-summary-card{
    padding:17px 18px!important;
    border:1px solid #dbeae7!important;
    border-radius:16px!important;
    background:#fbfefd!important;
    box-shadow:none!important;
}
.selected-summary-card.emphasis{
    background:linear-gradient(135deg,#e9f9f7 0%,#f7fcfb 100%)!important;
    border-color:#b8e2dd!important;
}
.selected-summary-card span{font-size:12px!important;color:#718984!important}
.selected-summary-card strong{font-size:25px!important;color:#1d5155!important}
.selected-summary-card small{font-size:12px!important;color:#788e89!important}
.assessment-workspace{
    display:block!important;
    padding:22px 0 30px!important;
    background:transparent!important;
}
.assessment-main-pane{max-width:1120px!important;margin:0 auto!important}
.adl-google-shell{
    max-width:none!important;
    margin:0!important;
    padding:18px!important;
    border:1px solid #d3ebe7!important;
    border-radius:24px!important;
    background:linear-gradient(180deg,#eaf9f7 0%,#f5fcfb 100%)!important;
    box-shadow:0 18px 42px rgba(38,102,105,.08)!important;
}
.adl-google-topline{
    height:6px!important;
    margin:-18px -18px 18px!important;
    border-radius:24px 24px 0 0!important;
    background:linear-gradient(90deg,#53bfc0 0%,#80d6c8 100%)!important;
}
.adl-google-title{
    padding:24px 28px!important;
    margin-bottom:16px!important;
    border:1px solid #d6e8e5!important;
    border-top:0!important;
    border-radius:18px!important;
    background:#fff!important;
    box-shadow:0 8px 20px rgba(43,99,100,.05)!important;
}
.adl-google-title .section-kicker{
    display:inline-flex!important;
    align-items:center!important;
    min-height:27px!important;
    padding:0 10px!important;
    border-radius:999px!important;
    background:#eef9f7!important;
    color:#3f7772!important;
    letter-spacing:.04em!important;
}
.adl-google-title h3{
    margin:10px 0 8px!important;
    font-size:31px!important;
    line-height:1.2!important;
    color:#183f45!important;
    letter-spacing:-.3px!important;
}
.adl-google-title p{
    max-width:850px!important;
    color:#687f7b!important;
    font-size:14px!important;
    line-height:1.75!important;
}
.adl-google-title .doctor-result{
    margin-top:18px!important;
    padding:13px 15px!important;
    border:1px solid #dcecea!important;
    border-radius:12px!important;
    background:#f8fcfb!important;
    color:#55736e!important;
}
.adl-google-required{
    margin-top:10px!important;
    font-size:12px!important;
    color:#7b8e8a!important;
}
.adl-google-question{
    padding:22px 26px!important;
    margin-bottom:14px!important;
    border:1px solid #d8e9e6!important;
    border-radius:18px!important;
    background:#fff!important;
    box-shadow:0 6px 18px rgba(43,99,100,.035)!important;
    transition:border-color .16s ease,box-shadow .16s ease,transform .16s ease!important;
}
.adl-google-question:hover{
    border-color:#c6e4df!important;
    box-shadow:0 10px 24px rgba(43,99,100,.06)!important;
}
.adl-google-question:focus-within{
    border-left:1px solid #80d1c8!important;
    border-color:#80d1c8!important;
    padding-left:26px!important;
    box-shadow:0 0 0 3px rgba(88,191,192,.10),0 10px 24px rgba(43,99,100,.06)!important;
}
.adl-google-question-head{
    display:grid!important;
    grid-template-columns:auto 1fr!important;
    column-gap:10px!important;
    align-items:start!important;
    margin-bottom:15px!important;
}
.adl-google-question-head h3{
    grid-column:1/-1!important;
    margin:0 0 5px!important;
    color:#1e4549!important;
    font-size:18px!important;
    line-height:1.35!important;
}
.adl-google-question-head p{
    grid-column:1/-1!important;
    color:#7a8d89!important;
    font-size:13px!important;
}
.adl-google-options{gap:8px!important}
.adl-google-option{
    display:grid!important;
    grid-template-columns:24px 82px 1fr!important;
    align-items:center!important;
    gap:10px!important;
    min-height:48px!important;
    padding:9px 14px!important;
    border:1px solid #dceae8!important;
    border-radius:12px!important;
    background:#fbfefd!important;
    transition:background .15s ease,border-color .15s ease,box-shadow .15s ease!important;
}
.adl-google-option:hover{
    background:#f3fbf9!important;
    border-color:#c7e4df!important;
}
.adl-google-option:has(input[type=radio]:checked){
    background:#e9f8f5!important;
    border-color:#6fc7bf!important;
    box-shadow:0 0 0 2px rgba(88,191,192,.08)!important;
}
.adl-google-option input[type=radio]{
    width:20px!important;
    height:20px!important;
    margin:0!important;
    accent-color:#318e92!important;
}
.adl-google-option .option-score{
    min-width:0!important;
    color:#1f5557!important;
    font-size:14px!important;
    font-weight:900!important;
    white-space:nowrap!important;
}
.adl-google-option .option-text{
    color:#415e59!important;
    font-size:14px!important;
    line-height:1.5!important;
}
.adl-google-footer{
    padding-top:8px!important;
}
.adl-google-footer .step-next-btn,
.google-submit-btn{
    min-width:220px!important;
    min-height:48px!important;
    border-radius:13px!important;
    background:linear-gradient(135deg,#55bfc0 0%,#42a9ac 100%)!important;
    border:0!important;
    color:#fff!important;
    font-weight:900!important;
    box-shadow:0 10px 20px rgba(74,174,176,.18)!important;
}
.adl-google-footer .step-next-btn:hover,
.google-submit-btn:hover{
    background:linear-gradient(135deg,#49afb1 0%,#3d9da0 100%)!important;
}
@media(max-width:820px){
    .assessment-formal-head{padding:18px 18px 14px!important}
    .formal-mini-info{padding:12px 18px!important}
    .selected-assessment-summary{grid-template-columns:1fr!important;padding:14px 18px 18px!important}
    .adl-google-shell{padding:10px!important;border-radius:18px!important}
    .adl-google-topline{margin:-10px -10px 12px!important;border-radius:18px 18px 0 0!important}
    .adl-google-title{padding:20px 18px!important}
    .adl-google-title h3{font-size:25px!important}
    .adl-google-question{padding:18px!important}
    .adl-google-question:focus-within{padding-left:18px!important}
    .adl-google-option{grid-template-columns:24px 72px 1fr!important;padding:9px 10px!important}
}
@media(max-width:560px){
    .adl-google-option{grid-template-columns:24px 1fr!important}
    .adl-google-option .option-score{grid-column:2!important}
    .adl-google-option .option-text{grid-column:2!important}
    .adl-google-title h3{font-size:22px!important}
    .assessment-formal-head h2{font-size:22px!important}
}

</style>
</head>
<body class="role-page<?= $showSuccessScreen ? ' adl-submit-success-body' : '' ?>"><?php if(!$showSuccessScreen) renderSidebar(); ?><main class="main<?= $showSuccessScreen ? ' adl-submit-success-main' : '' ?>"><?php if(!$showSuccessScreen) renderUserTopbar(); ?>
<?php if($showSuccessScreen):
    $sentScore=(int)($sentDetails['caregiver_total_score']??0);
    $sentDoctor=trim((string)($sentDetails['doctor_name']??'')) ?: trim((string)($sentDetails['doctor_username']??'')) ?: '-';
    $sentAtRaw=(string)($sentDetails['result_returned_at']??'');
    $sentTs=$sentAtRaw!=='' ? strtotime($sentAtRaw) : time();
    $sentDate=$sentTs ? adlThaiDate(date('Y-m-d',$sentTs)) : '-';
    $sentTime=$sentTs ? date('H:i',$sentTs).' น.' : '-';
?>
<div class="adl-submit-success-wrap">
    <div class="adl-submit-success-card" role="status" aria-live="polite">
        <div class="adl-submit-success-accent"></div>
        <div class="adl-submit-success-content">
            <div class="adl-submit-success-head">
                <span class="adl-submit-success-icon">✓</span>
                <div>
                    <h1>บันทึกข้อมูลสำเร็จ</h1>
                    <p class="adl-submit-success-sub">ระบบได้บันทึกข้อมูลการประเมินของ <strong><?=e($sentDetails['Fullname'] ?? '-')?></strong> และส่งผลกลับหมอเรียบร้อยแล้ว</p>
                </div>
            </div>
            <div class="adl-submit-success-grid">
                <div class="adl-submit-success-item"><span>ผู้สูงอายุ</span><strong><?=e($sentDetails['Fullname'] ?? '-')?></strong></div>
                <div class="adl-submit-success-item"><span>วันที่บันทึก</span><strong><?=e($sentDate)?></strong></div>
                <div class="adl-submit-success-item"><span>เวลา</span><strong><?=e($sentTime)?></strong></div>
                <div class="adl-submit-success-item"><span>ผลคะแนนการประเมินล่าสุด</span><strong><?=$sentScore?>/20 คะแนน</strong></div>
                <div class="adl-submit-success-item"><span>ผลการจัดกลุ่ม</span><strong><?=e(adlGroupCaregiver($sentScore))?></strong></div>
                <div class="adl-submit-success-item"><span>ส่งผลกลับไปยังหมอ</span><strong><?=e($sentDoctor)?></strong></div>
            </div>
            <div class="adl-submit-success-actions">
                <a class="adl-submit-summary-btn" href="caregiver_adl_summary_view.php?adl_id=<?= (int)($sentDetails['adl_id'] ?? 0) ?>">ดูผลสรุป</a>
                <a class="adl-submit-back-btn" href="caregiver_adl.php">กลับหน้ารายการประเมิน</a>
            </div>
        </div>
    </div>
</div>
<?php else: ?>
<?php if($message):?><div class="notice ok"><?=e($message)?></div><?php endif;?>
<?php if($sentDetails):
    $sentScore=(int)($sentDetails['caregiver_total_score']??0);
    $sentDoctor=trim((string)($sentDetails['doctor_name']??'')) ?: trim((string)($sentDetails['doctor_username']??'')) ?: '-';
    $sentCaregiver=trim((string)($sentDetails['caregiver_name']??'')) ?: trim((string)($sentDetails['caregiver_username']??'')) ?: '-';
    $sentAtRaw=(string)($sentDetails['result_returned_at']??'');
    $sentAt=$sentAtRaw!=='' ? date('d/m/Y H:i', strtotime($sentAtRaw)) : date('d/m/Y H:i');
?>
<div class="send-result-card" role="status" aria-live="polite">
    <div class="send-result-head">
        <span class="send-result-check">✓</span>
        <div><div class="send-result-title">ส่งผลกลับหมอสำเร็จ</div><div class="send-result-sub">รายละเอียดข้อมูลที่ระบบส่งกลับหลังบันทึกการประเมิน</div></div>
    </div>
    <div class="send-result-grid">
        <div class="send-result-item"><span>ผู้สูงอายุ</span><strong><?=e($sentDetails['Fullname'])?></strong></div>
        <div class="send-result-item"><span>ผลคะแนนล่าสุด</span><strong><?=$sentScore?>/20 คะแนน</strong></div>
        <div class="send-result-item"><span>ผลการจัดกลุ่ม</span><strong><?=e(adlGroupCaregiver($sentScore))?></strong></div>
        <div class="send-result-item"><span>ส่งกลับไปยังหมอ</span><strong><?=e($sentDoctor)?></strong></div>
        <div class="send-result-item"><span>ผู้ส่งผล</span><strong><?=e($sentCaregiver)?></strong></div>
        <div class="send-result-item"><span>วันเวลาที่ส่ง</span><strong><?=e($sentAt)?> น.</strong></div>
        <div class="send-result-item"><span>ผู้ดูแลประจำ</span><strong><?=e($sentDetails['regular_caregiver']??'-')?></strong></div>
        <div class="send-result-item"><span>เงินสงเคราะห์</span><strong><?=e($sentDetails['welfare_status']??'-')?></strong></div>
        <div class="send-result-item"><span>สมาชิกชมรม</span><strong><?=e($sentDetails['club_membership']??'-')?></strong></div>
        <?php if(trim((string)($sentDetails['note']??''))!==''):?><div class="send-result-item send-result-wide"><span>หมายเหตุที่ส่งกลับหมอ</span><strong><?=e($sentDetails['note'])?></strong></div><?php endif;?>
        <div class="send-result-item send-result-wide"><span>สถานะ</span><strong class="send-result-status">ส่งผลคะแนนล่าสุด ผลการจัดกลุ่ม และข้อมูลสรุปการประเมินกลับหมอเรียบร้อยแล้ว</strong></div>
    </div>
</div>
<?php endif;?>
<?php if($error):?><div class="notice err"><?=e($error)?></div><?php endif;?>
<?php if(!$formOnly && !$selected): ?>
<div class="adl-entry-wrap">
    <section class="adl-entry-card">
        <div class="adl-entry-head"><h1>แบบประเมินผู้สูงอายุ</h1></div>
        <?php if(!$rows): ?>
            <div class="empty">ยังไม่มีผู้สูงอายุที่อยู่ในความรับผิดชอบ จึงยังไม่สามารถทำแบบประเมินได้</div>
        <?php else: ?>
        <div class="adl-patient-select">
            <label for="adlPatientSearch">เลือกผู้สูงอายุ</label>
            <div class="adl-search-box" id="adlPatientBox">
                <input type="text" id="adlPatientSearch" class="adl-search-input" placeholder="พิมพ์เพื่อค้นหาและเลือกผู้สูงอายุ..." autocomplete="off">
                <button type="button" class="adl-search-clear" id="adlPatientClear" aria-label="ล้างคำค้น">×</button>
                
                <div class="adl-search-options" id="adlPatientOptions">
                    <?php foreach($rows as $r):
                        $adlLabel=e($r['Fullname']).(!empty($r['villagename'])?' • '.e($r['villagename']):'');
                        $adlSearch=e(mb_strtolower(trim((string)$r['Fullname']).' '.trim((string)($r['villagename']??'')), 'UTF-8'));
                    ?>
                    <button type="button" class="adl-search-option" data-value="<?=(int)$r['adl_id']?>" data-label="<?=$adlLabel?>" data-search="<?=$adlSearch?>" data-has-result="<?= (($r['caregiver_total_score'] ?? null) !== null || (int)($r['history_count'] ?? 0) > 0) ? '1' : '0' ?>"><?=$adlLabel?></button>
                    <?php endforeach; ?>
                    <div class="adl-search-empty" id="adlPatientEmpty">ไม่พบรายชื่อผู้สูงอายุ</div>
                </div>
                <select id="adlPatientSelect" class="adl-native-select"><option value="">-- เลือกผู้สูงอายุ --</option><?php foreach($rows as $r):?><option value="<?=(int)$r['adl_id']?>" data-has-result="<?= (($r['caregiver_total_score'] ?? null) !== null || (int)($r['history_count'] ?? 0) > 0) ? '1' : '0' ?>"><?=e($r['Fullname'])?></option><?php endforeach;?></select>
            </div>
        </div>
        <div class="adl-entry-grid">
            <a id="adlAssessLink" class="adl-entry-link primary is-disabled" href="caregiver_adl_form.php"><div class="adl-entry-label">แบบประเมิน ADL</div></a>
            <a id="adlBodyLink" class="adl-entry-link body is-disabled" href="caregiver_adl_form.php"><div class="adl-entry-label">แบบประเมิน Body</div></a>
            <a id="adlHistoryLink" class="adl-entry-link history is-disabled" href="caregiver_adl_history.php" aria-disabled="true" tabindex="-1"><div class="adl-entry-label">ผลการประเมิน</div></a>
        </div>
        <?php endif; ?>
    </section>
</div>
<?php endif; ?>
<?php if($selected):?>
<?php if($formOnly): ?>
<div class="adl-form-page-nav"><a href="caregiver_adl.php" class="btn-secondary-lite" onclick="if(window.history.length>1){event.preventDefault();window.history.back();}">ย้อนกลับ</a></div>
<?php endif; ?>
<section class="handoff-card assessment-card formal-assessment<?= $formOnly ? ' form-only-simple' : '' ?>" id="assessmentForm">
<?php if(!$formOnly): ?>
<div class="assessment-formal-head">
    <div>
        <span class="section-kicker">แบบประเมินรายบุคคล</span>
        <h2>การประเมินติดตามผล: <?=e($selected['Fullname'])?></h2>
    </div>
</div>
<div class="mini-info formal-mini-info"><span>อายุ <b><?=e($selected['Age'])?></b> ปี</span><span>เพศ <b><?=e($selected['Gender'])?></b></span><span>หมู่บ้าน <b><?=e($selected['villagename']??'-')?></b></span><span>ผลประเมินครั้งที่ 1 โดยหมอ <b><?=(int)$selected['total_score']?>/20</b></span><span>กลุ่มครั้งที่ 1 <b><?=e(adlGroupCaregiver((int)$selected['total_score']))?></b></span><span>ประเมินแล้ว <b><?= (int)($selected['history_count'] ?? 0) ?></b> ครั้ง</span></div>
<div class="selected-assessment-summary">
    <div class="selected-summary-card emphasis"><span>ครั้งที่กำลังจะบันทึก</span><strong>ครั้งที่ <?= (int)$selectedNextRound ?></strong><small>ระบบจะเก็บข้อมูลเดิมเป็นประวัติอัตโนมัติ</small></div>
    <div class="selected-summary-card"><span>ผลล่าสุดโดยแคร์กิฟเวอร์</span><strong><?= $selected['caregiver_total_score']!==null ? ((int)$selected['caregiver_total_score']).'/20' : '-' ?></strong><small><?= $selected['caregiver_total_score']!==null ? e(adlGroupCaregiver((int)$selected['caregiver_total_score'])) : 'ยังไม่มีข้อมูล' ?></small></div>
    <div class="selected-summary-card"><span>ประเมินล่าสุด</span><strong><?= e(adlThaiDateTime($selected['latest_assessed_at'] ?? null)) ?></strong><small><?= !empty($selected['history_count']) ? 'สามารถเปิดดูย้อนหลังจากปุ่มดูประวัติ' : 'ยังไม่มีประวัติย้อนหลัง' ?></small></div>
</div>
<?php endif; ?>
<div class="assessment-workspace">
<div class="assessment-main-pane">
<form method="post" id="caregiverAssessmentForm"><input type="hidden" name="adl_id" value="<?=(int)$selected['adl_id']?>">

<div class="step<?= $requestedStep === 1 ? ' active' : '' ?>" data-step="1">
<div class="adl-google-shell">
<?php if(!$formOnly): ?>
    <div class="adl-google-topline"></div>
    <div class="adl-google-title">
        <span class="section-kicker">แบบประเมินรายบุคคล</span>
        <h3>แบบประเมิน ADL ครั้งที่ <?= (int)$selectedNextRound ?></h3>
        <p>สำหรับแคร์กิฟเวอร์ประเมินความสามารถในการดำเนินชีวิตประจำวันของผู้สูงอายุ กรุณาเลือกคำตอบที่ตรงกับสภาพจริงมากที่สุดให้ครบทุกข้อ</p>
        <div class="doctor-result"><strong>ผลการประเมินครั้งที่ 1 โดยหมอ:</strong> <?=(int)$selected['total_score']?>/20 คะแนน — <?=e(adlGroupCaregiver((int)$selected['total_score']))?></div>
        <div class="adl-google-required"><span style="color:#d93025!important">*</span> จำเป็นต้องตอบทุกข้อ</div>
    </div>
<?php endif; ?>
<?php foreach($adlItems as $key=>$item):$field='caregiver_'.$key;$current=$selected[$field]??null;?>
    <div class="adl-google-question">
        <div class="adl-google-question-head">
            <h3><?=e($item['title'])?><span class="required-star" style="color:#d93025!important">*</span></h3>
            <p><?=e($item['subtitle'])?></p>
        </div>
        <div class="adl-google-options">
        <?php foreach($item['options'] as $scoreVal=>$label):?>
            <label class="adl-google-option score-opt">
                <input type="radio" name="cg_<?=e($key)?>" value="<?=$scoreVal?>" <?=((string)$current===(string)$scoreVal)?'checked':''?> required>
                <span class="option-score score-num"><?=$scoreVal?>.</span>
                <span class="option-text"><?=e($label)?></span>
            </label>
        <?php endforeach;?>
        </div>
    </div>
<?php endforeach;?>
    <div class="adl-google-footer"><button type="button" class="step-next-btn" data-go="2">ทำแบบประเมิน Body ต่อ</button></div>
</div>
</div>

<div class="step<?= $requestedStep === 2 ? ' active' : '' ?>" data-step="2">
<?php if($formOnly): ?>
<div class="body-simple-shell">
    <div class="body-simple-section">
        
        <div class="health-table-wrap"><table class="health-table"><thead><tr><th>ลำดับ</th><th>รายการวัด</th><th>หน่วยวัด</th><th>ค่าปกติ</th><th>ค่าที่ประเมิน</th></tr></thead><tbody>
<tr><td>1</td><td>น้ำหนัก</td><td>กิโลกรัม</td><td>-</td><td><input type="number" step="0.01" min="0" name="health_weight_kg" id="health_weight_kg" value="<?=e($selected['caregiver_health_weight_kg']??$selected['Weight_kg']??'')?>"></td></tr>
<tr><td>2</td><td>รอบเอว</td><td>เซนติเมตร</td><td>ชาย &lt; 90 / หญิง &lt; 80</td><td><input type="number" step="0.01" min="0" name="health_waist_cm" id="health_waist_cm" value="<?=e($selected['caregiver_health_waist_cm']??'')?>"></td></tr>
<tr><td>3</td><td>รอบสะโพก</td><td>เซนติเมตร</td><td>-</td><td><input type="number" step="0.01" min="0" name="health_hip_cm" id="health_hip_cm" value="<?=e($selected['caregiver_health_hip_cm']??'')?>"></td></tr>
<tr><td>4</td><td>อัตราส่วนเอวสะโพก</td><td>-</td><td>ชาย &lt; 0.8 / หญิง &lt; 0.7</td><td><input type="number" step="0.001" name="health_waist_hip_ratio" id="health_waist_hip_ratio" value="<?=e($selected['caregiver_health_waist_hip_ratio']??'')?>"></td></tr>
<tr><td>5</td><td>ระดับเปอร์เซ็นต์ไขมันร่างกาย</td><td>%</td><td>ชาย 10-19 / หญิง 20-29</td><td><input type="number" step="0.01" min="0" name="health_body_fat_pct" id="health_body_fat_pct" value="<?=e($selected['caregiver_health_body_fat_pct']??'')?>"></td></tr>
<tr><td>6</td><td>ระดับไขมันช่องท้อง</td><td>-</td><td>1-5</td><td><input type="number" step="0.01" min="0" name="health_visceral_fat" value="<?=e($selected['caregiver_health_visceral_fat']??'')?>"></td></tr>
<tr><td>7</td><td>อัตราการเผาผลาญขณะพัก (BMR)</td><td>กิโลแคลอรี่</td><td>-</td><td><input type="number" step="0.01" min="0" name="health_bmr" value="<?=e($selected['caregiver_health_bmr']??'')?>"></td></tr>
<tr><td>8</td><td>ค่าดัชนีมวลกาย (BMI)</td><td>กก./ม²</td><td>18.5-22.9</td><td><input type="number" step="0.01" name="health_bmi" id="health_bmi" value="<?=e($selected['caregiver_health_bmi']??'')?>"></td></tr>
<tr><td>9</td><td>อายุร่างกาย (Body Age: อายุโดยประมาณจากองค์ประกอบร่างกาย ไม่ใช่อายุจริง)</td><td>ปี</td><td>อายุจริงของผู้สูงอายุ (ใช้เป็นค่าอ้างอิงเพื่อเปรียบเทียบกับค่า Body Age ที่เครื่องวัดได้)</td><td><input type="number" step="0.01" min="0" name="health_body_age" value="<?=e($selected['caregiver_health_body_age']??'')?>"></td></tr>
<tr class="health-group"><td colspan="5">ระดับเปอร์เซ็นต์ไขมันใต้ผิวหนัง — ช่วงที่เครื่องวัดได้ 5.0–60.0% | ระดับ: ต่ำ / ปกติ / สูง / สูงมาก</td></tr>
<tr><td>10</td><td>ทั้งตัว</td><td>%</td><td>0,-1,-2 (เครื่องนำค่าที่วัดได้ไปเทียบกับช่วงปกติ: 0 = ปกติ, -1 = ต่ำ, -2 = ต่ำมาก)</td><td><input type="number" step="0.01" name="health_subfat_total" value="<?=e($selected['caregiver_health_subfat_total']??'')?>"></td></tr>
<tr><td>11</td><td>ช่วงลำตัว</td><td>%</td><td>0,-1,-2 (เครื่องนำค่าที่วัดได้ไปเทียบกับช่วงปกติ: 0 = ปกติ, -1 = ต่ำ, -2 = ต่ำมาก)</td><td><input type="number" step="0.01" name="health_subfat_trunk" value="<?=e($selected['caregiver_health_subfat_trunk']??'')?>"></td></tr>
<tr><td>12</td><td>ช่วงแขน</td><td>%</td><td>0,-1,-2 (เครื่องนำค่าที่วัดได้ไปเทียบกับช่วงปกติ: 0 = ปกติ, -1 = ต่ำ, -2 = ต่ำมาก)</td><td><input type="number" step="0.01" name="health_subfat_arms" value="<?=e($selected['caregiver_health_subfat_arms']??'')?>"></td></tr>
<tr><td>13</td><td>ช่วงขา</td><td>%</td><td>0,-1,-2 (เครื่องนำค่าที่วัดได้ไปเทียบกับช่วงปกติ: 0 = ปกติ, -1 = ต่ำ, -2 = ต่ำมาก)</td><td><input type="number" step="0.01" name="health_subfat_legs" value="<?=e($selected['caregiver_health_subfat_legs']??'')?>"></td></tr>
<tr class="health-group"><td colspan="5">ระดับเปอร์เซ็นต์กล้ามเนื้อ — ค่าปกติอายุ 60–80 ปี: ชาย 32.9–38.9% / หญิง 23.9–29.9%</td></tr>
<tr><td>14</td><td>ทั้งตัว</td><td>%</td><td>0,+1,+2 (เครื่องนำค่าที่วัดได้ไปเทียบกับช่วงปกติ: 0 = ปกติ, +1 = สูง, +2 = สูงมาก)</td><td><input type="number" step="0.01" name="health_muscle_total" value="<?=e($selected['caregiver_health_muscle_total']??'')?>"></td></tr>
<tr><td>15</td><td>ช่วงลำตัว</td><td>%</td><td>0,+1,+2 (เครื่องนำค่าที่วัดได้ไปเทียบกับช่วงปกติ: 0 = ปกติ, +1 = สูง, +2 = สูงมาก)</td><td><input type="number" step="0.01" name="health_muscle_trunk" value="<?=e($selected['caregiver_health_muscle_trunk']??'')?>"></td></tr>
<tr><td>16</td><td>ช่วงแขน</td><td>%</td><td>0,+1,+2 (เครื่องนำค่าที่วัดได้ไปเทียบกับช่วงปกติ: 0 = ปกติ, +1 = สูง, +2 = สูงมาก)</td><td><input type="number" step="0.01" name="health_muscle_arms" value="<?=e($selected['caregiver_health_muscle_arms']??'')?>"></td></tr>
<tr><td>17</td><td>ช่วงขา</td><td>%</td><td>0,+1,+2 (เครื่องนำค่าที่วัดได้ไปเทียบกับช่วงปกติ: 0 = ปกติ, +1 = สูง, +2 = สูงมาก)</td><td><input type="number" step="0.01" name="health_muscle_legs" value="<?=e($selected['caregiver_health_muscle_legs']??'')?>"></td></tr>
<tr class="health-group"><td colspan="5">มวลกายไร้ไขมัน</td></tr>
<tr><td>18</td><td>ค่ามวลกายไร้ไขมัน</td><td>กิโลกรัม</td><td>-</td><td><input type="number" step="0.01" name="health_fat_free_mass" id="health_fat_free_mass" value="<?=e($selected['caregiver_health_fat_free_mass']??'')?>"></td></tr>
<tr><td>19</td><td>ค่าน้ำตาลปลายนิ้ว (DTX)</td><td>mg/dL</td><td>เก็บเป็นค่าตัวเลขจากเครื่องตรวจน้ำตาลปลายนิ้ว</td><td><input type="number" step="0.01" min="0" inputmode="decimal" name="health_dtx" value="<?=e($selected['caregiver_health_dtx']??'')?>" placeholder="เช่น 105"></td></tr>
<tr><td>20</td><td>ค่าความดันโลหิต (BP)</td><td>mmHg</td><td>-</td><td><input type="text" name="health_bp" placeholder="เช่น 120/80" value="<?=e($selected['caregiver_health_bp']??'')?>"></td></tr>
</tbody></table></div>
    </div>
    <div class="body-simple-section">
        <div class="google-section-card">
            <div class="google-section-body google-social-questions">
                <div class="google-form-question">
                    <h4>1. มีผู้ดูแลประจำหรือไม่ <span class="required-star" style="color:#d93025!important">*</span></h4>
                    <div class="google-radio-options"><?php foreach($caregiverOptions as $o):?><label><input type="radio" name="regular_caregiver" value="<?=e($o)?>" <?=$selected['regular_caregiver']===$o?'checked':''?> required><span><?=e($o)?></span></label><?php endforeach;?></div>
                </div>
                <div class="google-form-question">
                    <h4>2. ได้รับเงินสงเคราะห์หรือไม่ <span class="required-star" style="color:#d93025!important">*</span></h4>
                    <div class="google-radio-options"><?php foreach($welfareOptions as $o):?><label><input type="radio" name="welfare_status" value="<?=e($o)?>" <?=$selected['welfare_status']===$o?'checked':''?> required><span><?=e($o)?></span></label><?php endforeach;?></div>
                </div>
                <div class="google-form-question">
                    <h4>3. เป็นสมาชิกชมรมใด ๆ หรือไม่ <span class="required-star" style="color:#d93025!important">*</span></h4>
                    <div class="google-radio-options"><?php foreach($clubOptions as $o):?><label><input type="radio" name="club_membership" value="<?=e($o)?>" <?=$selected['club_membership']===$o?'checked':''?> required><span><?=e($o)?></span></label><?php endforeach;?></div>
                </div>
                <div class="google-form-question">
                    <h4>หมายเหตุเพิ่มเติม</h4>
                    <textarea class="google-long-answer" name="note" placeholder="ระบุรายละเอียดเพิ่มเติม (ถ้ามี)"><?=e($selected['note'])?></textarea>
                </div>
            </div>
        </div>
        <div class="step-bottom-nav">
            <button type="button" class="step-nav-btn" data-go="1">ย้อนกลับไปแบบประเมิน ADL</button>
            <button class="google-submit-btn" type="submit">บันทึกผล</button>
        </div>
    </div>
</div>
<?php else: ?>
<div class="health-title">แบบประเมินภาวะสุขภาพด้วยเครื่องวัด Body composition</div><div class="health-note">กรอกค่าที่วัดได้ให้ครบถ้วน จากนั้นกดหน้าถัดไปเพื่อสรุปผลการประเมิน</div>

<div class="health-table-wrap"><table class="health-table"><thead><tr><th>ลำดับ</th><th>รายการวัด</th><th>หน่วยวัด</th><th>ค่าปกติ</th><th>ค่าที่ประเมิน</th></tr></thead><tbody>
<tr><td>1</td><td>น้ำหนัก</td><td>กิโลกรัม</td><td>-</td><td><input type="number" step="0.01" min="0" name="health_weight_kg" id="health_weight_kg" value="<?=e($selected['caregiver_health_weight_kg']??$selected['Weight_kg']??'')?>"></td></tr>
<tr><td>2</td><td>รอบเอว</td><td>เซนติเมตร</td><td>ชาย &lt; 90 / หญิง &lt; 80</td><td><input type="number" step="0.01" min="0" name="health_waist_cm" id="health_waist_cm" value="<?=e($selected['caregiver_health_waist_cm']??'')?>"></td></tr>
<tr><td>3</td><td>รอบสะโพก</td><td>เซนติเมตร</td><td>-</td><td><input type="number" step="0.01" min="0" name="health_hip_cm" id="health_hip_cm" value="<?=e($selected['caregiver_health_hip_cm']??'')?>"></td></tr>
<tr><td>4</td><td>อัตราส่วนเอวสะโพก</td><td>-</td><td>ชาย &lt; 0.8 / หญิง &lt; 0.7</td><td><input type="number" step="0.001" name="health_waist_hip_ratio" id="health_waist_hip_ratio" value="<?=e($selected['caregiver_health_waist_hip_ratio']??'')?>"></td></tr>
<tr><td>5</td><td>ระดับเปอร์เซ็นต์ไขมันร่างกาย</td><td>%</td><td>ชาย 10-19 / หญิง 20-29</td><td><input type="number" step="0.01" min="0" name="health_body_fat_pct" id="health_body_fat_pct" value="<?=e($selected['caregiver_health_body_fat_pct']??'')?>"></td></tr>
<tr><td>6</td><td>ระดับไขมันช่องท้อง</td><td>-</td><td>1-5</td><td><input type="number" step="0.01" min="0" name="health_visceral_fat" value="<?=e($selected['caregiver_health_visceral_fat']??'')?>"></td></tr>
<tr><td>7</td><td>อัตราการเผาผลาญขณะพัก (BMR)</td><td>กิโลแคลอรี่</td><td>-</td><td><input type="number" step="0.01" min="0" name="health_bmr" value="<?=e($selected['caregiver_health_bmr']??'')?>"></td></tr>
<tr><td>8</td><td>ค่าดัชนีมวลกาย (BMI)</td><td>กก./ม²</td><td>18.5-22.9</td><td><input type="number" step="0.01" name="health_bmi" id="health_bmi" value="<?=e($selected['caregiver_health_bmi']??'')?>"></td></tr>
<tr><td>9</td><td>อายุร่างกาย (Body Age: อายุโดยประมาณจากองค์ประกอบร่างกาย ไม่ใช่อายุจริง)</td><td>ปี</td><td>อายุจริงของผู้สูงอายุ (ใช้เป็นค่าอ้างอิงเพื่อเปรียบเทียบกับค่า Body Age ที่เครื่องวัดได้)</td><td><input type="number" step="0.01" min="0" name="health_body_age" value="<?=e($selected['caregiver_health_body_age']??'')?>"></td></tr>
<tr class="health-group"><td colspan="5">ระดับเปอร์เซ็นต์ไขมันใต้ผิวหนัง — ช่วงที่เครื่องวัดได้ 5.0–60.0% | ระดับ: ต่ำ / ปกติ / สูง / สูงมาก</td></tr>
<tr><td>10</td><td>ทั้งตัว</td><td>%</td><td>0,-1,-2 (เครื่องนำค่าที่วัดได้ไปเทียบกับช่วงปกติ: 0 = ปกติ, -1 = ต่ำ, -2 = ต่ำมาก)</td><td><input type="number" step="0.01" name="health_subfat_total" value="<?=e($selected['caregiver_health_subfat_total']??'')?>"></td></tr>
<tr><td>11</td><td>ช่วงลำตัว</td><td>%</td><td>0,-1,-2 (เครื่องนำค่าที่วัดได้ไปเทียบกับช่วงปกติ: 0 = ปกติ, -1 = ต่ำ, -2 = ต่ำมาก)</td><td><input type="number" step="0.01" name="health_subfat_trunk" value="<?=e($selected['caregiver_health_subfat_trunk']??'')?>"></td></tr>
<tr><td>12</td><td>ช่วงแขน</td><td>%</td><td>0,-1,-2 (เครื่องนำค่าที่วัดได้ไปเทียบกับช่วงปกติ: 0 = ปกติ, -1 = ต่ำ, -2 = ต่ำมาก)</td><td><input type="number" step="0.01" name="health_subfat_arms" value="<?=e($selected['caregiver_health_subfat_arms']??'')?>"></td></tr>
<tr><td>13</td><td>ช่วงขา</td><td>%</td><td>0,-1,-2 (เครื่องนำค่าที่วัดได้ไปเทียบกับช่วงปกติ: 0 = ปกติ, -1 = ต่ำ, -2 = ต่ำมาก)</td><td><input type="number" step="0.01" name="health_subfat_legs" value="<?=e($selected['caregiver_health_subfat_legs']??'')?>"></td></tr>
<tr class="health-group"><td colspan="5">ระดับเปอร์เซ็นต์กล้ามเนื้อ — ค่าปกติอายุ 60–80 ปี: ชาย 32.9–38.9% / หญิง 23.9–29.9%</td></tr>
<tr><td>14</td><td>ทั้งตัว</td><td>%</td><td>0,+1,+2 (เครื่องนำค่าที่วัดได้ไปเทียบกับช่วงปกติ: 0 = ปกติ, +1 = สูง, +2 = สูงมาก)</td><td><input type="number" step="0.01" name="health_muscle_total" value="<?=e($selected['caregiver_health_muscle_total']??'')?>"></td></tr>
<tr><td>15</td><td>ช่วงลำตัว</td><td>%</td><td>0,+1,+2 (เครื่องนำค่าที่วัดได้ไปเทียบกับช่วงปกติ: 0 = ปกติ, +1 = สูง, +2 = สูงมาก)</td><td><input type="number" step="0.01" name="health_muscle_trunk" value="<?=e($selected['caregiver_health_muscle_trunk']??'')?>"></td></tr>
<tr><td>16</td><td>ช่วงแขน</td><td>%</td><td>0,+1,+2 (เครื่องนำค่าที่วัดได้ไปเทียบกับช่วงปกติ: 0 = ปกติ, +1 = สูง, +2 = สูงมาก)</td><td><input type="number" step="0.01" name="health_muscle_arms" value="<?=e($selected['caregiver_health_muscle_arms']??'')?>"></td></tr>
<tr><td>17</td><td>ช่วงขา</td><td>%</td><td>0,+1,+2 (เครื่องนำค่าที่วัดได้ไปเทียบกับช่วงปกติ: 0 = ปกติ, +1 = สูง, +2 = สูงมาก)</td><td><input type="number" step="0.01" name="health_muscle_legs" value="<?=e($selected['caregiver_health_muscle_legs']??'')?>"></td></tr>
<tr class="health-group"><td colspan="5">มวลกายไร้ไขมัน</td></tr>
<tr><td>18</td><td>ค่ามวลกายไร้ไขมัน</td><td>กิโลกรัม</td><td>-</td><td><input type="number" step="0.01" name="health_fat_free_mass" id="health_fat_free_mass" value="<?=e($selected['caregiver_health_fat_free_mass']??'')?>"></td></tr>
<tr><td>19</td><td>ค่าน้ำตาลปลายนิ้ว (DTX)</td><td>mg/dL</td><td>เก็บเป็นค่าตัวเลขจากเครื่องตรวจน้ำตาลปลายนิ้ว</td><td><input type="number" step="0.01" min="0" inputmode="decimal" name="health_dtx" value="<?=e($selected['caregiver_health_dtx']??'')?>" placeholder="เช่น 105"></td></tr>
<tr><td>20</td><td>ค่าความดันโลหิต (BP)</td><td>mmHg</td><td>-</td><td><input type="text" name="health_bp" placeholder="เช่น 120/80" value="<?=e($selected['caregiver_health_bp']??'')?>"></td></tr>
</tbody></table></div>
<div class="step-bottom-nav between">
<button type="button" class="step-nav-btn" data-go="1">ย้อนกลับไปแบบประเมิน ADL</button>
<button type="button" class="step-nav-btn primary" data-go="3">หน้าถัดไป : สรุปผลคะแนน</button>
</div>
<?php endif; ?>
</div>

<?php if(!$formOnly): ?>
<div class="step" data-step="3">
<div class="google-form-shell" id="resultSummaryForm">
    <div class="google-form-accent"></div>
    <div class="google-form-title-card">
        <div class="google-form-title-row">
            <div>
                <span class="section-kicker">แบบสรุปผลการประเมินผู้สูงอายุ</span>
                <h3>แบบสรุปผลการประเมินความสามารถในการดำเนินชีวิตประจำวัน (ADL)</h3>
                <p>สรุปผลการประเมิน Barthel Activities of Daily Living เพื่อประกอบการติดตามและส่งต่อข้อมูลแก่หมอผู้รับผิดชอบ</p>
            </div>
            <span class="result-preview-note">ตรวจสอบข้อมูลให้ครบถ้วน แล้วบันทึกการประเมินเพื่อเปิดสรุปรายงาน</span>
        </div>
        <div class="google-required-note"><span style="color:#d93025!important">*</span> ข้อมูลจากแบบประเมิน ADL จะถูกนำมาแสดงในแบบฟอร์มนี้อัตโนมัติ</div>
    </div>

    <div class="google-question-card">
        <div class="google-question-title">ข้อมูลผู้สูงอายุ</div>
        <div class="google-info-lines">
            <div><span>ชื่อ-นามสกุล</span><strong><?=e($selected['Fullname'])?></strong></div>
            <div><span>อายุ</span><strong><?=e($selected['Age'])?> ปี</strong></div>
            <div><span>เพศ</span><strong><?=e($selected['Gender'])?></strong></div>
            <div><span>หมู่บ้าน</span><strong><?=e($selected['villagename']??'-')?></strong></div>
        </div>
    </div>

    <div class="google-section-card">
        <div class="google-section-head">ผลคะแนน ADL</div>
        <div class="google-section-body">
            <div class="google-score-summary">
                <div><span>ครั้งที่ 1 โดยหมอ</span><strong><?=(int)$selected['total_score']?>/20</strong><small><?=e(adlGroupCaregiver((int)$selected['total_score']))?></small></div>
                <div class="current"><span>ครั้งที่ <?= (int)$selectedNextRound ?> โดยแคร์กิฟเวอร์</span><strong id="summaryScore">0/20</strong><small id="summaryGroup">-</small></div>
                <div><span>ผลการเปลี่ยนแปลง</span><strong id="finalGroup">-</strong><small id="scoreChange">-</small></div>
            </div>
        </div>
    </div>

    <div class="google-section-card adl-summary-section">
        <div class="google-section-head">รายละเอียดคำตอบแบบประเมิน ADL ครั้งที่ <?= (int)$selectedNextRound ?></div>
        <div class="google-section-desc">แสดงคำตอบที่เลือกจากแบบประเมิน ADL ทั้ง 10 ข้อ</div>
        <div class="google-section-body google-adl-list">
        <?php foreach($adlItems as $key=>$item): ?>
            <div class="google-adl-card" data-summary-adl="<?=e($key)?>">
                <div class="google-adl-question">
                    <span class="google-adl-number"><?=e(explode('.', $item['title'])[0])?></span>
                    <div>
                        <h4><?=e($item['title'])?></h4>
                        <p><?=e($item['subtitle'])?></p>
                    </div>
                </div>
                <div class="google-answer-line">
                    <span class="google-radio-dot"></span>
                    <div class="google-answer-text">
                        <strong class="adl-selected-label">ยังไม่ได้เลือกคำตอบ</strong>
                        <span class="adl-selected-score">- คะแนน</span>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
        </div>
    </div>

    <div class="google-section-card">
        <div class="google-section-head">สรุปภาวะสุขภาพ</div>
        <div class="google-section-body">
            <div class="google-info-lines health-lines">
                <div><span>วันที่ประเมิน</span><strong id="sumHealthDate">-</strong></div>
                <div><span>น้ำหนัก</span><strong id="sumWeight">-</strong></div>
                <div><span>BMI</span><strong id="sumBmi">-</strong></div>
                <div><span>รอบเอว</span><strong id="sumWaist">-</strong></div>
                <div><span>อัตราส่วนเอว/สะโพก</span><strong id="sumRatio">-</strong></div>
                <div><span>ไขมันร่างกาย</span><strong id="sumBodyFat">-</strong></div>
                <div><span>น้ำตาลปลายนิ้ว (DTX)</span><strong id="sumDtx">-</strong></div>
                <div><span>ความดันโลหิต (BP)</span><strong id="sumBp">-</strong></div>
            </div>
        </div>
    </div>

    <div class="google-section-card">
        <div class="google-section-head">ข้อมูลการดูแลและสังคม</div>
        <div class="google-section-body google-social-questions">
            <div class="google-form-question">
                <h4>1. มีผู้ดูแลประจำหรือไม่ <span class="required-star" style="color:#d93025!important">*</span></h4>
                <div class="google-radio-options"><?php foreach($caregiverOptions as $o):?><label><input type="radio" name="regular_caregiver" value="<?=e($o)?>" <?=$selected['regular_caregiver']===$o?'checked':''?> required><span><?=e($o)?></span></label><?php endforeach;?></div>
            </div>
            <div class="google-form-question">
                <h4>2. ได้รับเงินสงเคราะห์หรือไม่ <span class="required-star" style="color:#d93025!important">*</span></h4>
                <div class="google-radio-options"><?php foreach($welfareOptions as $o):?><label><input type="radio" name="welfare_status" value="<?=e($o)?>" <?=$selected['welfare_status']===$o?'checked':''?> required><span><?=e($o)?></span></label><?php endforeach;?></div>
            </div>
            <div class="google-form-question">
                <h4>3. เป็นสมาชิกชมรมใด ๆ หรือไม่ <span class="required-star" style="color:#d93025!important">*</span></h4>
                <div class="google-radio-options"><?php foreach($clubOptions as $o):?><label><input type="radio" name="club_membership" value="<?=e($o)?>" <?=$selected['club_membership']===$o?'checked':''?> required><span><?=e($o)?></span></label><?php endforeach;?></div>
            </div>
            <div class="google-form-question">
                <h4>หมายเหตุเพิ่มเติม</h4>
                <textarea class="google-long-answer" name="note" placeholder="ระบุรายละเอียดเพิ่มเติม (ถ้ามี)"><?=e($selected['note'])?></textarea>
            </div>
        </div>
    </div>

    <div class="google-submit-note"><strong>ส่งผลกลับหมอ</strong><span>เมื่อกดบันทึก ระบบจะบันทึกผลการประเมินครั้งนี้ลงในประวัติ และส่งผลคะแนนล่าสุด ผลการจัดกลุ่ม รายละเอียดคำตอบ ADL และข้อมูลสรุปกลับไปยังหมออัตโนมัติ</span></div>
</div>
<div class="step-bottom-nav between google-form-actions">
<button type="button" class="step-nav-btn" data-go="2">ย้อนกลับ : ประเมินภาวะสุขภาพ</button>
<button class="btn-save google-submit-btn" type="submit">บันทึกและส่งแบบฟอร์มกลับหมอ</button>
</div></div>
<?php endif; ?>
</form>
</div>

</div>
</section><?php endif;?></div><?php endif; ?></main>
<script>
(function(){
 const form=document.getElementById('caregiverAssessmentForm'); if(!form)return;
 const steps=[...form.querySelectorAll('.step')], pills=[...document.querySelectorAll('.step-pill')];
 function showStep(n){steps.forEach(s=>s.classList.toggle('active',s.dataset.step==n));pills.forEach(p=>p.classList.toggle('active',p.dataset.pill==n));document.getElementById('assessmentForm').scrollIntoView({behavior:'smooth',block:'start'});if(n==3)updateSummary();}
 const initialStep=<?= json_encode($requestedStep) ?>;
 if(initialStep){showStep(initialStep);}
 document.querySelectorAll('[data-go]').forEach(b=>b.addEventListener('click',()=>{
   const n=Number(b.dataset.go);
   showStep(n);
 }));
 function updateSummary(){let total=0;form.querySelectorAll('input[name^="cg_"]:checked').forEach(i=>total+=Number(i.value||0));const scoreEl=document.getElementById('summaryScore');if(scoreEl)scoreEl.textContent=total+'/20';const g=total>=12?'กลุ่มติดสังคม':(total>=5?'กลุ่มติดบ้าน':'กลุ่มติดเตียง');const groupEl=document.getElementById('summaryGroup');if(groupEl)groupEl.textContent=g;const fg=document.getElementById('finalGroup');if(fg)fg.textContent=g;const doctorScore=<?=json_encode((int)$selected['total_score'])?>;const change=document.getElementById('scoreChange');if(change){const diff=total-doctorScore;change.textContent=diff>0?'คะแนนเพิ่มขึ้น '+diff+' คะแนน':(diff<0?'คะแนนลดลง '+Math.abs(diff)+' คะแนน':'คะแนนเท่าเดิม');}
   document.querySelectorAll('[data-summary-adl]').forEach(card=>{const key=card.dataset.summaryAdl;const chosen=form.querySelector('input[name="cg_'+key+'"]:checked');const labelEl=card.querySelector('.adl-selected-label');const scoreText=card.querySelector('.adl-selected-score');if(!chosen){if(labelEl)labelEl.textContent='ยังไม่ได้เลือกคำตอบ';if(scoreText)scoreText.textContent='- คะแนน';return;}const opt=chosen.closest('.score-opt');const spans=opt?opt.querySelectorAll('span'):[];if(labelEl)labelEl.textContent=spans.length>1?spans[1].textContent.trim():'เลือกคำตอบแล้ว';if(scoreText)scoreText.textContent=chosen.value+' คะแนน';});
   updateHealthSummary();}
 form.querySelectorAll('input[name^="cg_"]').forEach(i=>i.addEventListener('change',updateSummary));
 const wt=document.getElementById('health_weight_kg'),waist=document.getElementById('health_waist_cm'),hip=document.getElementById('health_hip_cm'),ratio=document.getElementById('health_waist_hip_ratio'),bmi=document.getElementById('health_bmi'),fat=document.getElementById('health_body_fat_pct'),ffm=document.getElementById('health_fat_free_mass');
 const heightCm=<?=json_encode((float)($selected['Height_cm']??0))?>;
 function valueText(name,suffix=''){const el=form.querySelector('[name="'+name+'"]');const v=el?String(el.value||'').trim():'';return v?(v+suffix):'-';}
 function updateHealthSummary(){
   const map={sumHealthDate:['health_assessment_date',''],sumWeight:['health_weight_kg',' กก.'],sumBmi:['health_bmi',''],sumWaist:['health_waist_cm',' ซม.'],sumRatio:['health_waist_hip_ratio',''],sumBodyFat:['health_body_fat_pct',' %'],sumDtx:['health_dtx',' mg/dL'],sumBp:['health_bp',' mmHg']};
   Object.entries(map).forEach(([id,cfg])=>{const el=document.getElementById(id);if(el)el.textContent=valueText(cfg[0],cfg[1]);});
 }
 form.querySelectorAll('input[name^="health_"]').forEach(i=>i.addEventListener('input',updateHealthSummary));
 function calcHealth(){const w=parseFloat(wt.value||0),wc=parseFloat(waist.value||0),hc=parseFloat(hip.value||0),fp=parseFloat(fat.value||0);if(wc>0&&hc>0)ratio.value=(wc/hc).toFixed(3);if(w>0&&heightCm>0){const m=heightCm/100;bmi.value=(w/(m*m)).toFixed(2);}if(w>0&&fp>=0)ffm.value=(w-(fp*w/100)).toFixed(2);updateHealthSummary();}
 [wt,waist,hip,fat].forEach(el=>el&&el.addEventListener('input',calcHealth)); updateSummary();
})();
</script><script>
(function(){
 const select=document.getElementById('adlPatientSelect'), input=document.getElementById('adlPatientSearch'), clear=document.getElementById('adlPatientClear'), toggle=document.getElementById('adlPatientToggle'), wrap=document.getElementById('adlPatientOptions'), empty=document.getElementById('adlPatientEmpty'), assess=document.getElementById('adlAssessLink'), body=document.getElementById('adlBodyLink'), history=document.getElementById('adlHistoryLink');
 const opts=Array.from(document.querySelectorAll('.adl-search-option'));
 if(!select||!input) return;
 function links(){const id=select.value,ok=id!=='';const selectedOption=select.selectedIndex>=0?select.options[select.selectedIndex]:null;const hasResult=!!(ok&&selectedOption&&selectedOption.dataset.hasResult==='1');if(assess){assess.href=ok?'caregiver_adl_form.php?adl_id='+encodeURIComponent(id)+'&step=1':'caregiver_adl_form.php';assess.classList.toggle('is-disabled',!ok)}if(body){body.href=ok?'caregiver_adl_form.php?adl_id='+encodeURIComponent(id)+'&step=2':'caregiver_adl_form.php';body.classList.toggle('is-disabled',!ok)}if(history){history.href=hasResult?'caregiver_adl_history.php?adl_id='+encodeURIComponent(id):'caregiver_adl_history.php';history.classList.toggle('is-disabled',!hasResult);history.setAttribute('aria-disabled',hasResult?'false':'true');history.tabIndex=hasResult?0:-1}}
 function open(){wrap&&wrap.classList.add('is-open')} function close(){wrap&&wrap.classList.remove('is-open');opts.forEach(n=>n.classList.remove('is-active'))}
 function clearState(){clear&&clear.classList.toggle('is-visible',input.value.trim()!=='')}
 function filter(){const q=input.value.trim().toLocaleLowerCase('th-TH');let shown=0;opts.forEach(n=>{const hay=((n.dataset.search||'')+' '+(n.dataset.label||'')).toLocaleLowerCase('th-TH'),m=!q||hay.includes(q);n.style.display=m?'block':'none';n.classList.toggle('is-active',m&&shown===0);if(m)shown++});empty&&empty.classList.toggle('is-visible',shown===0);clearState()}
 function showAll(){let shown=0;opts.forEach(n=>{n.style.display='block';n.classList.toggle('is-active',shown===0);shown++});empty&&empty.classList.toggle('is-visible',shown===0);clearState()}
 function choose(n){select.value=n.dataset.value||'';input.value=n.dataset.label||'';clearState();close();links()}
 function openAllPatients(){open();showAll()}
 input.addEventListener('focus',openAllPatients);input.addEventListener('click',openAllPatients);input.addEventListener('input',()=>{select.value='';links();open();filter()});
 opts.forEach(n=>n.addEventListener('click',()=>choose(n)));toggle&&toggle.addEventListener('click',()=>{if(wrap&&wrap.classList.contains('is-open'))close();else{open();showAll();input.focus()}});clear&&clear.addEventListener('click',()=>{input.value='';select.value='';clearState();links();open();showAll();input.focus()});document.addEventListener('click',e=>{if(!e.target.closest('#adlPatientBox'))close()});clearState();links();
})();
</script>
</body></html>
