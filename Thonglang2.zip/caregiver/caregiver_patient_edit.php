<?php
require_once __DIR__ . '/../connect.php';
ensureThonglangCoreSchema($conn);
requireRole('caregiver');
mysqli_set_charset($conn, 'utf8mb4');

$caregiverId = (int)($_SESSION['user_id'] ?? 0);
$patientId = (int)($_GET['patient_id'] ?? $_POST['patient_id'] ?? 0);
$error = '';
$message = '';

function cgPatientOwned(mysqli $conn, int $patientId, int $caregiverId): bool
{
    $stmt = mysqli_prepare($conn, "SELECT 1 FROM patient_caregiver_assignment WHERE patient_id=? AND caregiver_user_id=? LIMIT 1");
    if (!$stmt) return false;
    mysqli_stmt_bind_param($stmt, 'ii', $patientId, $caregiverId);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $ok = $res && mysqli_fetch_row($res);
    mysqli_stmt_close($stmt);
    return (bool)$ok;
}

if ($patientId <= 0 || $caregiverId <= 0 || !cgPatientOwned($conn, $patientId, $caregiverId)) {
    header('Location: caregiver_patients.php');
    exit;
}

$villages = [];
$villageRes = mysqli_query($conn, "SELECT village_id, villagename FROM village ORDER BY villagename ASC");
if ($villageRes) {
    while ($v = mysqli_fetch_assoc($villageRes)) $villages[] = $v;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $firstname = trim((string)($_POST['Firstname'] ?? ''));
    $lastname = trim((string)($_POST['Lastname'] ?? ''));
    $fullname = trim($firstname . ' ' . $lastname);
    if ($fullname === '') $fullname = trim((string)($_POST['Fullname'] ?? ''));
    $gender = trim((string)($_POST['Gender'] ?? ''));
    $age = max(0, (int)($_POST['Age'] ?? 0));
    $weightRaw = trim((string)($_POST['Weight_kg'] ?? ''));
    $heightRaw = trim((string)($_POST['Height_cm'] ?? ''));
    $weight = $weightRaw === '' ? null : (float)$weightRaw;
    $height = $heightRaw === '' ? null : (float)$heightRaw;
    $houseNo = trim((string)($_POST['House_no'] ?? ''));
    $mooNo = trim((string)($_POST['Moo_no'] ?? ''));
    $addressDetail = trim((string)($_POST['Address_detail'] ?? ''));
    $tambon = 'ทองหลาง';
    $amphoe = 'จักราช';
    $province = 'นครราชสีมา';
    $postcode = '30230';
    $addressParts = [];
    if ($houseNo !== '') $addressParts[] = 'บ้านเลขที่ ' . $houseNo;
    if ($mooNo !== '') $addressParts[] = 'หมู่ที่ ' . $mooNo;
    if ($addressDetail !== '') $addressParts[] = $addressDetail;
    $addressParts[] = 'ตำบล ' . $tambon;
    $addressParts[] = 'อำเภอ ' . $amphoe;
    $addressParts[] = 'จังหวัด ' . $province;
    $addressParts[] = 'รหัสไปรษณีย์ ' . $postcode;
    $address = trim(implode(' ', $addressParts));
    $phone = trim((string)($_POST['Phone'] ?? ''));
    $disease = trim((string)($_POST['Disease'] ?? ''));
    $villageId = (int)($_POST['Village_id'] ?? 0);
    $latitudeRaw = trim((string)($_POST['Latitude'] ?? ''));
    $longitudeRaw = trim((string)($_POST['Longitude'] ?? ''));
    $latitude = $latitudeRaw === '' ? null : (float)$latitudeRaw;
    $longitude = $longitudeRaw === '' ? null : (float)$longitudeRaw;

    if ($fullname === '') {
        $error = 'กรุณาระบุชื่อผู้สูงอายุ';
    } elseif (($latitudeRaw !== '' && !is_numeric($latitudeRaw)) || ($longitudeRaw !== '' && !is_numeric($longitudeRaw))) {
        $error = 'กรุณาระบุละติจูดและลองจิจูดเป็นตัวเลข';
    } elseif (($latitude !== null && ($latitude < -90 || $latitude > 90)) || ($longitude !== null && ($longitude < -180 || $longitude > 180))) {
        $error = 'พิกัดอยู่นอกช่วงที่ถูกต้อง';
    } else {
        $stmt = mysqli_prepare($conn, "UPDATE patient SET Firstname=?, Lastname=?, Fullname=?, Gender=?, Age=?, Weight_kg=?, Height_cm=?, Address=?, Phone=?, Disease=?, Village_id=?, Latitude=?, Longitude=? WHERE Patient_id=?");
        if (!$stmt) {
            $error = 'ไม่สามารถเตรียมข้อมูลสำหรับแก้ไขได้: ' . mysqli_error($conn);
        } else {
            mysqli_stmt_bind_param($stmt, 'ssssiddsssiddi', $firstname, $lastname, $fullname, $gender, $age, $weight, $height, $address, $phone, $disease, $villageId, $latitude, $longitude, $patientId);
            if (mysqli_stmt_execute($stmt)) {
                $message = 'แก้ไขข้อมูลผู้สูงอายุสำเร็จ';
            } else {
                $error = 'แก้ไขข้อมูลไม่สำเร็จ: ' . mysqli_stmt_error($stmt);
            }
            mysqli_stmt_close($stmt);
        }
    }
}

$stmt = mysqli_prepare($conn, "SELECT Patient_id, Firstname, Lastname, Fullname, Gender, Age, Weight_kg, Height_cm, Address, Phone, Disease, Village_id, Latitude, Longitude FROM patient WHERE Patient_id=? LIMIT 1");
mysqli_stmt_bind_param($stmt, 'i', $patientId);
mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);
$patient = $res ? mysqli_fetch_assoc($res) : null;
mysqli_stmt_close($stmt);

if (!$patient) {
    header('Location: caregiver_patients.php');
    exit;
}

if (trim((string)($patient['Firstname'] ?? '')) === '' && trim((string)($patient['Fullname'] ?? '')) !== '') {
    $parts = preg_split('/\s+/u', trim((string)$patient['Fullname']), 2);
    $patient['Firstname'] = $parts[0] ?? '';
    $patient['Lastname'] = $parts[1] ?? '';
}

// แยกที่อยู่เดิมออกเป็นฟิลด์ที่อ่านและแก้ไขง่าย โดยยังบันทึกกลับลงคอลัมน์ Address เดิม
$existingAddress = trim((string)($patient['Address'] ?? ''));
$houseNoValue = '';
$mooNoValue = '';
$addressDetailValue = '';
if ($existingAddress !== '') {
    if (preg_match('/บ้านเลขที่\s*([^\s,]+)/u', $existingAddress, $m)) $houseNoValue = trim($m[1]);
    if (preg_match('/หมู่(?:ที่)?\s*([^\s,]+)/u', $existingAddress, $m)) $mooNoValue = trim($m[1]);
    $addressDetailValue = preg_replace('/บ้านเลขที่\s*[^\s,]+/u', '', $existingAddress);
    $addressDetailValue = preg_replace('/หมู่(?:ที่)?\s*[^\s,]+/u', '', $addressDetailValue);
    $addressDetailValue = preg_replace('/ตำบล\s*ทองหลาง/u', '', $addressDetailValue);
    $addressDetailValue = preg_replace('/อำเภอ\s*จักราช/u', '', $addressDetailValue);
    $addressDetailValue = preg_replace('/จังหวัด\s*นครราชสีมา/u', '', $addressDetailValue);
    $addressDetailValue = preg_replace('/รหัสไปรษณีย์\s*30230/u', '', $addressDetailValue);
    $addressDetailValue = preg_replace('/\s+/u', ' ', trim($addressDetailValue));
}
?>
<!doctype html>
<html lang="th">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>แก้ไขข้อมูลผู้สูงอายุ | <?= e(appName()) ?></title>
<?php renderPastelTheme(); ?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Thai:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
.edit-card{background:#fff;border:1px solid #dbe9e7;border-radius:18px;box-shadow:0 5px 18px rgba(43,91,74,.045);overflow:hidden;max-width:1000px;margin:0 auto}.edit-head{padding:22px 26px;border-bottom:1px solid #edf3f1}.edit-head h1{margin:0;color:#203d33;font-size:22px}.edit-head p{margin:5px 0 0;color:#788a84;font-size:13px}.edit-body{padding:24px 26px}.form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px}.field{display:grid;gap:7px}.field.full{grid-column:1/-1}.field label{font-size:13px;font-weight:800;color:#365c52}.field input,.field select,.field textarea{width:100%;border:1px solid #cfe1dd;border-radius:12px;background:#fff;color:#27453d;font:inherit;font-size:14px;outline:none}.field input,.field select{height:44px;padding:0 13px}.field textarea{min-height:92px;padding:11px 13px;resize:vertical}.field input:focus,.field select:focus,.field textarea:focus{border-color:#68beb9;box-shadow:0 0 0 3px rgba(88,191,192,.12)}.form-actions{display:flex;justify-content:flex-end;gap:10px;margin-top:22px;padding-top:20px;border-top:1px solid #edf3f1}.btn-back,.btn-save{min-height:42px;padding:10px 18px;border-radius:12px;font:inherit;font-size:13px;font-weight:800;text-decoration:none;display:inline-flex;align-items:center;justify-content:center}.btn-back{border:1px solid #d5e5e1;background:#fff;color:#496b63}.btn-save{border:0;background:#49aeb3;color:#fff;cursor:pointer}.notice{max-width:1000px;margin:0 auto 14px;padding:12px 16px;border-radius:12px;font-size:13px;font-weight:700}.notice.ok{background:#edf9f4;color:#2c735c;border:1px solid #cfeadc}.notice.err{background:#fff1f1;color:#9c4b4b;border:1px solid #f0cccc}@media(max-width:760px){.form-grid{grid-template-columns:1fr}.field.full{grid-column:auto}.edit-body,.edit-head{padding-left:18px;padding-right:18px}.form-actions{justify-content:stretch;flex-direction:column}.btn-back,.btn-save{width:100%}}

.location-panel{grid-column:1/-1;padding:16px;border:1px solid #d7ebe7;border-radius:16px;background:#f8fcfb;display:grid;gap:13px}.location-title{display:flex;align-items:flex-start;justify-content:space-between;gap:12px}.location-title strong{color:#244f48;font-size:15px}.location-title span{display:block;margin-top:3px;color:#728a83;font-size:12px;font-weight:500}.location-search-row{display:grid;grid-template-columns:minmax(0,1fr) auto auto;gap:9px}.location-search-row input{height:46px!important}.loc-btn{border:1px solid #bcded9;border-radius:11px;padding:0 15px;background:#fff;color:#2f6964;font:inherit;font-size:13px;font-weight:800;cursor:pointer;white-space:nowrap}.loc-btn.primary{background:#58babc;border-color:#58babc;color:#fff}.loc-btn:disabled{opacity:.55;cursor:wait}.location-status{font-size:12px;color:#6b817b;min-height:18px}.location-results{display:none;border:1px solid #d7e7e3;border-radius:12px;background:#fff;overflow:hidden}.location-results.show{display:block}.location-result{display:block;width:100%;padding:11px 13px;border:0;border-bottom:1px solid #edf3f1;background:#fff;text-align:left;font:inherit;color:#2d4c45;cursor:pointer}.location-result:last-child{border-bottom:0}.location-result:hover{background:#f0faf8}.location-result strong{display:block;font-size:13px}.location-result small{display:block;margin-top:3px;color:#7a8e88;line-height:1.4}.location-map{height:360px;width:100%;min-width:0;position:relative;border:1px solid #d6e6e2;border-radius:14px;overflow:hidden;background:#eef7f5}.location-map.leaflet-container{width:100%!important;height:360px!important}.location-map .leaflet-map-pane,.location-map .leaflet-tile-pane{width:100%;height:100%}.location-map .leaflet-tile{max-width:none!important;max-height:none!important}.location-map .leaflet-control-zoom{box-shadow:0 4px 14px rgba(32,79,75,.12)}.coord-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.location-hint{font-size:12px;color:#728780;line-height:1.6}.leaflet-container{font-family:'Noto Sans Thai',sans-serif}.field textarea.address-box{min-height:82px}.location-source{font-size:11px;color:#8a9c97;text-align:right}@media(max-width:760px){.location-search-row{grid-template-columns:1fr}.loc-btn{min-height:42px}.coord-grid{grid-template-columns:1fr}.location-map{height:300px!important}} .location-map iframe{width:100%;height:100%;border:0;display:block}
.google-map-heading{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-top:4px}.google-map-heading strong{display:block;color:#244f48;font-size:15px}.google-map-heading span{display:block;margin-top:3px;color:#728a83;font-size:12px}.google-map-open{display:inline-flex;align-items:center;justify-content:center;min-height:38px;padding:8px 13px;border:1px solid #bcded9;border-radius:10px;background:#fff;color:#2f6964;text-decoration:none;font-size:12px;font-weight:800;white-space:nowrap}.google-map-open:hover{background:#eef9f7}.home-coordinate-title{margin:16px 0 0;padding-top:14px;border-top:1px solid #dcebe8;font-size:15px;font-weight:900;color:#315f5d}@media(max-width:760px){.google-map-heading{align-items:stretch;flex-direction:column}.google-map-open{width:100%}}

/* address layout */
.section-block{grid-column:1/-1;border:1px solid #deece9;border-radius:16px;background:#fbfdfd;padding:18px 18px 16px;display:grid;gap:15px}
.section-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;padding-bottom:12px;border-bottom:1px solid #e9f1ef}
.section-head strong{font-size:15px;color:#244f48}.section-head span{display:block;margin-top:3px;font-size:12px;color:#7b8f89;font-weight:500}
.address-grid{display:grid;grid-template-columns:160px 160px minmax(0,1fr);gap:12px}
.address-fixed-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}
.readonly-box{height:44px;display:flex;align-items:center;padding:0 13px;border:1px solid #d7e5e2;border-radius:12px;background:#f4f8f7;color:#55736b;font-size:14px}
.address-preview{padding:11px 13px;border:1px dashed #bfd9d4;border-radius:12px;background:#f5fbfa;color:#3b6259;font-size:13px;line-height:1.6}
.address-preview b{color:#244f48}
@media(max-width:900px){.address-grid{grid-template-columns:1fr 1fr}.address-grid .detail{grid-column:1/-1}.address-fixed-grid{grid-template-columns:1fr 1fr}}
@media(max-width:600px){.address-grid,.address-fixed-grid{grid-template-columns:1fr}.address-grid .detail{grid-column:auto}}
</style>
</head>
<body class="role-page">
<?php renderSidebar(); ?>
<main class="main">
    <?php renderUserTopbar(); ?>

    <?php if ($error): ?><div class="notice err"><?= e($error) ?></div><?php endif; ?>
    <?php if ($message): ?><div class="notice ok"><?= e($message) ?></div><?php endif; ?>

    <section class="edit-card">
        <div class="edit-head">
            <h1>แก้ไขข้อมูลผู้สูงอายุ</h1>
            <p>แก้ไขข้อมูลของผู้สูงอายุที่อยู่ในความดูแลของคุณ</p>
        </div>
        <form method="post" class="edit-body">
            <input type="hidden" name="patient_id" value="<?= (int)$patientId ?>">
            <div class="form-grid">
                <div class="field"><label>ชื่อ</label><input type="text" name="Firstname" value="<?= e($patient['Firstname'] ?? '') ?>" required></div>
                <div class="field"><label>นามสกุล</label><input type="text" name="Lastname" value="<?= e($patient['Lastname'] ?? '') ?>"></div>
                <div class="field"><label>เพศ</label><select name="Gender"><option value="">ไม่ระบุ</option><option value="ชาย" <?= ($patient['Gender'] ?? '')==='ชาย'?'selected':'' ?>>ชาย</option><option value="หญิง" <?= ($patient['Gender'] ?? '')==='หญิง'?'selected':'' ?>>หญิง</option></select></div>
                <div class="field"><label>อายุ</label><input type="number" name="Age" min="0" max="130" value="<?= (int)($patient['Age'] ?? 0) ?>"></div>
                <div class="field"><label>น้ำหนัก (กก.)</label><input type="number" step="0.1" min="0" name="Weight_kg" value="<?= e($patient['Weight_kg'] ?? '') ?>"></div>
                <div class="field"><label>ส่วนสูง (ซม.)</label><input type="number" step="0.1" min="0" name="Height_cm" value="<?= e($patient['Height_cm'] ?? '') ?>"></div>
                <div class="field"><label>หมู่บ้าน</label><select name="Village_id" id="Village_id"><option value="0">ไม่ระบุ</option><?php foreach($villages as $v): ?><option value="<?= (int)$v['village_id'] ?>" <?= (int)($patient['Village_id'] ?? 0)===(int)$v['village_id']?'selected':'' ?>><?= e($v['villagename'] ?? '-') ?></option><?php endforeach; ?></select></div>
                <div class="field"><label>เบอร์โทรศัพท์</label><input type="text" name="Phone" value="<?= e($patient['Phone'] ?? '') ?>"></div>

                <div class="field full"><label>โรคประจำตัว</label><input type="text" name="Disease" value="<?= e($patient['Disease'] ?? '') ?>" placeholder="เช่น ความดัน หรือ เบาหวาน"></div>

                <div class="section-block">
                    <div class="section-head">
                        <div><strong>ที่อยู่</strong><span>แยกข้อมูลเป็นช่องเพื่อแก้ไขง่าย และระบบจะรวมเป็นที่อยู่เต็มให้อัตโนมัติ</span></div>
                    </div>
                    <div class="address-grid">
                        <div class="field"><label>บ้านเลขที่</label><input type="text" name="House_no" id="House_no" value="<?= e($houseNoValue) ?>" placeholder="เช่น 52"></div>
                        <div class="field"><label>หมู่ที่</label><input type="text" name="Moo_no" id="Moo_no" value="<?= e($mooNoValue) ?>" placeholder="เช่น 5"></div>
                        <div class="field detail"><label>รายละเอียดที่อยู่เพิ่มเติม</label><input type="text" name="Address_detail" id="Address_detail" value="<?= e($addressDetailValue) ?>" placeholder="เช่น ซอย ถนน หรือจุดสังเกต (ถ้ามี)"></div>
                    </div>
                    <div class="address-fixed-grid">
                        <div class="field"><label>ตำบล</label><div class="readonly-box">ทองหลาง</div></div>
                        <div class="field"><label>อำเภอ</label><div class="readonly-box">จักราช</div></div>
                        <div class="field"><label>จังหวัด</label><div class="readonly-box">นครราชสีมา</div></div>
                        <div class="field"><label>รหัสไปรษณีย์</label><div class="readonly-box">30230</div></div>
                    </div>
                    <input type="hidden" name="Address" id="Address" value="<?= e($patient['Address'] ?? '') ?>">
                    <div class="address-preview" id="addressPreview"><b>ที่อยู่เต็ม:</b> <?= e($patient['Address'] ?? '-') ?></div>
                </div>

                <div class="location-panel">
                    <div class="location-title">
                        <div><strong>ค้นหาพิกัดจากชื่อหมู่บ้าน</strong><span>ค้นหาเฉพาะหมู่บ้านใน ตำบลทองหลาง อำเภอจักราช จังหวัดนครราชสีมา</span></div>
                    </div>
                    <div class="location-search-row">
                        <input type="text" id="locationSearch" list="villageNameList" placeholder="พิมพ์ชื่อหมู่บ้าน เช่น บ้านตูม" autocomplete="off">
                        <datalist id="villageNameList"><?php foreach($villages as $v): ?><option value="<?= e($v['villagename'] ?? '') ?>"><?php endforeach; ?></datalist>
                        <button type="button" class="loc-btn primary" id="locationSearchBtn">ค้นหาตำแหน่ง</button>
                        <button type="button" class="loc-btn" id="useCurrentLocation">ตำแหน่งปัจจุบัน</button>
                    </div>
                    <div class="location-status" id="locationStatus">พิมพ์หรือเลือกชื่อหมู่บ้านจากรายการแนะนำ แล้วกด “ค้นหาตำแหน่ง”</div>
                    <div class="location-results" id="locationResults"></div>
                    <div class="google-map-heading">
                        <div>
                            <strong>Google Maps ตำบลทองหลาง</strong>
                            <span>แผนที่อ้างอิงตำบลทองหลาง อำเภอจักราช จังหวัดนครราชสีมา</span>
                        </div>
                        <a class="google-map-open" href="https://www.google.com/maps/place/Thong+Lang,+Chakkarat+District,+Nakhon+Ratchasima+30230/@15.0510075,102.3122145,13z/data=!3m1!4b1!4m6!3m5!1s0x311940b16b6ffbbb:0x40469cfc8dee620!8m2!3d15.0547605!4d102.3578423!16s%2Fg%2F11t1sfh_8l?authuser=0&entry=ttu" target="_blank" rel="noopener">เปิดใน Google Maps</a>
                    </div>
                    <div class="location-map" id="locationMap"><iframe id="googleMapFrame" title="Google Maps ตำบลทองหลาง" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen></iframe></div>
                    <div class="home-coordinate-title">พิกัดบ้าน</div>
                    <div class="coord-grid">
                        <div class="field"><label>ละติจูด (Latitude)</label><input type="text" inputmode="decimal" name="Latitude" id="Latitude" value="<?= e($patient['Latitude'] ?? '') ?>" placeholder="เช่น 15.0554928"></div>
                        <div class="field"><label>ลองจิจูด (Longitude)</label><input type="text" inputmode="decimal" name="Longitude" id="Longitude" value="<?= e($patient['Longitude'] ?? '') ?>" placeholder="เช่น 102.3666683"></div>
                    </div>
                    <div class="location-hint">เลือกผลการค้นหาแล้วแผนที่ Google Maps จะเลื่อนไปยังพิกัดนั้น สามารถแก้ไขละติจูดและลองจิจูดก่อนบันทึกได้</div>
                    <div class="location-source">แผนที่จาก Google Maps • ตำบลทองหลาง อำเภอจักราช จังหวัดนครราชสีมา</div>
                </div>

            </div>
            <div class="form-actions">
                <a class="btn-back" href="caregiver_patients.php">ย้อนกลับ</a>
                <button class="btn-save" type="submit">บันทึกการแก้ไข</button>
            </div>
        </form>
    </section>
</main>
<script>
(function(){
    const apiUrl = '../api/location_search.php';
    const searchInput = document.getElementById('locationSearch');
    const searchBtn = document.getElementById('locationSearchBtn');
    const currentBtn = document.getElementById('useCurrentLocation');
    const statusEl = document.getElementById('locationStatus');
    const resultsEl = document.getElementById('locationResults');
    const latInput = document.getElementById('Latitude');
    const lonInput = document.getElementById('Longitude');
    const addressInput = document.getElementById('Address');
    const villageSelect = document.getElementById('Village_id');
    const houseNoInput = document.getElementById('House_no');
    const mooNoInput = document.getElementById('Moo_no');
    const addressDetailInput = document.getElementById('Address_detail');
    const addressPreview = document.getElementById('addressPreview');

    function composeAddress(){
        const parts = [];
        const houseNo = (houseNoInput?.value || '').trim();
        const mooNo = (mooNoInput?.value || '').trim();
        const detail = (addressDetailInput?.value || '').trim();
        if (houseNo) parts.push('บ้านเลขที่ ' + houseNo);
        if (mooNo) parts.push('หมู่ที่ ' + mooNo);
        if (detail) parts.push(detail);
        parts.push('ตำบล ทองหลาง', 'อำเภอ จักราช', 'จังหวัด นครราชสีมา', 'รหัสไปรษณีย์ 30230');
        const full = parts.join(' ');
        if (addressInput) addressInput.value = full;
        if (addressPreview) addressPreview.innerHTML = '<b>ที่อยู่เต็ม:</b> ' + full.replace(/</g,'&lt;').replace(/>/g,'&gt;');
        return full;
    }
    [houseNoInput, mooNoInput, addressDetailInput].forEach(el => el && el.addEventListener('input', composeAddress));
    composeAddress();
    const editForm = document.querySelector('form.edit-card');
    if (editForm) editForm.addEventListener('submit', composeAddress);

    const initialLat = parseFloat(latInput.value);
    const initialLon = parseFloat(lonInput.value);
    const hasInitial = Number.isFinite(initialLat) && Number.isFinite(initialLon);
    const mapFrame = document.getElementById('googleMapFrame');
    const THONGLANG_LAT = 15.0547605;
    const THONGLANG_LON = 102.3578423;

    function updateGoogleMap(lat, lon, zoom=16){
        lat = Number(lat); lon = Number(lon);
        if (!Number.isFinite(lat) || !Number.isFinite(lon)) { lat = THONGLANG_LAT; lon = THONGLANG_LON; zoom = 13; }
        const q = encodeURIComponent(lat.toFixed(7) + ',' + lon.toFixed(7));
        mapFrame.src = 'https://www.google.com/maps?q=' + q + '&z=' + encodeURIComponent(zoom) + '&output=embed';
    }
    updateGoogleMap(hasInitial ? initialLat : THONGLANG_LAT, hasInitial ? initialLon : THONGLANG_LON, hasInitial ? 16 : 13);
    function setStatus(text, isError){
        statusEl.textContent = text || '';
        statusEl.style.color = isError ? '#a34f4f' : '#6b817b';
    }
    function setBusy(btn, busy, text){
        if (!btn) return;
        if (busy) { btn.dataset.oldText = btn.textContent; btn.textContent = text || 'กำลังค้นหา...'; btn.disabled = true; }
        else { btn.textContent = btn.dataset.oldText || btn.textContent; btn.disabled = false; }
    }
    function normalizeText(v){ return String(v || '').trim().toLowerCase().replace(/\s+/g,''); }
    function tryMatchVillage(address){
        if (!villageSelect || !address) return;
        const candidates = [address.village,address.hamlet,address.suburb,address.neighbourhood,address.quarter,address.town,address.city_district].filter(Boolean);
        if (!candidates.length) return;
        const opts = Array.from(villageSelect.options);
        for (const candidate of candidates) {
            const c = normalizeText(candidate).replace(/^บ้าน/,'');
            const found = opts.find(o => {
                const t = normalizeText(o.textContent).replace(/^บ้าน/,'');
                return t && (t === c || t.includes(c) || c.includes(t));
            });
            if (found) { villageSelect.value = found.value; break; }
        }
    }
    function placeMarker(lat, lon, pan=true){
        lat = Number(lat); lon = Number(lon);
        if (!Number.isFinite(lat) || !Number.isFinite(lon)) return;
        updateGoogleMap(lat, lon, pan ? 16 : 15);
    }
    async function reverseLookup(lat, lon){
        setStatus('กำลังดึงที่อยู่ใกล้เคียงจากพิกัด...');
        try {
            const r = await fetch(apiUrl + '?action=reverse&lat=' + encodeURIComponent(lat) + '&lon=' + encodeURIComponent(lon), {headers:{'Accept':'application/json'}});
            const data = await r.json();
            if (!data.ok) throw new Error(data.message || 'ไม่พบข้อมูลที่อยู่');
            const item = data.result || {};
            if (item.display_name) { /* ใช้ผลพิกัดเพื่ออ้างอิง แต่คงรูปแบบที่อยู่แบบแยกฟิลด์ */ composeAddress(); }
            tryMatchVillage(item.address || {});
            setStatus('ดึงที่อยู่ใกล้เคียงสำเร็จ สามารถแก้ไขข้อความที่อยู่ก่อนบันทึกได้');
        } catch (e) {
            setStatus(e.message || 'ไม่สามารถดึงที่อยู่จากพิกัดได้ แต่ยังบันทึกพิกัดได้', true);
        }
    }
    async function updateCoordinates(lat, lon, doReverse){
        latInput.value = Number(lat).toFixed(7);
        lonInput.value = Number(lon).toFixed(7);
        placeMarker(lat,lon,true);
        if (doReverse) await reverseLookup(lat,lon);
    }
    function renderResults(items){
        resultsEl.innerHTML = '';
        if (!items || !items.length) { resultsEl.classList.remove('show'); setStatus('ไม่พบชื่อหมู่บ้านนี้ในข้อมูลแผนที่ กรุณาตรวจสอบชื่อหมู่บ้าน หรือเลือกชื่อจากรายการแนะนำ', true); return; }
        items.forEach((item, idx) => {
            const btn = document.createElement('button');
            btn.type = 'button'; btn.className = 'location-result';
            const name = item.name || item.display_name || ('ผลลัพธ์ ' + (idx+1));
            const detail = item.display_name || '';
            btn.innerHTML = '<strong></strong><small></small>';
            btn.querySelector('strong').textContent = name;
            btn.querySelector('small').textContent = detail;
            btn.addEventListener('click', () => {
                const lat = parseFloat(item.lat), lon = parseFloat(item.lon);
                latInput.value = lat.toFixed(7); lonInput.value = lon.toFixed(7);
                addressInput.value = item.display_name || addressInput.value;
                tryMatchVillage(item.address || {});
                placeMarker(lat,lon,true);
                resultsEl.classList.remove('show');
                setStatus('เลือกตำแหน่งในตำบลทองหลางแล้ว แผนที่ Google Maps แสดงตำแหน่งที่เลือกเรียบร้อย');
            });
            resultsEl.appendChild(btn);
        });
        resultsEl.classList.add('show');
        setStatus('พบ ' + items.length + ' ตำแหน่ง กรุณาเลือกชื่อหมู่บ้านที่ถูกต้อง');
    }
    function matchVillageFromSearch(q){
        if (!villageSelect || !q) return;
        const c = normalizeText(q).replace(/^บ้าน/,'').replace(/หมู่(?:ที่)?\d+$/,'');
        const opts = Array.from(villageSelect.options);
        const found = opts.find(o => {
            const t = normalizeText(o.textContent).replace(/^บ้าน/,'').replace(/หมู่(?:ที่)?\d+$/,'');
            return t && (t === c || t.includes(c) || c.includes(t));
        });
        if (found) villageSelect.value = found.value;
    }
    async function searchLocation(){
        const q = searchInput.value.trim();
        if (q.length < 2) { setStatus('กรุณาพิมพ์ชื่อหมู่บ้านอย่างน้อย 2 ตัวอักษร', true); searchInput.focus(); return; }
        matchVillageFromSearch(q);
        setBusy(searchBtn,true,'กำลังค้นหา...');
        resultsEl.classList.remove('show');
        setStatus('กำลังค้นหาตำแหน่งจาก API...');
        try {
            const r = await fetch(apiUrl + '?action=search&q=' + encodeURIComponent(q), {headers:{'Accept':'application/json'}});
            const data = await r.json();
            if (!data.ok) throw new Error(data.message || 'ค้นหาไม่สำเร็จ');
            renderResults(data.results || []);
        } catch(e) { setStatus(e.message || 'ไม่สามารถค้นหาตำแหน่งได้', true); }
        finally { setBusy(searchBtn,false); }
    }
    searchBtn.addEventListener('click', searchLocation);
    searchInput.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); searchLocation(); } });
    currentBtn.addEventListener('click', function(){
        if (!navigator.geolocation) { setStatus('เบราว์เซอร์นี้ไม่รองรับการอ่านตำแหน่งปัจจุบัน', true); return; }
        setBusy(currentBtn,true,'กำลังระบุตำแหน่ง...');
        setStatus('กรุณาอนุญาตให้เบราว์เซอร์เข้าถึงตำแหน่ง');
        navigator.geolocation.getCurrentPosition(async pos => {
            setBusy(currentBtn,false);
            await updateCoordinates(pos.coords.latitude, pos.coords.longitude, true);
        }, err => {
            setBusy(currentBtn,false);
            const msg = err.code === 1 ? 'ไม่ได้รับอนุญาตให้ใช้ตำแหน่ง กรุณากด Allow ในเบราว์เซอร์' : 'ไม่สามารถอ่านตำแหน่งปัจจุบันได้';
            setStatus(msg, true);
        }, {enableHighAccuracy:true, timeout:12000, maximumAge:30000});
    });
    function syncManual(){
        const lat = parseFloat(latInput.value), lon = parseFloat(lonInput.value);
        if (Number.isFinite(lat) && Number.isFinite(lon)) placeMarker(lat,lon,false);
    }
    latInput.addEventListener('change',syncManual); lonInput.addEventListener('change',syncManual);
    if (hasInitial) placeMarker(initialLat,initialLon,false);
})();
</script>
</body>
</html>
