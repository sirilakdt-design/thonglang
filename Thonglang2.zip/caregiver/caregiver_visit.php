<?php
require_once __DIR__ . '/../connect.php';
requireRole('caregiver');
mysqli_set_charset($conn, 'utf8mb4');

$caregiverId = (int)($_SESSION['user_id'] ?? 0);
$message = '';
$error = '';
$showSuccessScreen = false;
$successVisit = null;

function visitTableExists(mysqli $conn, string $table): bool {
    $safe = mysqli_real_escape_string($conn, $table);
    $res = mysqli_query($conn, "SHOW TABLES LIKE '{$safe}'");
    return $res && mysqli_num_rows($res) > 0;
}

function visitColumnExists(mysqli $conn, string $table, string $column): bool {
    $safeTable = str_replace('`','',$table);
    $safeColumn = mysqli_real_escape_string($conn, $column);
    $res = mysqli_query($conn, "SHOW COLUMNS FROM `{$safeTable}` LIKE '{$safeColumn}'");
    return $res && mysqli_num_rows($res) > 0;
}

function visitEnsureColumn(mysqli $conn, string $table, string $column, string $definition): void {
    if (!visitColumnExists($conn, $table, $column)) {
        @mysqli_query($conn, "ALTER TABLE `{$table}` ADD COLUMN `{$column}` {$definition}");
    }
}

$createVisitSql = "CREATE TABLE IF NOT EXISTS caregiver_visit_record (
    visit_id INT AUTO_INCREMENT PRIMARY KEY,
    assignment_id INT NOT NULL,
    patient_id INT NOT NULL,
    caregiver_user_id INT NOT NULL,
    visit_date DATE NOT NULL,
    visit_time TIME NULL,
    visit_no INT NULL,
    visit_type VARCHAR(40) NOT NULL DEFAULT 'เยี่ยมตามแผน',
    purpose TEXT NULL,
    general_condition VARCHAR(80) NULL,
    bp_systolic SMALLINT NULL,
    bp_diastolic SMALLINT NULL,
    pulse SMALLINT NULL,
    temperature DECIMAL(4,1) NULL,
    respiratory_rate SMALLINT NULL,
    spo2 DECIMAL(5,2) NULL,
    weight_kg DECIMAL(7,2) NULL,
    height_cm DECIMAL(7,2) NULL,
    symptom_notes TEXT NULL,
    disease_snapshot TEXT NULL,
    medicine_text TEXT NULL,
    medication_status VARCHAR(80) NULL,
    nutrition_status VARCHAR(80) NULL,
    adl_status VARCHAR(100) NULL,
    mobility_status VARCHAR(80) NULL,
    fall_risk VARCHAR(40) NULL,
    skin_wound TEXT NULL,
    mental_status VARCHAR(80) NULL,
    caregiver_contact VARCHAR(180) NULL,
    problem_notes TEXT NULL,
    home_safety TEXT NULL,
    care_actions TEXT NULL,
    advice TEXT NULL,
    referral_type VARCHAR(80) NULL,
    doctor_referral TINYINT(1) NOT NULL DEFAULT 0,
    referral_reason TEXT NULL,
    next_visit_date DATE NULL,
    note TEXT NULL,
    visit_photo VARCHAR(255) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NULL,
    KEY idx_visit_patient (patient_id),
    KEY idx_visit_caregiver (caregiver_user_id),
    KEY idx_visit_date (visit_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if (!mysqli_query($conn, $createVisitSql)) {
    $error = 'ไม่สามารถเตรียมตารางบันทึกการเข้าเยี่ยมได้: ' . mysqli_error($conn);
} else {
    $columns = [
        'visit_no' => 'INT NULL',
        'purpose' => 'TEXT NULL',
        'height_cm' => 'DECIMAL(7,2) NULL',
        'disease_snapshot' => 'TEXT NULL',
        'medicine_text' => 'TEXT NULL',
        'adl_status' => 'VARCHAR(100) NULL',
        'caregiver_contact' => 'VARCHAR(180) NULL',
        'problem_notes' => 'TEXT NULL',
        'referral_type' => 'VARCHAR(80) NULL',
        'visit_photo' => 'VARCHAR(255) NULL',
    ];
    foreach ($columns as $name => $definition) visitEnsureColumn($conn, 'caregiver_visit_record', $name, $definition);
}

$assignments = [];
if ($error === '' && $caregiverId > 0) {
    $sql = "SELECT a.assignment_id,a.patient_id,a.next_visit_date,a.care_status,
                   p.Fullname,p.Age,p.Gender,p.Phone,p.Disease,p.Address,p.Weight_kg,p.Height_cm,p.Latitude,p.Longitude,
                   v.villagename,
                   dr.display_name AS doctor_name,dr.username AS doctor_username
            FROM patient_caregiver_assignment a
            JOIN patient p ON p.Patient_id=a.patient_id
            LEFT JOIN village v ON v.village_id=p.Village_id
            LEFT JOIN users dr ON dr.user_id=a.doctor_user_id AND dr.role='doctor'
            WHERE a.caregiver_user_id=?
              AND COALESCE(a.care_status,'กำลังดูแล') <> 'สิ้นสุดการดูแล'
            ORDER BY p.Fullname ASC";
    $stmt = mysqli_prepare($conn, $sql);
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'i', $caregiverId);
        mysqli_stmt_execute($stmt);
        $res = mysqli_stmt_get_result($stmt);
        while ($res && ($row = mysqli_fetch_assoc($res))) $assignments[] = $row;
        mysqli_stmt_close($stmt);
    } else {
        $error = 'ไม่สามารถดึงรายชื่อผู้สูงอายุที่อยู่ในความดูแลได้: ' . mysqli_error($conn);
    }
}

$selectedAssignmentId = (int)($_GET['assignment_id'] ?? $_POST['assignment_id'] ?? 0);
$selected = null;
foreach ($assignments as $a) {
    if ((int)$a['assignment_id'] === $selectedAssignmentId) { $selected = $a; break; }
}
$visitMode = (string)($_GET['mode'] ?? '');
if (!in_array($visitMode, ['', 'history'], true)) $visitMode = '';

function postText(string $name): string { return trim((string)($_POST[$name] ?? '')); }
function postIntOrNull(string $name): ?int { $v=postText($name); return $v===''?null:(int)$v; }
function postFloatOrNull(string $name): ?float { $v=postText($name); return $v===''?null:(float)$v; }

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_visit' && $error === '') {
    $assignmentId = (int)($_POST['assignment_id'] ?? 0);
    $owned = null;
    foreach ($assignments as $a) if ((int)$a['assignment_id'] === $assignmentId) { $owned=$a; break; }

    $visitDate = postText('visit_date');
    $visitTime = postText('visit_time');
    $visitNo = postIntOrNull('visit_no');
    $visitType = postText('visit_type');
    $purpose = postText('purpose');
    $generalCondition = postText('general_condition');
    $bpSys = postIntOrNull('bp_systolic');
    $bpDia = postIntOrNull('bp_diastolic');
    $pulse = postIntOrNull('pulse');
    $temp = postFloatOrNull('temperature');
    $resp = postIntOrNull('respiratory_rate');
    $spo2 = postFloatOrNull('spo2');
    $weight = postFloatOrNull('weight_kg');
    $height = postFloatOrNull('height_cm');
    $symptoms = postText('symptom_notes');
    $diseaseSnapshot = postText('disease_snapshot');
    $medicineText = postText('medicine_text');
    $medication = postText('medication_status');
    $nutrition = postText('nutrition_status');
    $adlStatus = postText('adl_status');
    $mobility = postText('mobility_status');
    $fallRisk = postText('fall_risk');
    $skinWound = postText('skin_wound');
    $mental = postText('mental_status');
    $caregiverContact = postText('caregiver_contact');
    $problemNotes = postText('problem_notes');
    $homeSafety = postText('home_safety');
    $careActions = postText('care_actions');
    $advice = postText('advice');
    $referralType = postText('referral_type');
    $doctorReferral = ($referralType !== '' && $referralType !== 'ไม่ส่งต่อ') ? 1 : 0;
    $referralReason = postText('referral_reason');
    $nextVisitDate = postText('next_visit_date');
    $note = postText('note');
    $patientLatitudeRaw = postText('patient_latitude');
    $patientLongitudeRaw = postText('patient_longitude');
    $patientLatitude = null;
    $patientLongitude = null;

    if (!$owned) {
        $error = 'ไม่พบรายการผู้สูงอายุที่อยู่ในความดูแลของบัญชีนี้';
    } elseif ($visitDate === '') {
        $error = 'กรุณาระบุวันที่เข้าเยี่ยม';
    } elseif ($visitType === '') {
        $error = 'กรุณาเลือกประเภทการเข้าเยี่ยม';
    } elseif ($doctorReferral && $referralReason === '') {
        $error = 'กรุณาระบุเหตุผลที่ต้องส่งต่อ';
    } else {
        if ($patientLatitudeRaw !== '' || $patientLongitudeRaw !== '') {
            if ($patientLatitudeRaw === '' || $patientLongitudeRaw === '') {
                $error = 'กรุณากรอกละติจูดและลองจิจูดให้ครบถ้วน';
            } elseif (!is_numeric($patientLatitudeRaw) || !is_numeric($patientLongitudeRaw)) {
                $error = 'ค่าละติจูดและลองจิจูดต้องเป็นตัวเลขเท่านั้น';
            } else {
                $patientLatitude = (float)$patientLatitudeRaw;
                $patientLongitude = (float)$patientLongitudeRaw;
                if ($patientLatitude < -90 || $patientLatitude > 90) $error = 'ละติจูดต้องอยู่ระหว่าง -90 ถึง 90';
                if ($error === '' && ($patientLongitude < -180 || $patientLongitude > 180)) $error = 'ลองจิจูดต้องอยู่ระหว่าง -180 ถึง 180';
            }
        }
        if ($error === '') {
            $visitPhotoUpload = thonglangHandleImageUpload('visit_photo_file', 'visit_photos');
            if (!empty($visitPhotoUpload['error'])) {
                $error = (string)$visitPhotoUpload['error'];
            }
        }
    }

    if ($error === '' && $owned) {
        $patientId = (int)$owned['patient_id'];
        $sql = "INSERT INTO caregiver_visit_record (
                    assignment_id,patient_id,caregiver_user_id,visit_date,visit_time,visit_no,visit_type,purpose,general_condition,
                    bp_systolic,bp_diastolic,pulse,temperature,respiratory_rate,spo2,weight_kg,height_cm,
                    symptom_notes,disease_snapshot,medicine_text,medication_status,nutrition_status,adl_status,mobility_status,fall_risk,
                    skin_wound,mental_status,caregiver_contact,problem_notes,home_safety,care_actions,advice,referral_type,doctor_referral,
                    referral_reason,next_visit_date,note
                ) VALUES (?,?,?,?,NULLIF(?,''),?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NULLIF(?,''),?)";
        $stmt = mysqli_prepare($conn, $sql);
        if ($stmt) {
            $types = 'iiississsiiididddssssssssssssssssisss';
            mysqli_stmt_bind_param($stmt, $types,
                $assignmentId,$patientId,$caregiverId,$visitDate,$visitTime,$visitNo,$visitType,$purpose,$generalCondition,
                $bpSys,$bpDia,$pulse,$temp,$resp,$spo2,$weight,$height,
                $symptoms,$diseaseSnapshot,$medicineText,$medication,$nutrition,$adlStatus,$mobility,$fallRisk,
                $skinWound,$mental,$caregiverContact,$problemNotes,$homeSafety,$careActions,$advice,$referralType,$doctorReferral,
                $referralReason,$nextVisitDate,$note
            );
            if (mysqli_stmt_execute($stmt)) {
                $newVisitId = (int)mysqli_insert_id($conn);
                if ($patientLatitudeRaw === '' && $patientLongitudeRaw === '') {
                    $coordStmt = mysqli_prepare($conn, "UPDATE patient SET Latitude=NULL, Longitude=NULL WHERE Patient_id=?");
                    if ($coordStmt) {
                        mysqli_stmt_bind_param($coordStmt, 'i', $patientId);
                        mysqli_stmt_execute($coordStmt);
                        mysqli_stmt_close($coordStmt);
                    }
                } elseif ($patientLatitude !== null && $patientLongitude !== null) {
                    $coordStmt = mysqli_prepare($conn, "UPDATE patient SET Latitude=?, Longitude=? WHERE Patient_id=?");
                    if ($coordStmt) {
                        mysqli_stmt_bind_param($coordStmt, 'ddi', $patientLatitude, $patientLongitude, $patientId);
                        mysqli_stmt_execute($coordStmt);
                        mysqli_stmt_close($coordStmt);
                    }
                }
                $visitPhotoPath = !empty($visitPhotoUpload['uploaded']) ? (string)($visitPhotoUpload['path'] ?? '') : '';
                if ($visitPhotoPath !== '') {
                    $photoStmt = mysqli_prepare($conn, "UPDATE caregiver_visit_record SET visit_photo=? WHERE visit_id=? AND caregiver_user_id=?");
                    if ($photoStmt) {
                        mysqli_stmt_bind_param($photoStmt, 'sii', $visitPhotoPath, $newVisitId, $caregiverId);
                        if (!mysqli_stmt_execute($photoStmt)) {
                            thonglangDeleteUploadedFile($visitPhotoPath);
                            $visitPhotoPath = '';
                        }
                        mysqli_stmt_close($photoStmt);
                    } else {
                        thonglangDeleteUploadedFile($visitPhotoPath);
                        $visitPhotoPath = '';
                    }
                }
                $message = 'บันทึกการเข้าเยี่ยมเสร็จสิ้นแล้ว';
                $showSuccessScreen = true;
                $successVisit = [
                    'visit_id' => $newVisitId,
                    'Fullname' => (string)($owned['Fullname'] ?? '-'),
                    'visit_date' => $visitDate,
                    'visit_time' => $visitTime,
                    'visit_type' => $visitType,
                    'next_visit_date' => $nextVisitDate,
                    'doctor_referral' => $doctorReferral,
                    'referral_type' => $referralType,
                    'visit_photo' => $visitPhotoPath,
                ];
                if ($nextVisitDate !== '') {
                    $u = mysqli_prepare($conn, "UPDATE patient_caregiver_assignment SET next_visit_date=? WHERE assignment_id=? AND caregiver_user_id=?");
                    if ($u) { mysqli_stmt_bind_param($u,'sii',$nextVisitDate,$assignmentId,$caregiverId); mysqli_stmt_execute($u); mysqli_stmt_close($u); }
                }
            } else {
                if (!empty($visitPhotoUpload['uploaded']) && !empty($visitPhotoUpload['path'])) {
                    thonglangDeleteUploadedFile((string)$visitPhotoUpload['path']);
                }
                $error = 'บันทึกไม่สำเร็จ: ' . mysqli_stmt_error($stmt);
            }
            mysqli_stmt_close($stmt);
        } else {
            $error = 'ไม่สามารถเตรียมคำสั่งบันทึกได้: ' . mysqli_error($conn);
        }
    }
}

$history = [];
if ($caregiverId > 0 && visitTableExists($conn, 'caregiver_visit_record')) {
    $sql = "SELECT vr.*,p.Fullname,v.villagename
            FROM caregiver_visit_record vr
            JOIN patient p ON p.Patient_id=vr.patient_id
            LEFT JOIN village v ON v.village_id=p.Village_id
            WHERE vr.caregiver_user_id=?
            ORDER BY vr.visit_date DESC, COALESCE(vr.visit_time,'00:00:00') DESC, vr.visit_id DESC";
    $stmt = mysqli_prepare($conn, $sql);
    if ($stmt) {
        mysqli_stmt_bind_param($stmt,'i',$caregiverId); mysqli_stmt_execute($stmt);
        $res=mysqli_stmt_get_result($stmt); while($res && ($r=mysqli_fetch_assoc($res))) $history[]=$r;
        mysqli_stmt_close($stmt);
    }
}

function thDate(?string $v): string {
    if (!$v) return '-'; $ts=strtotime($v); if(!$ts) return $v;
    return date('d/m/', $ts).((int)date('Y',$ts)+543);
}
?>
<!doctype html>
<html lang="th">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>บันทึกการเข้าเยี่ยมผู้สูงอายุ | <?= e(appName()) ?></title>
<?php renderPastelTheme(); ?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Thai:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIINfQ3yn5HaRdWCJeZ7" crossorigin="">
<style>
.visit-page{display:grid;gap:18px}.visit-page.visit-center-selection{min-height:calc(100vh - 190px);display:flex;align-items:center;justify-content:center}.visit-page.visit-center-selection .visit-layout{width:100%}.visit-page.visit-center-selection .visit-card{margin:0 auto}.visit-head{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;padding:22px 24px;border:1px solid #d8ebe8;border-radius:22px;background:linear-gradient(135deg,#f4fbfb,#eef9f7);box-shadow:0 12px 30px rgba(36,108,115,.06)}.visit-head h1{margin:0;color:#1e5055;font-size:28px}.visit-head p{margin:7px 0 0;color:#708986;line-height:1.6}.visit-head-chip{padding:8px 12px;border-radius:999px;background:#fff;border:1px solid #d6e9e6;color:#2b6668;font-size:12px;font-weight:800}.visit-layout{display:block}.visit-card{width:100%;background:#fff;border:1px solid #d8ebe8;border-radius:22px;box-shadow:0 12px 30px rgba(36,108,115,.06);overflow:hidden}.visit-card-head{padding:18px 22px;border-bottom:1px solid #e7f0ef;background:#fbfefe}.visit-card-head h2{margin:0;color:#214e52;font-size:20px}.visit-card-head p{margin:5px 0 0;color:#7b918d;font-size:12px}.visit-body{padding:20px 22px}.field{display:grid;gap:7px}.field label{font-size:13px;font-weight:800;color:#294c4f}.field input,.field select,.field textarea{width:100%;box-sizing:border-box;border:1px solid #d3e7e4;border-radius:12px;background:#fff;color:#27484a;font:inherit;padding:10px 12px;outline:none}.field input,.field select{min-height:44px}.field textarea{min-height:90px;resize:vertical}.field input[readonly],.field textarea[readonly]{background:#f7fbfb}.field input:focus,.field select:focus,.field textarea:focus{border-color:#61c2c6;box-shadow:0 0 0 3px rgba(97,194,198,.12)}.section-title{margin:22px 0 12px;padding:11px 13px;border-radius:12px;background:#eef9f7;border-left:4px solid #59bfc0;color:#285c60;font-size:14px;font-weight:900}.grid-2{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:13px}.grid-3{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:13px}.grid-4{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:13px}.visit-actions{display:flex;justify-content:flex-end;margin-top:20px}.btn-save{border:0;border-radius:12px;padding:12px 20px;background:linear-gradient(135deg,#67c8c3,#4fb4b9);color:#fff;font:inherit;font-weight:900;cursor:pointer;box-shadow:0 8px 18px rgba(88,191,192,.18)}.alert{padding:12px 14px;border-radius:12px}.ok{background:#eaf8f1;color:#2d684f;border:1px solid #cfe8da}.err{background:#fff1f1;color:#984b4b;border:1px solid #f0d1d1}.required{color:#b85656}.visit-note{padding:11px 12px;border-radius:12px;background:#f5fbfb;border:1px dashed #cfe5e2;color:#67827e;font-size:12px;line-height:1.6;margin-bottom:14px}.guide-list{display:grid;gap:10px}.guide-item{padding:13px;border:1px solid #dcebe8;border-radius:13px;background:#fbfefd}.guide-item strong{display:block;color:#2a5659;font-size:13px;margin-bottom:4px}.guide-item span{font-size:12px;color:#778e89;line-height:1.55}.history-list{display:grid;gap:10px}.history-item{padding:13px;border:1px solid #dcebe8;border-radius:13px;background:#fff}.history-item-head{display:flex;justify-content:space-between;gap:10px}.history-item strong{color:#285559}.history-meta{margin-top:5px;font-size:12px;color:#758b86;line-height:1.5}.refer-badge{display:inline-flex;padding:4px 8px;border-radius:999px;background:#fff4db;color:#8b6a21;font-size:11px;font-weight:800}.empty{padding:22px;text-align:center;color:#81928f}.history-scroll{max-height:520px;overflow:auto}.patient-readonly{padding:14px;border:1px solid #dcebe8;border-radius:14px;background:#fbfefd;margin-bottom:14px}.patient-readonly-grid{display:grid;grid-template-columns:1.2fr .55fr .65fr;gap:13px}.mutedline{font-size:12px;color:#7a908c;margin-top:4px}.visit-photo-upload{display:grid;grid-template-columns:140px minmax(0,1fr);gap:16px;align-items:center;padding:16px;border:1px dashed #cfe5e2;border-radius:16px;background:#fbfefe}.visit-photo-preview{width:120px;height:120px;border-radius:16px;border:1px solid #d6e8e5;background:linear-gradient(135deg,#eef9fb,#f2faf8);display:flex;align-items:center;justify-content:center;overflow:hidden;color:#718985;font-size:12px;font-weight:700;text-align:center}.visit-photo-preview img{width:100%;height:100%;object-fit:cover;display:block}.visit-photo-field input[type=file]{height:auto;min-height:46px;padding:10px;background:#fff}.visit-photo-field small{color:#718985;font-size:12px;line-height:1.5}@media(max-width:1100px){.grid-4{grid-template-columns:repeat(2,minmax(0,1fr))}}@media(max-width:760px){.grid-2,.grid-3,.grid-4,.patient-readonly-grid,.visit-photo-upload{grid-template-columns:1fr}.visit-head{flex-direction:column}.visit-body{padding:16px}.visit-actions .btn-save{width:100%}}


/* Visit entry menu — matched to the ADL entry screen */
.visit-entry-wrap{max-width:860px;margin:0 auto;padding:18px 0 34px}
.visit-entry-card{border:1px solid #d8ebe8;border-radius:26px;background:linear-gradient(180deg,#ffffff 0%,#f8fcfb 100%);box-shadow:0 14px 34px rgba(36,108,115,.07);padding:24px}
.visit-entry-head{text-align:center;margin-bottom:20px}.visit-entry-head h1{margin:0;color:#1d4f53;font-size:28px;line-height:1.2}
.visit-patient-select{max-width:640px;margin:0 auto 22px;padding:18px;border:1px solid #d9ebe8;border-radius:20px;background:#f8fcfc}
.visit-patient-select label{display:block;margin-bottom:9px;color:#254f53;font-size:14px;font-weight:900}
.visit-search-box{position:relative}.visit-search-input{width:100%;min-height:52px;padding:0 52px 0 14px;border:1px solid #cfe3e0;border-radius:14px;background:#fff;color:#214e50;font:inherit;font-weight:700;outline:none;box-sizing:border-box}
.visit-search-input:focus{border-color:#59bfc0;box-shadow:0 0 0 3px rgba(89,191,192,.12)}
.visit-search-toggle{position:absolute;top:50%;right:10px;transform:translateY(-50%);width:34px;height:34px;border:none;border-radius:10px;background:#f1f9f8;color:#2b686a;font-size:16px;cursor:pointer}
.visit-search-clear{position:absolute;top:50%;right:50px;transform:translateY(-50%);width:30px;height:30px;border:none;border-radius:999px;background:transparent;color:#7b918d;font-size:18px;cursor:pointer;display:none}.visit-search-clear.is-visible{display:inline-flex;align-items:center;justify-content:center}
.visit-search-options{position:absolute;left:0;right:0;top:calc(100% + 8px);padding:8px;border:1px solid #d9ebe8;border-radius:16px;background:#fff;box-shadow:0 18px 34px rgba(36,108,115,.10);display:none;max-height:260px;overflow:auto;z-index:50}.visit-search-options.is-open{display:block}
.visit-search-option{display:block;width:100%;padding:12px 13px;border:none;border-radius:12px;background:transparent;text-align:left;color:#214e50;font:inherit;font-weight:700;cursor:pointer}.visit-search-option:hover,.visit-search-option.is-active{background:#eef8f7}
.visit-search-empty{padding:12px 13px;border-radius:12px;color:#7a908d;font-size:12px;background:#fbfefe;display:none}.visit-search-empty.is-visible{display:block}.visit-native-select{display:none}.visit-select-note{margin-top:9px;color:#7a908d;font-size:12px}
.visit-entry-grid{display:grid;grid-template-columns:repeat(2,minmax(190px,220px));justify-content:center;gap:14px;max-width:460px;margin:0 auto}.visit-entry-link{display:flex;align-items:center;justify-content:center;min-height:74px;padding:12px 14px;border-radius:16px;border:1px solid #d9ebe8;background:#fff;text-decoration:none;transition:.18s ease;box-shadow:0 6px 16px rgba(36,108,115,.05)}
.visit-entry-link:hover{transform:translateY(-2px);box-shadow:0 12px 26px rgba(36,108,115,.10);border-color:#bfe2dd}.visit-entry-link.primary{background:linear-gradient(135deg,#63c4c6 0%,#56b7ba 100%);border-color:#56b7ba}.visit-entry-link.history{background:linear-gradient(135deg,#f4f9ff 0%,#fbfdff 100%)}
.visit-entry-label{font-size:17px;font-weight:900;color:#fff;text-align:center;line-height:1.3}.visit-entry-link.history .visit-entry-label{color:#21585c}.visit-entry-link.is-disabled{opacity:.46;pointer-events:none;filter:grayscale(.15)}
@media(max-width:760px){.visit-entry-wrap{padding:14px 0 28px}.visit-entry-card{padding:18px;border-radius:22px}.visit-entry-grid{grid-template-columns:1fr;max-width:100%}.visit-entry-link{min-height:68px;padding:12px 16px}.visit-entry-label{font-size:17px}.visit-entry-head h1{font-size:25px}.visit-patient-select{padding:16px}}
.visit-history-page{max-width:1320px;margin:0 auto;padding:18px 0 44px}
.visit-history-top{display:flex;align-items:center;justify-content:space-between;gap:14px;margin-bottom:18px}
.visit-history-top h1{margin:0;color:#1d4f53;font-size:30px;font-weight:900}
.visit-back-link{display:inline-flex;align-items:center;justify-content:center;padding:11px 18px;border:1px solid #62c4c6;border-radius:14px;background:linear-gradient(135deg,#6ecfd0 0%,#58bcc0 100%);color:#fff;text-decoration:none;font-weight:800;box-shadow:0 8px 20px rgba(89,191,192,.16)}.visit-back-link:hover{background:linear-gradient(135deg,#67c8ca 0%,#4fb4b9 100%);border-color:#58bcc0;color:#fff}
.visit-history-shell{display:grid;gap:18px}
.visit-history-hero{padding:24px 26px;border:1px solid #d8ebe8;border-radius:28px;background:linear-gradient(135deg,#ffffff 0%,#f7fcfb 100%);box-shadow:0 18px 40px rgba(36,108,115,.08)}
.visit-history-patient{display:flex;align-items:flex-start;justify-content:space-between;gap:18px;flex-wrap:wrap}
.visit-history-name{margin:0;color:#234f54;font-size:24px;font-weight:900}
.visit-history-sub{margin-top:6px;color:#708986;font-size:13px;line-height:1.65}
.visit-history-meta-list{display:flex;gap:10px;flex-wrap:wrap;margin-top:12px}
.visit-history-meta-tag{display:inline-flex;align-items:center;gap:6px;padding:8px 12px;border:1px solid #dbeae8;border-radius:999px;background:#fbfefe;color:#496668;font-size:13px;line-height:1.4}
.visit-history-meta-tag span{font-weight:800;color:#6e8784}
.visit-history-stats{display:flex;gap:12px;flex-wrap:wrap}
.visit-history-stat{min-width:150px;padding:14px 16px;border:1px solid #dcebe8;border-radius:18px;background:#fbfefe}
.visit-history-stat span{display:block;font-size:12px;font-weight:800;color:#708885;margin-bottom:4px}
.visit-history-stat strong{display:block;font-size:22px;font-weight:900;color:#1f5358}
.visit-history-card{border:1px solid #d9e5e4;border-radius:16px;background:#fff;box-shadow:0 6px 18px rgba(36,108,115,.04);padding:18px}
.visit-history-section-title{max-width:none;margin:0 0 14px;color:#244f53;font-size:18px;font-weight:900}
.visit-history-list{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:12px;max-width:none;margin:0}
.visit-history-item{display:grid;grid-template-columns:1fr;align-content:start;gap:10px;padding:12px 14px;border:1px solid #dbe6e5;border-radius:14px;background:#ffffff;min-width:0}
.visit-history-datebox{padding:9px 10px;border-radius:11px;background:#2f6f73;color:#fff;text-align:left;box-shadow:none}
.visit-history-datebox strong{display:block;font-size:12px;font-weight:900;line-height:1.3}
.visit-history-datebox span{display:block;margin-top:4px;font-size:10px;opacity:.95}
.visit-history-item-head{display:flex;align-items:flex-start;justify-content:space-between;gap:10px;padding-bottom:8px;border-bottom:1px solid #e6efee}
.visit-history-item-title{margin:0;color:#204f54;font-size:15px;font-weight:900;line-height:1.35}
.visit-history-badges{display:flex;gap:8px;flex-wrap:wrap;margin-top:7px}
.visit-history-badge{display:inline-flex;align-items:center;padding:3px 9px;border-radius:999px;background:#f4f9f9;color:#4f6769;font-size:11px;font-weight:700;border:1px solid #dbe8e6}
.visit-history-compact{margin-top:10px;padding:4px 0 0;background:#ffffff}
.visit-history-compact-row{display:grid;grid-template-columns:1fr;gap:3px;align-items:start;padding:7px 0;font-size:12px;line-height:1.5;color:#435d5f;border-top:1px dashed #e4eeec}
.visit-history-compact-row:first-child{border-top:none;padding-top:2px}
.visit-history-compact-label{font-weight:800;color:#244f53}
.visit-history-compact-value{color:#4c6466;word-break:break-word}
.visit-history-empty{padding:28px;text-align:center;border:1px dashed #d7e8e5;border-radius:18px;background:#fbfefe;color:#7a908d}
.visit-history-photo{margin-top:12px}.visit-history-photo img{width:96px;height:96px;object-fit:cover;border-radius:12px;border:1px solid #d7eae8;box-shadow:0 6px 14px rgba(36,108,115,.05)}
.visit-history-pagination{display:flex;align-items:center;justify-content:center;gap:6px;margin-top:16px;flex-wrap:wrap}
.visit-history-pagebtn{display:inline-flex;align-items:center;justify-content:center;min-width:34px;height:34px;padding:0 9px;border:1px solid #d4e7e4;border-radius:10px;background:#fff;color:#285c60;text-decoration:none;font-size:13px;font-weight:800;transition:.15s ease}
.visit-history-pagebtn:hover{border-color:#8bcfcd;background:#f2fbfa}.visit-history-pagebtn.is-active{background:#59bfc0;border-color:#59bfc0;color:#fff}.visit-history-pagebtn.is-disabled{opacity:.38;pointer-events:none}.visit-history-ellipsis{display:inline-flex;align-items:center;justify-content:center;min-width:24px;height:34px;color:#78908c;font-weight:800}
@media(max-width:1380px){.visit-history-list{grid-template-columns:repeat(3,minmax(0,1fr))}}@media(max-width:980px){.visit-history-list{grid-template-columns:repeat(2,minmax(0,1fr))}}@media(max-width:700px){.visit-history-list{grid-template-columns:1fr}.visit-history-compact-row{padding:8px 0}}

@media(max-width:760px){.visit-entry-wrap{padding:18px 0 32px}.visit-entry-card{padding:22px 18px 26px;border-radius:26px}.visit-patient-select{padding:18px 16px;border-radius:20px}.visit-entry-grid{grid-template-columns:1fr;max-width:100%}.visit-entry-link{min-height:88px;padding:14px 16px}.visit-entry-label{font-size:18px}.visit-entry-head h1{font-size:28px}.visit-history-top{align-items:flex-start;flex-direction:column}.visit-history-hero{padding:18px}.visit-history-name{font-size:21px}.visit-history-stat{min-width:0;flex:1 1 140px}.visit-back-link{width:100%;justify-content:center}.visit-history-meta-list{gap:8px}.visit-history-meta-tag{width:100%;border-radius:14px}}

/* Success screen — cleaner and more polished */
body.visit-submit-success-body{background:radial-gradient(circle at top,#f8fcfc 0%,#eef8f7 56%,#edf6f5 100%)!important}
.visit-submit-success-main{margin:0!important;padding:56px 20px!important;min-height:100vh;display:flex;justify-content:center;align-items:flex-start}
.visit-submit-success-wrap{width:100%;max-width:760px;margin:0 auto}
.visit-submit-success-card{position:relative;background:linear-gradient(180deg,#ffffff 0%,#fbfefe 100%);border:1px solid #d6ecea;border-radius:28px;overflow:hidden;box-shadow:0 24px 52px rgba(42,112,117,.12)}
.visit-submit-success-accent{height:8px;background:linear-gradient(90deg,#76cfca 0%,#54b7bc 100%)}
.visit-submit-success-content{padding:34px 34px 30px}
.visit-submit-success-top{display:flex;align-items:center;gap:18px;margin-bottom:20px}.visit-submit-success-icon{flex:0 0 66px;width:66px;height:66px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#67c8c3 0%,#4fb4b9 100%);color:#fff;font-size:32px;font-weight:900;box-shadow:0 12px 26px rgba(79,180,185,.24)}
.visit-submit-success-title h1{margin:0 0 6px;font-size:31px;line-height:1.25;color:#21484d!important;font-weight:900}.visit-submit-success-title p{margin:0;color:#6f8885;line-height:1.7;font-size:15px}
.visit-submit-success-summary{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px;margin:24px 0 20px}.visit-success-item{padding:16px 18px;border:1px solid #dcebe8;border-radius:18px;background:linear-gradient(180deg,#ffffff 0%,#f6fbfb 100%)}
.visit-success-label{display:block;margin-bottom:6px;font-size:12px;font-weight:800;color:#6f8683}.visit-success-value{display:block;color:#1f5257;font-size:18px;font-weight:900;line-height:1.45}
.visit-submit-success-photo{margin-top:4px;padding:18px;border:1px dashed #cfe3e0;border-radius:20px;background:#f9fcfc}.visit-submit-success-photo-title{font-size:13px;font-weight:800;color:#315d61;margin-bottom:10px}.visit-submit-success-photo img{display:block;max-width:100%;width:220px;height:220px;object-fit:cover;border-radius:18px;border:1px solid #d6ecea;box-shadow:0 8px 22px rgba(36,108,115,.08)}
.visit-submit-success-actions{display:flex;align-items:center;justify-content:center;gap:12px;margin-top:24px;flex-wrap:wrap}
.visit-submit-success-btn,.visit-submit-success-link{display:inline-flex;align-items:center;justify-content:center;min-width:190px;padding:12px 18px;border-radius:14px;text-decoration:none;font-weight:800}
.visit-submit-success-btn{background:linear-gradient(135deg,#67c8c3 0%,#4fb4b9 100%);color:#fff!important;box-shadow:0 10px 22px rgba(79,180,185,.20)}
.visit-submit-success-link{background:#fff;color:#246c73!important;border:1px solid #cfe8e6}
.visit-submit-success-btn:hover,.visit-submit-success-link:hover{transform:translateY(-1px)}
@media(max-width:720px){.visit-submit-success-main{padding:28px 14px!important}.visit-submit-success-content{padding:24px 18px 22px}.visit-submit-success-top{align-items:flex-start}.visit-submit-success-title h1{font-size:24px}.visit-submit-success-summary{grid-template-columns:1fr}.visit-submit-success-actions{flex-direction:column;align-items:stretch}.visit-submit-success-btn,.visit-submit-success-link{width:100%;min-width:0}.visit-submit-success-photo img{width:100%;height:auto;aspect-ratio:1/1}}


/* Cleaner compact visit form */
.alert.info{background:#eef8fb;color:#2f6571;border:1px solid #cfe4eb}
.compact-form-grid{display:grid;gap:16px;margin-top:16px}
.form-panel{padding:18px;border:1px solid #dfeceb;border-radius:18px;background:linear-gradient(180deg,#ffffff 0%,#fbfefe 100%);box-shadow:0 8px 20px rgba(36,108,115,.04)}
.form-panel .section-title{margin:0 0 14px}
.patient-selector-shell{padding:16px;border:1px solid #dcebe8;border-radius:18px;background:#fcfefe}
.patient-summary{display:grid;grid-template-columns:1.3fr repeat(3,minmax(0,1fr));gap:12px;margin-top:16px}
.summary-item{padding:14px 16px;border:1px solid #dcebe8;border-radius:16px;background:linear-gradient(180deg,#ffffff 0%,#f8fcfb 100%)}
.summary-label{display:block;margin-bottom:6px;font-size:12px;font-weight:800;color:#6d8784;text-transform:none}
.summary-item strong{display:block;color:#214e52;font-size:16px;line-height:1.45}
.summary-item small{display:block;margin-top:4px;color:#78908b;font-size:12px}
.summary-main strong{font-size:18px}
.summary-note{margin-top:12px;padding:12px 14px;border:1px dashed #cfe5e2;border-radius:14px;background:#f6fbfb;color:#68807d;font-size:12px;line-height:1.65}
.form-panel .field input,.form-panel .field select,.form-panel .field textarea,.patient-selector-shell .field select{background:#fbfefe}
.form-panel .field textarea{min-height:108px}
.compact-photo-upload{padding:18px;background:#fbfefe}
.compact-photo-upload .visit-photo-preview{width:110px;height:110px}
.compact-actions{margin-top:18px}
.compact-actions .btn-save{min-width:220px}
.visit-map-panel{padding:18px;border:1px solid #dfeceb;border-radius:18px;background:linear-gradient(180deg,#ffffff 0%,#fbfefe 100%);box-shadow:0 8px 20px rgba(36,108,115,.04)}
.visit-map-head{display:flex;align-items:flex-start;justify-content:space-between;gap:14px;flex-wrap:wrap;margin-bottom:14px}
.visit-map-head strong{display:block;color:#214e52;font-size:15px;font-weight:900}
.visit-map-head span{display:block;margin-top:4px;color:#77908b;font-size:12px;line-height:1.6}
.visit-map-actions{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
.visit-map-btn{border:1px solid #cfe5e2;border-radius:14px;background:#fff;color:#2d6669;padding:11px 18px;font:inherit;font-size:13px;font-weight:800;cursor:pointer;box-shadow:0 8px 18px rgba(36,108,115,.05)}
.visit-map-btn.primary{background:linear-gradient(135deg,#67c8c3,#4fb4b9);border-color:#59bfc0;color:#fff}
#visitPatientLocationMap{width:100%;height:300px;border:1px solid #d7e8e5;border-radius:16px;overflow:hidden;background:#eef7f6}
.visit-map-coordinates{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;margin-top:16px}
.visit-map-coordinates .field input{background:#fff}
@media(max-width:760px){.visit-map-coordinates{grid-template-columns:1fr}#visitPatientLocationMap{height:240px}}
@media(max-width:980px){.patient-summary{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:760px){.patient-summary{grid-template-columns:1fr}.form-panel{padding:16px}.compact-actions .btn-save{width:100%}}


/* History palette aligned with Thonglang system */
.visit-history-page{--tl-primary:#58bfc0;--tl-primary-dark:#2f7377;--tl-primary-soft:#eaf7f6;--tl-primary-pale:#f6fbfb;--tl-border:#d5e8e6;--tl-text:#234f54;--tl-muted:#6f8885}
.visit-history-card,.visit-history-hero{border-color:var(--tl-border);background:#fff;box-shadow:0 10px 28px rgba(47,115,119,.06)}
.visit-history-section-title,.visit-history-name,.visit-history-item-title{color:var(--tl-text)}
.visit-history-datebox{background:linear-gradient(180deg,var(--tl-primary) 0%,#4eb1b5 100%);color:#fff}
.visit-history-badge{background:var(--tl-primary-soft);border-color:#cfe5e2;color:#2d6669}
.visit-history-compact-row{border-top-color:#dfecea}
.visit-history-compact-label{color:#2b6064}
.visit-history-compact-value{color:#4f6769}
.visit-history-item{border-color:var(--tl-border);background:linear-gradient(180deg,#ffffff 0%,var(--tl-primary-pale) 100%)}
.visit-history-compact{background:transparent}
.visit-history-pagebtn{border-color:#cfe5e2;color:#2f6f73;background:#fff}
.visit-history-pagebtn:hover{background:var(--tl-primary-soft);border-color:#a9d8d5}
.visit-history-pagebtn.is-active{background:var(--tl-primary);border-color:var(--tl-primary);color:#fff}
.visit-back-link{border-color:#62c4c6;color:#ffffff;background:linear-gradient(135deg,#6ecfd0 0%,#58bcc0 100%);box-shadow:0 8px 20px rgba(89,191,192,.16)}
.visit-back-link:hover{background:linear-gradient(135deg,#67c8ca 0%,#4fb4b9 100%);border-color:#58bcc0;color:#fff}


/* Caregiver visit history table layout */
.visit-history-page{max-width:none;margin:0;padding:0 0 30px}
.visit-history-top{display:flex;align-items:center;justify-content:space-between;gap:14px;margin-bottom:18px}
.visit-history-top h1{margin:0;color:#1d4f53;font-size:30px;font-weight:900}
.visit-history-table-card{background:transparent;border:none;border-radius:0;box-shadow:none;padding:0}
.visit-history-head{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;flex-wrap:wrap;padding-bottom:16px}.visit-history-head h2{margin:0;color:#225359;font-size:20px}.visit-history-head p{margin:5px 0 0;color:#778f8b;font-size:12px}
.visit-history-count-chip{display:inline-flex;align-items:center;justify-content:center;padding:10px 16px;border-radius:999px;background:#f6fbfa;border:1px solid #d6e7e4;color:#2c6668;font-size:13px;font-weight:900;white-space:nowrap}
.visit-history-patient-strip{display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap;margin-bottom:16px;padding:18px;border:1px solid #dcebe8;border-radius:20px;background:linear-gradient(135deg,#f8fcfc 0%,#fefefe 100%)}
.visit-history-patient-main strong{display:block;color:#1f5358;font-size:26px;font-weight:900;line-height:1.25}.visit-history-patient-main span{display:block;margin-top:6px;color:#748c88;font-size:13px;line-height:1.6}
.visit-history-patient-tags{display:flex;align-items:center;gap:10px;flex-wrap:wrap}.visit-history-pill{display:inline-flex;align-items:center;gap:6px;padding:8px 12px;border:1px solid #dbeae8;border-radius:999px;background:#fff;color:#4b6768;font-size:12px}.visit-history-pill b{color:#2d5b5f}
.visit-history-table-wrap{overflow:auto;border:1px solid #e2efed;border-radius:22px}
.visit-history-table{width:100%;min-width:900px;border-collapse:separate;border-spacing:0}.visit-history-table th,.visit-history-table td{padding:16px 14px;text-align:left;border-bottom:1px solid #e8f1ef;vertical-align:top}.visit-history-table th{background:#edf7f7;color:#2b6769;font-size:13px;font-weight:900}.visit-history-table th:first-child{border-top-left-radius:20px}.visit-history-table th:last-child{border-top-right-radius:20px}.visit-history-table tbody tr:last-child td{border-bottom:none}.visit-history-table tbody tr:nth-child(even){background:#fbfefe}
.visit-history-date strong,.visit-history-type strong,.visit-history-next strong{display:block;color:#224f54;font-size:14px;font-weight:900}.visit-history-date .meta,.visit-history-type .meta,.visit-history-next .meta{display:block;margin-top:5px;color:#7c918d;font-size:12px;line-height:1.5}
.visit-history-condition-badge{display:inline-flex;align-items:center;padding:7px 12px;border-radius:999px;background:#eef8f7;border:1px solid #d6e8e5;color:#2a6669;font-size:12px;font-weight:800}
.visit-history-detail-btn{display:inline-flex;align-items:center;justify-content:center;min-height:40px;padding:0 15px;border-radius:12px;border:1px solid #cfe2df;background:#f5fbfb;color:#2a6468;font-size:13px;font-weight:900;cursor:pointer;text-decoration:none}.visit-history-detail-btn:hover{background:#ebf7f6}
.visit-history-empty-row{text-align:center;color:#80938f;padding:22px !important}
.visit-history-pagination{display:flex;align-items:center;justify-content:center;gap:7px;flex-wrap:wrap;margin-top:18px}.visit-history-pagebtn{display:inline-flex;align-items:center;justify-content:center;min-width:38px;height:38px;padding:0 10px;border:1px solid #d5e7e4;border-radius:11px;background:#fff;color:#2f6668;text-decoration:none;font-size:13px;font-weight:900;box-shadow:0 5px 12px rgba(46,112,116,.04)}.visit-history-pagebtn:hover{background:#eef8f6}.visit-history-pagebtn.is-active{background:linear-gradient(135deg,#5fc4c3,#49aaae);border-color:#53b5b6;color:#fff}.visit-history-pagebtn.is-disabled{opacity:.38;pointer-events:none}.visit-history-ellipsis{display:inline-flex;align-items:center;justify-content:center;min-width:30px;color:#78908c;font-weight:900}
.visit-history-detail{position:fixed;inset:0;padding:22px;background:rgba(17,35,37,.34);z-index:999;display:none;align-items:center;justify-content:center}.visit-history-detail.open{display:flex}.visit-history-detail-card{width:min(1020px,100%);max-height:90vh;overflow:auto;background:#fff;border-radius:26px;border:1px solid #d8ebe8;box-shadow:0 26px 70px rgba(30,73,76,.20)}.visit-history-detail-head{display:flex;justify-content:space-between;gap:15px;align-items:flex-start;padding:22px 24px;border-bottom:1px solid #e6f0ee;background:linear-gradient(135deg,#f7fcfb,#eef8fa);position:sticky;top:0;z-index:2}.visit-history-detail-head h2{margin:0;color:#24575b}.visit-history-detail-close{width:38px;height:38px;border-radius:50%;border:1px solid #d7e7e4;background:#fff;color:#486d6c;font-size:22px;cursor:pointer;box-shadow:0 6px 14px rgba(46,112,116,.06)}.visit-history-detail-body{padding:22px 24px}.visit-history-detail-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:11px}.visit-history-detail-box{padding:12px 13px;border:1px solid #e0ecea;border-radius:13px;background:#fbfefd}.visit-history-detail-box span{display:block;font-size:11px;color:#829592;font-weight:800}.visit-history-detail-box strong{display:block;margin-top:5px;color:#2b5355;font-size:13px;white-space:pre-wrap;line-height:1.5}.visit-history-detail-box.full{grid-column:1/-1}.visit-history-detail-label{margin:20px 0 10px;padding:9px 11px;border-radius:11px;background:#eef9f7;border-left:4px solid #5fc3c1;font-size:13px;font-weight:900;color:#346365}.visit-history-alert{padding:13px 14px;border-radius:13px;background:#fff2f2;border:1px solid #efd1d1;color:#995858;font-weight:900;line-height:1.5}
@media(max-width:760px){.visit-history-top{align-items:flex-start;flex-direction:column}.visit-back-link{width:100%;justify-content:center}.visit-history-table-card{padding:0}.visit-history-patient-main strong{font-size:21px}.visit-history-detail-grid{grid-template-columns:1fr}}

.visit-month-toolbar{display:flex;align-items:center;justify-content:flex-end;gap:12px;flex-wrap:wrap;margin:0 0 18px;padding:0;border:none;border-radius:0;background:transparent}.visit-month-nav{display:flex;align-items:center;gap:10px;flex-wrap:wrap}.visit-month-btn{display:inline-flex;align-items:center;justify-content:center;min-width:42px;min-height:42px;padding:0 14px;border:1px solid #cfe4e1;border-radius:13px;background:#fff;color:#2e6467;text-decoration:none;font-size:14px;font-weight:900;box-shadow:0 6px 14px rgba(46,112,116,.04)}.visit-month-current{font-size:16px;font-weight:900;color:#214f54}.visit-month-picker{margin:0}.visit-month-picker select{appearance:none;-webkit-appearance:none;-moz-appearance:none;min-width:240px;height:54px;padding:0 52px 0 18px;border:1px solid #cfe4e1;border-radius:16px;background-color:#fff;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='18' height='18' viewBox='0 0 24 24' fill='none' stroke='%232b3b3b' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Crect x='3' y='5' width='18' height='16' rx='2'/%3E%3Cline x1='16' y1='3' x2='16' y2='7'/%3E%3Cline x1='8' y1='3' x2='8' y2='7'/%3E%3Cline x1='3' y1='11' x2='21' y2='11'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 16px center;background-size:18px 18px;color:#244f52;font:inherit;font-size:16px;font-weight:500;outline:none;cursor:pointer;box-shadow:0 4px 12px rgba(46,112,116,.03)}.visit-month-picker select:focus{border-color:#83cbc8;box-shadow:0 0 0 3px rgba(89,191,192,.10)}.visit-month-form{display:flex;align-items:center;gap:8px}.visit-month-form input{height:40px;border:1px solid #cfe4e1;border-radius:12px;background:#fff;padding:0 12px;font:inherit;color:#2c5558}.visit-month-form button{height:40px;padding:0 14px;border:0;border-radius:12px;background:#59bfc0;color:#fff;font:inherit;font-weight:900;cursor:pointer}


/* Thai month picker */
.thai-month-picker{position:relative;margin:0;z-index:60}
.thai-month-picker-toggle{display:flex;align-items:center;justify-content:space-between;gap:14px;min-width:250px;height:52px;padding:0 15px 0 17px;border:1px solid #cfe4e1;border-radius:18px;background:#fff;color:#244f52;font:inherit;font-size:16px;font-weight:700;cursor:pointer;box-shadow:0 6px 14px rgba(46,112,116,.04)}
.thai-month-picker-toggle:focus,.thai-month-picker.open .thai-month-picker-toggle{border-color:#75c7c5;box-shadow:0 0 0 3px rgba(89,191,192,.12);outline:none}
.thai-month-picker-icon{width:19px;height:19px;display:inline-flex;align-items:center;justify-content:center;flex:0 0 auto}
.thai-month-picker-icon svg{width:18px;height:18px;display:block}
.thai-month-picker-popover{position:absolute;right:0;top:calc(100% + 8px);width:320px;padding:14px;background:#fff;border:1px solid #d7e5e3;border-radius:16px;box-shadow:0 18px 44px rgba(29,68,71,.18);display:none;z-index:999}
.thai-month-picker.open .thai-month-picker-popover{display:block}
.thai-month-picker-yearbar{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:2px 2px 12px;border-bottom:1px solid #e6efed;margin-bottom:12px}
.thai-month-picker-year{font-size:17px;font-weight:900;color:#244f52}
.thai-month-year-controls{display:flex;gap:6px}
.thai-month-year-btn{width:32px;height:32px;border:1px solid #d8e8e5;border-radius:9px;background:#f9fcfb;color:#5d7777;font:inherit;font-weight:900;cursor:pointer}
.thai-month-year-btn:disabled{opacity:.32;cursor:not-allowed}.thai-month-year-text{width:auto;min-width:78px;padding:0 10px;font-size:11px}
.thai-month-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:7px}
.thai-month-option{height:42px;border:1px solid transparent;border-radius:10px;background:transparent;color:#294f53;font:inherit;font-size:14px;font-weight:700;cursor:pointer}
.thai-month-option:hover{background:#eef8f7;border-color:#d8ebe8}
.thai-month-option.selected{background:#3f4a4d;color:#fff;border-color:#3f4a4d}
.thai-month-option:disabled{color:#b7c0bf;background:transparent;cursor:not-allowed}
.thai-month-picker-footer{display:flex;justify-content:flex-end;margin-top:12px;padding-top:10px;border-top:1px solid #e8f0ef}
.thai-month-today{border:0;background:transparent;color:#2f7e82;font:inherit;font-size:13px;font-weight:900;cursor:pointer;padding:5px 4px}
@media(max-width:620px){.thai-month-picker{width:100%}.thai-month-picker-toggle{width:100%;min-width:0}.thai-month-picker-popover{right:auto;left:0;width:min(320px,calc(100vw - 44px))}}

/* Month history card - reference layout */
.visit-month-toolbar{justify-content:flex-start!important;margin:0 0 22px!important}
.visit-history-month-card{width:min(470px,100%);overflow:visible;border-radius:28px;background:linear-gradient(145deg,#58b9bb 0%,#48a9ab 100%);box-shadow:0 14px 30px rgba(46,112,116,.10)}
.visit-history-month-card-top{display:flex;justify-content:flex-end;align-items:center;min-height:94px;padding:22px 28px 14px}
.visit-history-month-count{display:inline-flex;align-items:center;justify-content:center;min-height:46px;padding:0 20px;border:1px solid rgba(255,255,255,.42);border-radius:999px;background:rgba(255,255,255,.08);color:#fff;font-size:15px;font-weight:900;white-space:nowrap}
.visit-history-month-picker-wrap{padding:24px 24px 22px;background:#fff;border-radius:0 0 28px 28px}
.visit-history-month-picker-wrap .thai-month-picker{width:100%}
.visit-history-month-picker-wrap .thai-month-picker-toggle{width:100%;min-width:0;height:66px;padding:0 20px;border-radius:22px;font-size:17px;font-weight:900;box-shadow:none}
.visit-history-month-picker-wrap .thai-month-picker-popover{left:0;right:auto;width:min(340px,calc(100vw - 56px))}
@media(max-width:620px){.visit-history-month-card{width:100%;border-radius:24px}.visit-history-month-card-top{min-height:82px;padding:18px 20px 12px}.visit-history-month-count{font-size:14px}.visit-history-month-picker-wrap{padding:18px;border-radius:0 0 24px 24px}}

</style>
</head>
<body class="role-page<?= $showSuccessScreen ? ' visit-submit-success-body' : '' ?>">
<?php if(!$showSuccessScreen) renderSidebar(); ?>
<div class="main<?= $showSuccessScreen ? ' visit-submit-success-main' : '' ?>">
<?php if(!$showSuccessScreen) renderUserTopbar(); ?>
<?php if($showSuccessScreen): ?>
<?php
    $successPhotoUrl = thonglangUploadedImageUrl($successVisit['visit_photo'] ?? '');
    $successVisitDate = thDate($successVisit['visit_date'] ?? '');
    $successNextDate = thDate($successVisit['next_visit_date'] ?? '');
    $successVisitTime = !empty($successVisit['visit_time']) ? substr((string)$successVisit['visit_time'],0,5).' น.' : '-';
?>
<div class="visit-submit-success-wrap">
    <div class="visit-submit-success-card" role="status" aria-live="polite">
        <div class="visit-submit-success-accent"></div>
        <div class="visit-submit-success-content">
            <div class="visit-submit-success-top">
                <div class="visit-submit-success-icon">✓</div>
                <div class="visit-submit-success-title">
                    <h1>บันทึกข้อมูลสำเร็จ</h1>
                    <p>ระบบได้บันทึกข้อมูลการเข้าเยี่ยมของ <strong><?=e($successVisit['Fullname'] ?? '-')?></strong> เรียบร้อยแล้ว</p>
                </div>
            </div>

            <div class="visit-submit-success-summary">
                <div class="visit-success-item">
                    <span class="visit-success-label">วันที่เข้าเยี่ยม</span>
                    <span class="visit-success-value"><?=e($successVisitDate)?></span>
                </div>
                <div class="visit-success-item">
                    <span class="visit-success-label">เวลา</span>
                    <span class="visit-success-value"><?=e($successVisitTime)?></span>
                </div>
                <div class="visit-success-item">
                    <span class="visit-success-label">ประเภทการเข้าเยี่ยม</span>
                    <span class="visit-success-value"><?=e($successVisit['visit_type'] ?? '-')?></span>
                </div>
                <div class="visit-success-item">
                    <span class="visit-success-label">นัดติดตามครั้งถัดไป</span>
                    <span class="visit-success-value"><?=e($successNextDate !== '-' ? $successNextDate : 'ยังไม่ได้นัดหมาย')?></span>
                </div>
                <?php if(!empty($successVisit['doctor_referral'])): ?>
                <div class="visit-success-item" style="grid-column:1/-1">
                    <span class="visit-success-label">การส่งต่อ</span>
                    <span class="visit-success-value"><?=e($successVisit['referral_type'] ?? 'มีการส่งต่อ')?></span>
                </div>
                <?php endif; ?>
            </div>

            <?php if($successPhotoUrl !== ''): ?>
            <div class="visit-submit-success-photo">
                <div class="visit-submit-success-photo-title">รูปภาพที่แนบ</div>
                <img src="<?=e($successPhotoUrl)?>" alt="รูปภาพการเข้าเยี่ยม">
            </div>
            <?php endif; ?>

            <div class="visit-submit-success-actions">
                <a class="visit-submit-success-btn" href="caregiver_visit.php">กลับหน้าเมนูการเข้าเยี่ยม</a>
                <a class="visit-submit-success-link" href="caregiver_patients.php">กลับหน้าผู้สูงอายุ</a>
            </div>
        </div>
    </div>
</div>
<?php else: ?>
<?php if(!$selected && $visitMode === ''): ?>
<div class="visit-entry-wrap">
    <?php if($message):?><div class="alert ok" style="margin-bottom:14px"><?=e($message)?></div><?php endif;?>
    <?php if($error):?><div class="alert err" style="margin-bottom:14px"><?=e($error)?></div><?php endif;?>
    <section class="visit-entry-card">
        <div class="visit-entry-head"><h1>การเข้าเยี่ยมผู้สูงอายุ</h1></div>
        <?php if(!$assignments): ?>
            <div class="empty">ยังไม่มีผู้สูงอายุที่อยู่ในความดูแล จึงยังไม่สามารถบันทึกการเข้าเยี่ยมได้</div>
        <?php else: ?>
        <div class="visit-patient-select">
            <label for="visitPatientSearch">เลือกผู้สูงอายุ</label>
            <div class="visit-search-box" id="visitPatientBox">
                <input type="text" id="visitPatientSearch" class="visit-search-input" placeholder="พิมพ์เพื่อค้นหาและเลือกผู้สูงอายุ..." autocomplete="off">
                <button type="button" class="visit-search-clear" id="visitPatientClear" aria-label="ล้างคำค้น">×</button>
                
                <div class="visit-search-options" id="visitPatientOptions">
                    <?php foreach($assignments as $a): $visitLabel=e($a['Fullname']).(!empty($a['villagename'])?' • '.e($a['villagename']):''); ?>
                    <button type="button" class="visit-search-option" data-value="<?=(int)$a['assignment_id']?>" data-label="<?=$visitLabel?>" data-search="<?=e(mb_strtolower(trim((string)$a['Fullname']).' '.trim((string)($a['villagename']??'')), 'UTF-8'))?>"><?=$visitLabel?></button>
                    <?php endforeach; ?>
                    <div class="visit-search-empty" id="visitPatientEmpty">ไม่พบรายชื่อผู้สูงอายุ</div>
                </div>
                <select id="visitPatientSelect" class="visit-native-select"><option value="">-- เลือกผู้สูงอายุ --</option><?php foreach($assignments as $a):?><option value="<?=(int)$a['assignment_id']?>"><?=e($a['Fullname'])?></option><?php endforeach;?></select>
            </div>
        </div>
        <div class="visit-entry-grid">
            <a id="visitRecordLink" class="visit-entry-link primary is-disabled" href="caregiver_visit.php"><div class="visit-entry-label">บันทึกการเข้าเยี่ยม</div></a>
            <a id="visitHistoryLink" class="visit-entry-link history is-disabled" href="caregiver_visit.php?mode=history"><div class="visit-entry-label">ประวัติการเข้าเยี่ยม</div></a>
        </div>
        <?php endif; ?>
    </section>
</div>
<?php elseif($visitMode === 'history' && $selected): ?>
<?php
    $allPatientHistory=array_values(array_filter($history,fn($r)=>(int)$r['patient_id']===(int)$selected['patient_id']));
    $currentHistoryMonth = date('Y-m');
    $historyMonth = trim((string)($_GET['month'] ?? $currentHistoryMonth));
    if (!preg_match('/^\d{4}-\d{2}$/', $historyMonth)) $historyMonth = $currentHistoryMonth;
    if ($historyMonth > $currentHistoryMonth) $historyMonth = $currentHistoryMonth;
    $historyMonthTs = strtotime($historyMonth.'-01');
    if (!$historyMonthTs) { $historyMonth = $currentHistoryMonth; $historyMonthTs = strtotime($historyMonth.'-01'); }
    $prevHistoryMonth = date('Y-m', strtotime('-1 month', $historyMonthTs));
    $nextHistoryMonth = date('Y-m', strtotime('+1 month', $historyMonthTs));
    $canGoNextHistoryMonth = $historyMonth < $currentHistoryMonth;
    $thaiMonthsFull=[1=>'มกราคม',2=>'กุมภาพันธ์',3=>'มีนาคม',4=>'เมษายน',5=>'พฤษภาคม',6=>'มิถุนายน',7=>'กรกฎาคม',8=>'สิงหาคม',9=>'กันยายน',10=>'ตุลาคม',11=>'พฤศจิกายน',12=>'ธันวาคม'];
    $historyMonthLabel=$thaiMonthsFull[(int)date('n',$historyMonthTs)].' '.((int)date('Y',$historyMonthTs)+543);
    $selectedHistory=array_values(array_filter($allPatientHistory,function($r) use ($historyMonth){ return substr((string)($r['visit_date']??''),0,7)===$historyMonth; }));
    $historyCount = count($selectedHistory);
    $latestVisit = $selectedHistory ? $selectedHistory[0] : null;
    $pagedHistory = $selectedHistory;
?>
<div class="visit-history-page">
    <div class="visit-history-top">
        <h1>ประวัติการเข้าเยี่ยม</h1>
        <a class="visit-back-link" href="caregiver_visit.php">ย้อนกลับ</a>
    </div>

    <section class="visit-history-table-card">
        <div class="visit-history-patient-strip">
            <div class="visit-history-patient-main">
                <strong><?=e($selected['Fullname'])?></strong>
            </div>
            <div class="visit-history-patient-tags">
                <?php if(!empty($selected['villagename'])): ?>
                    <div class="visit-history-pill"><b>หมู่บ้าน:</b> <?=e($selected['villagename'])?></div>
                <?php endif; ?>
                <?php if(!empty($selected['doctor_name']) || !empty($selected['doctor_username'])): ?>
                    <div class="visit-history-pill"><b>ผู้มอบหมาย:</b> <?=e($selected['doctor_name'] ?: $selected['doctor_username'])?></div>
                <?php endif; ?>
                <div class="visit-history-pill"><b>จำนวนครั้งที่เข้าเยี่ยม:</b> <?=$historyCount?></div>
                <div class="visit-history-pill"><b>ครั้งล่าสุด:</b> <?=e($latestVisit ? thDate($latestVisit['visit_date']) : '-')?></div>
            </div>
        </div>

        <div class="visit-history-table-wrap">
            <table class="visit-history-table">
                <thead>
                    <tr>
                        <th>วันที่เยี่ยม</th>
                        <th>ประเภทการเยี่ยม</th>
                        <th>สภาพทั่วไป</th>
                        <th>นัดครั้งถัดไป</th>
                        <th>รายละเอียด</th>
                    </tr>
                </thead>
                <tbody>
                <?php if(!$selectedHistory): ?>
                    <tr><td colspan="5" class="visit-history-empty-row">ยังไม่มีประวัติการเข้าเยี่ยมของผู้สูงอายุรายนี้ในเดือนที่เลือก</td></tr>
                <?php else: ?>
                    <?php foreach($pagedHistory as $r): ?>
                        <?php $photoUrl = thonglangUploadedImageUrl($r['visit_photo'] ?? ''); $detailPayload = $r; $detailPayload['photo_url'] = $photoUrl; ?>
                        <tr>
                            <td>
                                <div class="visit-history-date">
                                    <strong><?=e(thDate($r['visit_date']))?></strong>
                                    <span class="meta">เวลา <?=!empty($r['visit_time']) ? e(substr((string)$r['visit_time'],0,5)).' น.' : '-'?></span>
                                </div>
                            </td>
                            <td>
                                <div class="visit-history-type">
                                    <strong><?=e($r['visit_type'] ?: 'บันทึกการเข้าเยี่ยม')?><?=!empty($r['visit_no']) ? ' ครั้งที่ '.(int)$r['visit_no'] : ''?></strong>
                                    <span class="meta">วัตถุประสงค์: <?=e($r['purpose'] ?: '-')?></span>
                                </div>
                            </td>
                            <td><span class="visit-history-condition-badge"><?=e($r['general_condition'] ?: '-')?></span></td>
                            <td>
                                <div class="visit-history-next">
                                    <strong><?=e(!empty($r['next_visit_date']) ? thDate($r['next_visit_date']) : '-')?></strong>
                                    <?php if(!empty($r['referral_type']) && $r['referral_type'] !== 'ไม่ส่งต่อ'): ?>
                                        <span class="meta">ส่งต่อ: <?=e($r['referral_type'])?></span>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td><button type="button" class="visit-history-detail-btn" onclick='openCaregiverVisitHistoryDetail(<?=json_encode($detailPayload,JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_AMP|JSON_HEX_QUOT|JSON_UNESCAPED_UNICODE)?>)'>รายละเอียดเพิ่มเติม</button></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
</div>

<div class="visit-history-detail" id="caregiverVisitHistoryDetail"><div class="visit-history-detail-card"><div class="visit-history-detail-head"><div><h2 id="cvhName">รายละเอียดการเข้าเยี่ยม</h2><div class="mutedline" id="cvhDate"></div></div><button class="visit-history-detail-close" type="button" onclick="closeCaregiverVisitHistoryDetail()">×</button></div><div class="visit-history-detail-body" id="cvhBody"></div></div></div>
<?php else: ?>
<div class="visit-page">
<?php if($message):?><div class="alert ok"><?=e($message)?></div><?php endif;?>
<?php if($error):?><div class="alert err"><?=e($error)?></div><?php endif;?>
<div class="visit-layout">
<section class="visit-card">
<div class="visit-body">
<?php if(!$assignments):?>
<div class="empty">ยังไม่มีผู้สูงอายุที่อยู่ในความดูแล จึงยังไม่สามารถบันทึกการเข้าเยี่ยมได้</div>
<?php else:?>
<form method="post" id="visitForm" enctype="multipart/form-data">
<input type="hidden" name="action" value="save_visit">

<div class="section-title">1. ข้อมูลผู้สูงอายุ</div>
<div class="patient-selector-shell">
    <div class="field">
        <label>เลือกผู้สูงอายุ <span class="required" style="color:#d93025!important">*</span></label>
        <select name="assignment_id" required onchange="if(this.value){window.location='caregiver_visit.php?assignment_id='+this.value;}else{window.location='caregiver_visit.php';}">
            <option value="" <?=$selectedAssignmentId===0?'selected':''?>>-- กรุณาเลือกผู้สูงอายุ --</option>
            <?php foreach($assignments as $a):?>
                <option value="<?=(int)$a['assignment_id']?>" <?=((int)$a['assignment_id']===$selectedAssignmentId)?'selected':''?>><?=e($a['Fullname'])?><?=!empty($a['villagename'])?' • '.e($a['villagename']):''?></option>
            <?php endforeach;?>
        </select>
    </div>

    <?php if($selected): ?>
        <?php
            $patientVillage = trim((string)($selected['villagename'] ?? ''));
            $patientAddress = trim((string)($selected['Address'] ?? ''));
            $patientPhone = trim((string)($selected['Phone'] ?? ''));
            $patientDoctor = trim((string)($selected['doctor_name'] ?? $selected['doctor_username'] ?? ''));
        ?>
        <div class="patient-summary">
            <div class="summary-item summary-main">
                <span class="summary-label">ผู้สูงอายุ</span>
                <strong><?=e($selected['Fullname'])?></strong>
                <?php if($patientVillage !== ''):?><small><?=e($patientVillage)?></small><?php endif;?>
            </div>
            <div class="summary-item">
                <span class="summary-label">อายุ</span>
                <strong><?=e($selected['Age'])?> ปี</strong>
            </div>
            <div class="summary-item">
                <span class="summary-label">เบอร์โทรศัพท์</span>
                <strong><?=e($patientPhone !== '' ? $patientPhone : '-')?></strong>
            </div>
            <div class="summary-item">
                <span class="summary-label">หมอผู้มอบหมาย</span>
                <strong><?=e($patientDoctor !== '' ? $patientDoctor : '-')?></strong>
            </div>
        </div>
        <?php if($patientAddress !== ''): ?>
            <div class="summary-note">ที่อยู่: <?=e($patientAddress)?></div>
        <?php endif; ?>
    <?php else: ?>
        <div class="alert info" style="margin-top:14px">กรุณาเลือกผู้สูงอายุก่อน แล้วระบบจะแสดงเฉพาะข้อมูลสำคัญสำหรับการบันทึกการเข้าเยี่ยม</div>
    <?php endif; ?>
</div>

<?php if($selected): ?>
<div class="compact-form-grid">
    <section class="form-panel">
        <div class="section-title">2. ข้อมูลการเข้าเยี่ยม</div>
        <div class="grid-2">
            <div class="field">
                <label>วันที่เยี่ยม <span class="required" style="color:#d93025!important">*</span></label>
                <input type="date" name="visit_date" value="<?=e($_POST['visit_date']??date('Y-m-d'))?>" required>
            </div>
            <div class="field">
                <label>เวลา</label>
                <input type="time" name="visit_time" value="<?=e($_POST['visit_time']??date('H:i'))?>">
            </div>
            <div class="field">
                <label>ประเภทการเข้าเยี่ยม</label>
                <select name="visit_type">
                    <?php foreach(['การเข้าเยี่ยมตามแผน','การติดตามอาการ','เยี่ยมหลังออกจากโรงพยาบาล','เยี่ยมเร่งด่วน','อื่น ๆ'] as $v):?>
                        <option value="<?=e($v)?>" <?=($_POST['visit_type']??'การเข้าเยี่ยมตามแผน')===$v?'selected':''?>><?=e($v)?></option>
                    <?php endforeach;?>
                </select>
            </div>
            <div class="field">
                <label>วัตถุประสงค์ในการเยี่ยม</label>
                <textarea name="purpose" placeholder="เช่น ติดตามอาการ ประเมินสุขภาพ หรือเข้าเยี่ยมตามแผน"><?=e($_POST['purpose']??'')?></textarea>
            </div>
        </div>
    </section>

    <section class="form-panel">
        <div class="section-title">3. ข้อมูลสุขภาพที่สำคัญ</div>
        <div class="grid-3">
            <div class="field">
                <label>ความดันบน</label>
                <input type="number" name="bp_systolic" value="<?=e($_POST['bp_systolic']??'')?>" placeholder="120">
            </div>
            <div class="field">
                <label>ความดันล่าง</label>
                <input type="number" name="bp_diastolic" value="<?=e($_POST['bp_diastolic']??'')?>" placeholder="80">
            </div>
            <div class="field">
                <label>ชีพจร (ครั้ง/นาที)</label>
                <input type="number" name="pulse" value="<?=e($_POST['pulse']??'')?>" placeholder="72">
            </div>
        </div>
        <div class="grid-2" style="margin-top:13px">
            <div class="field">
                <label>การรับประทานยา</label>
                <select name="medication_status">
                    <option value="">-- เลือก --</option>
                    <?php foreach(['รับประทานยาตามคำสั่งแพทย์','ลืมรับประทานยาบางครั้ง','รับประทานยาไม่สม่ำเสมอ','ได้รับยาใหม่ / มีการปรับเปลี่ยนยา','ไม่สามารถประเมินได้'] as $v):?>
                        <option value="<?=e($v)?>" <?=($_POST['medication_status']??'')===$v?'selected':''?>><?=e($v)?></option>
                    <?php endforeach;?>
                </select>
            </div>
            <div class="field">
                <label>สภาพทั่วไป</label>
                <select name="general_condition">
                    <option value="">-- เลือก --</option>
                    <?php foreach(['ปกติ / คงที่','ดีขึ้น','อ่อนเพลีย','มีอาการผิดปกติ','ต้องเฝ้าระวัง'] as $v):?>
                        <option value="<?=e($v)?>" <?=($_POST['general_condition']??'')===$v?'selected':''?>><?=e($v)?></option>
                    <?php endforeach;?>
                </select>
            </div>
        </div>
        <div class="grid-2" style="margin-top:13px">
            <div class="field">
                <label>การช่วยเหลือตนเอง</label>
                <select name="adl_status">
                    <option value="">-- เลือก --</option>
                    <?php foreach(['ช่วยเหลือตนเองได้','ต้องการความช่วยเหลือบางส่วน','ต้องการผู้ดูแล'] as $v):?>
                        <option value="<?=e($v)?>" <?=($_POST['adl_status']??'')===$v?'selected':''?>><?=e($v)?></option>
                    <?php endforeach;?>
                </select>
            </div>
            <div class="field">
                <label>การเคลื่อนไหว</label>
                <select name="mobility_status">
                    <option value="">-- เลือก --</option>
                    <?php foreach(['เดินได้ปกติ','เดินลำบาก','ใช้ไม้เท้า','ใช้รถเข็น','ติดเตียง'] as $v):?>
                        <option value="<?=e($v)?>" <?=($_POST['mobility_status']??'')===$v?'selected':''?>><?=e($v)?></option>
                    <?php endforeach;?>
                </select>
            </div>
        </div>
        <div style="margin-top:13px">
            <div class="field">
                <label>อาการหรือสิ่งที่พบ</label>
                <textarea name="symptom_notes" placeholder="ระบุเฉพาะอาการสำคัญหรือสิ่งผิดปกติที่พบ"><?=e($_POST['symptom_notes']??'')?></textarea>
            </div>
        </div>
    </section>

    <section class="form-panel">
        <div class="section-title">4. การดูแลและติดตาม</div>
        <div class="grid-2">
            <div class="field">
                <label>การดูแล / การช่วยเหลือที่ให้</label>
                <textarea name="care_actions"><?=e($_POST['care_actions']??'')?></textarea>
            </div>
            <div class="field">
                <label>คำแนะนำที่ให้</label>
                <textarea name="advice"><?=e($_POST['advice']??'')?></textarea>
            </div>
            <div class="field">
                <label>การส่งต่อ</label>
                <select name="referral_type" id="referralType">
                    <?php foreach(['ไม่ส่งต่อ','โรงพยาบาล','หน่วยงานอื่น'] as $v):?>
                        <option value="<?=e($v)?>" <?=($_POST['referral_type']??'ไม่ส่งต่อ')===$v?'selected':''?>><?=e($v==='โรงพยาบาล'?'ส่งต่อโรงพยาบาล':($v==='หน่วยงานอื่น'?'ส่งต่อหน่วยงานอื่น':$v))?></option>
                    <?php endforeach;?>
                </select>
            </div>
            <div class="field">
                <label>เหตุผลที่ส่งต่อ</label>
                <textarea name="referral_reason" id="referralReason" placeholder="กรอกเมื่อมีการส่งต่อ"><?=e($_POST['referral_reason']??'')?></textarea>
            </div>
            <div class="field">
                <label>นัดติดตามครั้งถัดไป</label>
                <input type="date" name="next_visit_date" value="<?=e($_POST['next_visit_date']??($selected['next_visit_date']??''))?>">
            </div>
        </div>
    </section>

    <section class="visit-map-panel">
        <div class="visit-map-head">
            <div>
                <strong>5. ตำแหน่งบ้านของผู้สูงอายุ</strong>
            </div>
            <div class="visit-map-actions">
                <?php if (systemSetting($conn, 'allow_current_location', '1') === '1'): ?><button type="button" class="visit-map-btn primary" id="visitUseCurrentLocation">ใช้ตำแหน่งปัจจุบัน</button><?php endif; ?>
                <button type="button" class="visit-map-btn" id="visitClearLocation">ล้างตำแหน่ง</button>
            </div>
        </div>
        <div id="visitPatientLocationMap" aria-label="เลือกตำแหน่งบ้านของผู้สูงอายุ"></div>
        <div class="visit-map-coordinates">
            <div class="field">
                <label for="patient_latitude">ละติจูด</label>
                <input type="text" name="patient_latitude" id="patient_latitude" value="<?=e($_POST['patient_latitude']??($selected['Latitude']??''))?>" placeholder="เช่น 14.9799000">
            </div>
            <div class="field">
                <label for="patient_longitude">ลองจิจูด</label>
                <input type="text" name="patient_longitude" id="patient_longitude" value="<?=e($_POST['patient_longitude']??($selected['Longitude']??''))?>" placeholder="เช่น 102.3157000">
            </div>
        </div>
    </section>

    <section class="form-panel">
        <div class="section-title">6. รูปภาพประกอบ (ถ้ามี)</div>
        <div class="visit-photo-upload compact-photo-upload">
            <div class="visit-photo-preview" id="visitPhotoPreview"><span>ตัวอย่างรูปภาพ</span></div>
            <div class="field visit-photo-field">
                <label>แนบไฟล์รูปภาพ</label>
                <input type="file" name="visit_photo_file" id="visitPhotoFile" accept="image/jpeg,image/png,image/gif,image/webp">
                <small>ไม่บังคับ • รองรับ JPG, PNG, GIF หรือ WEBP ขนาดไม่เกิน 5 MB</small>
            </div>
        </div>
    </section>
</div>
<div class="visit-actions compact-actions"><button type="submit" class="btn-save">บันทึกข้อมูลการเยี่ยม</button></div>
<?php endif; ?>
</form>
<?php endif;?>
</div></section>


</div></div>
<?php endif; ?>
<?php endif; ?>
</div>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
<script>
(function(){
 const select=document.getElementById('visitPatientSelect'), input=document.getElementById('visitPatientSearch'), clear=document.getElementById('visitPatientClear'), toggle=document.getElementById('visitPatientToggle'), wrap=document.getElementById('visitPatientOptions'), empty=document.getElementById('visitPatientEmpty'), record=document.getElementById('visitRecordLink'), hist=document.getElementById('visitHistoryLink');
 const opts=Array.from(document.querySelectorAll('.visit-search-option'));
 if(!select||!input) return;
 function links(){const id=select.value,ok=id!=='';if(record){record.href=ok?'caregiver_visit.php?assignment_id='+encodeURIComponent(id):'caregiver_visit.php';record.classList.toggle('is-disabled',!ok)}if(hist){hist.href=ok?'caregiver_visit.php?mode=history&assignment_id='+encodeURIComponent(id):'caregiver_visit.php?mode=history';hist.classList.toggle('is-disabled',!ok)}}
 function open(){wrap&&wrap.classList.add('is-open')} function close(){wrap&&wrap.classList.remove('is-open');opts.forEach(n=>n.classList.remove('is-active'))}
 function clearState(){clear&&clear.classList.toggle('is-visible',input.value.trim()!=='')}
 function filter(){const q=input.value.trim().toLocaleLowerCase('th-TH');let shown=0;opts.forEach(n=>{const hay=((n.dataset.search||'')+' '+(n.dataset.label||'')).toLocaleLowerCase('th-TH'),m=!q||hay.includes(q);n.style.display=m?'block':'none';n.classList.toggle('is-active',m&&shown===0);if(m)shown++});empty&&empty.classList.toggle('is-visible',shown===0);clearState()}
 function showAll(){let shown=0;opts.forEach(n=>{n.style.display='block';n.classList.toggle('is-active',shown===0);shown++});empty&&empty.classList.toggle('is-visible',shown===0);clearState()}
 function choose(n){select.value=n.dataset.value||'';input.value=n.dataset.label||'';clearState();close();links()}
 function openAllPatients(){open();showAll()}
 input.addEventListener('focus',openAllPatients);input.addEventListener('click',openAllPatients);input.addEventListener('input',()=>{select.value='';links();open();filter()});
 opts.forEach(n=>n.addEventListener('click',()=>choose(n)));toggle&&toggle.addEventListener('click',()=>{if(wrap&&wrap.classList.contains('is-open'))close();else{open();showAll();input.focus()}});clear&&clear.addEventListener('click',()=>{input.value='';select.value='';clearState();links();open();showAll();input.focus()});document.addEventListener('click',e=>{if(!e.target.closest('#visitPatientBox'))close()});clearState();links();
})();
(function(){var type=document.getElementById('referralType'),reason=document.getElementById('referralReason');if(type&&reason){function sync(){var need=type.value&&type.value!=='ไม่ส่งต่อ';reason.required=need;reason.closest('.field').style.opacity=need?'1':'.65'}type.addEventListener('change',sync);sync();}})();
(function(){var input=document.getElementById('visitPhotoFile'),preview=document.getElementById('visitPhotoPreview');if(!input||!preview)return;input.addEventListener('change',function(){var file=this.files&&this.files[0];if(!file){preview.innerHTML='<span>ตัวอย่างรูปภาพ</span>';return;}if(!file.type.match(/^image\//)){preview.innerHTML='<span>กรุณาเลือกไฟล์รูปภาพ</span>';return;}var reader=new FileReader();reader.onload=function(e){preview.innerHTML='<img src="'+e.target.result+'" alt="ตัวอย่างรูปภาพ">';};reader.readAsDataURL(file);});})();
(function(){
    var mapEl=document.getElementById('visitPatientLocationMap');
    var latInput=document.getElementById('patient_latitude');
    var lngInput=document.getElementById('patient_longitude');
    var useBtn=document.getElementById('visitUseCurrentLocation');
    var clearBtn=document.getElementById('visitClearLocation');
    if(!mapEl||!latInput||!lngInput||typeof L==='undefined') return;
    var defaultCenter=[<?= json_encode((float)systemSetting($conn, 'map_default_lat', '15.045')) ?>,<?= json_encode((float)systemSetting($conn, 'map_default_lng', '102.330')) ?>];
    var defaultZoom=<?= (int)systemSetting($conn, 'map_default_zoom', '13') ?>;
    var map=L.map('visitPatientLocationMap',{zoomControl:true,minZoom:11,maxZoom:19}).setView(defaultCenter,defaultZoom);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'&copy; OpenStreetMap contributors'}).addTo(map);
    var marker=null;
    function setCoordinate(lat,lng,focus){
        var latNum=parseFloat(lat), lngNum=parseFloat(lng);
        if(!isFinite(latNum)||!isFinite(lngNum)) return;
        latInput.value=latNum.toFixed(7);
        lngInput.value=lngNum.toFixed(7);
        if(marker){ marker.setLatLng([latNum,lngNum]); } else { marker=L.marker([latNum,lngNum]).addTo(map); }
        if(focus!==false) map.setView([latNum,lngNum],16);
    }
    function clearCoordinate(){
        latInput.value=''; lngInput.value='';
        if(marker){ map.removeLayer(marker); marker=null; }
        map.setView(defaultCenter,13);
    }
    map.on('click', function(e){ setCoordinate(e.latlng.lat, e.latlng.lng, true); });
    [latInput,lngInput].forEach(function(input){ input.addEventListener('change', function(){
        if(latInput.value.trim()===''&&lngInput.value.trim()===''){ clearCoordinate(); return; }
        if(latInput.value.trim()!==''&&lngInput.value.trim()!==''){ setCoordinate(latInput.value, lngInput.value, true); }
    });});
    if(useBtn){ useBtn.addEventListener('click', function(){
        if(!navigator.geolocation){ alert('อุปกรณ์นี้ไม่รองรับการระบุตำแหน่ง'); return; }
        navigator.geolocation.getCurrentPosition(function(pos){ setCoordinate(pos.coords.latitude, pos.coords.longitude, true); }, function(){ alert('ไม่สามารถดึงตำแหน่งปัจจุบันได้'); }, {enableHighAccuracy:true,timeout:10000,maximumAge:0});
    }); }
    if(clearBtn){ clearBtn.addEventListener('click', clearCoordinate); }
    if(latInput.value.trim()!==''&&lngInput.value.trim()!==''){ setCoordinate(latInput.value, lngInput.value, true); }
});
function caregiverVisitHistoryEsc(v){return String(v??'').replace(/[&<>'"]/g,function(c){return({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'})[c];});}
function caregiverVisitHistoryBox(label,value,full){return '<div class="visit-history-detail-box'+(full?' full':'')+'"><span>'+caregiverVisitHistoryEsc(label)+'</span><strong>'+(value?caregiverVisitHistoryEsc(value):'-')+'</strong></div>';}
function openCaregiverVisitHistoryDetail(r){
    var nameEl=document.getElementById('cvhName'),dateEl=document.getElementById('cvhDate'),bodyEl=document.getElementById('cvhBody'),modal=document.getElementById('caregiverVisitHistoryDetail');
    if(!nameEl||!dateEl||!bodyEl||!modal)return;
    nameEl.textContent=(r.visit_type||'บันทึกการเข้าเยี่ยม')+(r.visit_no?' ครั้งที่ '+r.visit_no:'');
    dateEl.textContent=(r.visit_date||'')+(r.visit_time?' • '+String(r.visit_time).slice(0,5)+' น.':'');
    var h='';
    if((Number(r.doctor_referral||0)===1) || (r.referral_type && r.referral_type!=='ไม่ส่งต่อ')){ h+='<div class="visit-history-alert">รายการนี้มีการส่งต่อ'+(r.referral_reason?' — '+caregiverVisitHistoryEsc(r.referral_reason):'')+'</div>'; }
    h+='<div class="visit-history-detail-label">ข้อมูลการเข้าเยี่ยม</div><div class="visit-history-detail-grid">';
    h+=caregiverVisitHistoryBox('ประเภทการเยี่ยม',r.visit_type)+caregiverVisitHistoryBox('ครั้งที่เข้าเยี่ยม',r.visit_no)+caregiverVisitHistoryBox('สภาพทั่วไป',r.general_condition)+caregiverVisitHistoryBox('วัตถุประสงค์การเข้าเยี่ยม',r.purpose,true)+caregiverVisitHistoryBox('นัดติดตามครั้งถัดไป',r.next_visit_date)+caregiverVisitHistoryBox('การส่งต่อ',r.referral_type)+caregiverVisitHistoryBox('เหตุผลที่ส่งต่อ',r.referral_reason,true);
    h+='</div><div class="visit-history-detail-label">รายละเอียดการดูแล</div><div class="visit-history-detail-grid">';
    h+=caregiverVisitHistoryBox('อาการและข้อสังเกต',r.symptom_notes,true)+caregiverVisitHistoryBox('การดูแลและความช่วยเหลือที่ให้',r.care_actions,true)+caregiverVisitHistoryBox('คำแนะนำแก่ผู้สูงอายุ / ผู้ดูแล',r.advice,true)+caregiverVisitHistoryBox('หมายเหตุ',r.note,true);
    h+='</div>';
    if(r.photo_url){ h+='<div class="visit-history-detail-label">รูปภาพประกอบการเข้าเยี่ยม</div><div style="padding:4px 0 6px"><img src="'+caregiverVisitHistoryEsc(r.photo_url)+'" alt="รูปภาพการเข้าเยี่ยม" style="max-width:320px;width:100%;height:auto;max-height:320px;object-fit:cover;border-radius:14px;border:1px solid #d8ebe8"></div>'; }
    bodyEl.innerHTML=h; modal.classList.add('open');
}
function closeCaregiverVisitHistoryDetail(){var modal=document.getElementById('caregiverVisitHistoryDetail');if(modal)modal.classList.remove('open');}
(function(){var modal=document.getElementById('caregiverVisitHistoryDetail');if(modal){modal.addEventListener('click',function(e){if(e.target.id==='caregiverVisitHistoryDetail')closeCaregiverVisitHistoryDetail();});}})();
</script>

<script>
(function(){
  const THAI_MONTHS=['มกราคม','กุมภาพันธ์','มีนาคม','เมษายน','พฤษภาคม','มิถุนายน','กรกฎาคม','สิงหาคม','กันยายน','ตุลาคม','พฤศจิกายน','ธันวาคม'];
  const THAI_SHORT=['ม.ค.','ก.พ.','มี.ค.','เม.ย.','พ.ค.','มิ.ย.','ก.ค.','ส.ค.','ก.ย.','ต.ค.','พ.ย.','ธ.ค.'];
  function initPicker(root){
    const toggle=root.querySelector('.thai-month-picker-toggle');
    const label=root.querySelector('.thai-month-picker-label');
    const pop=root.querySelector('.thai-month-picker-popover');
    const yearEl=root.querySelector('.thai-month-picker-year');
    const grid=root.querySelector('.thai-month-grid');
    const hidden=root.querySelector('input[name="month"]');
    const prevYear=root.querySelector('[data-year-prev]');
    const nextYear=root.querySelector('[data-year-next]');
    const todayBtn=root.querySelector('.thai-month-today');
    if(!toggle||!pop||!yearEl||!grid||!hidden)return;
    const now=new Date();
    const maxY=now.getFullYear(), maxM=now.getMonth()+1;
    let [selY,selM]=(hidden.value||'').split('-').map(Number);
    if(!selY||!selM){selY=maxY;selM=maxM;}
    let viewY=selY;
    function close(){root.classList.remove('open');toggle.setAttribute('aria-expanded','false');}
    function render(){
      yearEl.textContent=String(viewY+543);
      grid.innerHTML='';
      THAI_SHORT.forEach((m,i)=>{
        const month=i+1;
        const b=document.createElement('button');b.type='button';b.className='thai-month-option';b.textContent=m;
        const future=viewY>maxY||(viewY===maxY&&month>maxM);
        b.disabled=future;
        if(viewY===selY&&month===selM)b.classList.add('selected');
        b.addEventListener('click',()=>{selY=viewY;selM=month;hidden.value=selY+'-'+String(selM).padStart(2,'0');label.textContent=THAI_MONTHS[selM-1]+' '+(selY+543);close();hidden.form.submit();});
        grid.appendChild(b);
      });
      if(nextYear) nextYear.disabled=viewY>=maxY;
    }
    toggle.addEventListener('click',e=>{e.stopPropagation();const isOpen=root.classList.toggle('open');toggle.setAttribute('aria-expanded',isOpen?'true':'false');if(isOpen){viewY=selY;render();}});
    prevYear&&prevYear.addEventListener('click',()=>{viewY--;render();});
    nextYear&&nextYear.addEventListener('click',()=>{if(viewY<maxY){viewY++;render();}});
    todayBtn&&todayBtn.addEventListener('click',()=>{selY=maxY;selM=maxM;hidden.value=selY+'-'+String(selM).padStart(2,'0');label.textContent=THAI_MONTHS[selM-1]+' '+(selY+543);close();hidden.form.submit();});
    document.addEventListener('click',e=>{if(!root.contains(e.target))close();});
    render();
  }
  document.querySelectorAll('.thai-month-picker').forEach(initPicker);
})();
</script>

</body></html>
