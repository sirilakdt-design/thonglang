ALTER TABLE adl_assessment
  ADD COLUMN caregiver_user_id INT NULL,
  ADD COLUMN handoff_status VARCHAR(40) NOT NULL DEFAULT 'รอส่งต่อ',
  ADD COLUMN caregiver_completed_at DATETIME NULL;
