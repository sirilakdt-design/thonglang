-- ใช้ไฟล์นี้เฉพาะกรณีบัญชีฐานข้อมูลไม่มีสิทธิ์ ALTER TABLE อัตโนมัติ
-- ถ้ามีคอลัมน์ Latitude / Longitude อยู่แล้ว ไม่ต้องรันซ้ำ
ALTER TABLE patient
    ADD COLUMN Latitude DECIMAL(10,7) NULL AFTER Village_id,
    ADD COLUMN Longitude DECIMAL(10,7) NULL AFTER Latitude;
