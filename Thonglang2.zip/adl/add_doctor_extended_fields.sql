-- เพิ่มเฉพาะข้อมูลหมอที่ต้องการ
ALTER TABLE `users`
    ADD COLUMN `doctor_code` VARCHAR(50) NULL AFTER `phone_number`,
    ADD COLUMN `department` VARCHAR(150) NULL AFTER `medical_position`;


