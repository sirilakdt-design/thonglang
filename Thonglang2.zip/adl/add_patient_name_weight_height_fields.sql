-- เพิ่มฟิลด์ชื่อ/นามสกุล น้ำหนัก และส่วนสูงในตาราง patient
-- หมายเหตุ: ตัวระบบจะตรวจและเพิ่มคอลัมน์ให้อัตโนมัติผ่าน database_schema_upgrade.php อยู่แล้ว

ALTER TABLE `patient`
    ADD COLUMN IF NOT EXISTS `Firstname` VARCHAR(120) NULL AFTER `Patient_id`,
    ADD COLUMN IF NOT EXISTS `Lastname` VARCHAR(120) NULL AFTER `Firstname`,
    ADD COLUMN IF NOT EXISTS `Weight_kg` DECIMAL(6,2) NULL AFTER `Age`,
    ADD COLUMN IF NOT EXISTS `Height_cm` DECIMAL(6,2) NULL AFTER `Weight_kg`;
