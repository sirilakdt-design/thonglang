<?php
require_once __DIR__ . '/../connect.php';
ensureThonglangCoreSchema($conn);
requireRole('doctor');
mysqli_set_charset($conn, 'utf8mb4');

$message = '';
$error = '';
$doctorId = (int) ($_SESSION['user_id'] ?? 0);

$create = "CREATE TABLE IF NOT EXISTS adl_assessment (
    adl_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    caregiver_user_id INT NULL,
    doctor_user_id INT NULL,
    assessment_date DATE NOT NULL,
    feeding TINYINT NOT NULL,
    grooming TINYINT NOT NULL,
    transfer TINYINT NOT NULL,
    toilet_use TINYINT NOT NULL,
    mobility TINYINT NOT NULL,
    dressing TINYINT NOT NULL,
    stairs TINYINT NOT NULL,
    bathing TINYINT NOT NULL,
    bowels TINYINT NOT NULL,
    bladder TINYINT NOT NULL,
    total_score SMALLINT NOT NULL,
    regular_caregiver VARCHAR(120) NULL,
    welfare_status VARCHAR(60) NULL,
    club_membership VARCHAR(120) NULL,
    note TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_patient(patient_id),
    KEY idx_caregiver(caregiver_user_id),
    KEY idx_doctor(doctor_user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
if (!mysqli_query($conn, $create)) {
    $error = 'ไม่สามารถเตรียมตาราง ADL ได้: ' . mysqli_error($conn);
}

function ensureAdlColumn(mysqli $conn, string $column, string $definition): void
{
    $safe = preg_replace('/[^a-zA-Z0-9_]/', '', $column);
    try {
        $res = mysqli_query($conn, "SHOW COLUMNS FROM adl_assessment WHERE Field = '" . mysqli_real_escape_string($conn, $safe) . "'");
        if ($res && mysqli_num_rows($res) === 0) {
            mysqli_query($conn, "ALTER TABLE adl_assessment ADD COLUMN `$safe` $definition");
        }
    } catch (mysqli_sql_exception $e) {
        // เก็บข้อความไว้ให้หน้าจอแสดงแทนการหยุดทำงานแบบ Fatal error
        global $error;
        if ($error === '') {
            $error = 'ไม่สามารถปรับโครงสร้างตาราง ADL ได้: ' . $e->getMessage();
        }
    }
}

/*
 * รองรับฐานข้อมูลเดิมที่เคยสร้างตาราง adl_assessment ไว้แล้ว
 * CREATE TABLE IF NOT EXISTS จะไม่เพิ่มคอลัมน์ใหม่ให้ตารางเก่า จึงตรวจและเพิ่มทีละคอลัมน์
 * คอลัมน์ของข้อมูลเดิมใช้ NULL/DEFAULT เพื่อไม่ทำลายประวัติเดิม
 */
ensureAdlColumn($conn, 'patient_id', 'INT NULL');
ensureAdlColumn($conn, 'caregiver_user_id', 'INT NULL');
ensureAdlColumn($conn, 'doctor_user_id', 'INT NULL');
ensureAdlColumn($conn, 'assessment_date', 'DATE NULL');
ensureAdlColumn($conn, 'feeding', 'TINYINT NULL');
ensureAdlColumn($conn, 'grooming', 'TINYINT NULL');
ensureAdlColumn($conn, 'transfer', 'TINYINT NULL');
ensureAdlColumn($conn, 'toilet_use', 'TINYINT NULL');
ensureAdlColumn($conn, 'mobility', 'TINYINT NULL');
ensureAdlColumn($conn, 'dressing', 'TINYINT NULL');
ensureAdlColumn($conn, 'stairs', 'TINYINT NULL');
ensureAdlColumn($conn, 'bathing', 'TINYINT NULL');
ensureAdlColumn($conn, 'bowels', 'TINYINT NULL');
ensureAdlColumn($conn, 'bladder', 'TINYINT NULL');
ensureAdlColumn($conn, 'total_score', 'SMALLINT NOT NULL DEFAULT 0');
ensureAdlColumn($conn, 'regular_caregiver', 'VARCHAR(120) NULL');
ensureAdlColumn($conn, 'welfare_status', 'VARCHAR(60) NULL');
ensureAdlColumn($conn, 'club_membership', 'VARCHAR(120) NULL');
ensureAdlColumn($conn, 'note', 'TEXT NULL');
ensureAdlColumn($conn, 'created_at', 'TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP');
ensureAdlColumn($conn, 'handoff_status', "VARCHAR(40) NOT NULL DEFAULT 'รอส่งต่อ'");
ensureAdlColumn($conn, 'caregiver_total_score', 'TINYINT NULL');
ensureAdlColumn($conn, 'result_returned_to_doctor', 'TINYINT(1) NOT NULL DEFAULT 0');
ensureAdlColumn($conn, 'result_returned_at', 'DATETIME NULL');
ensureAdlColumn($conn, 'caregiver_completed_at', 'DATETIME NULL');

/* ฐานข้อมูลรุ่นเก่าเคยกำหนด caregiver_user_id เป็น NOT NULL
 * ปัจจุบัน ADL ย้ายมาให้หมอเป็นผู้ประเมิน จึงอนุญาตให้ฟิลด์เดิมเป็น NULL
 * เพื่อเก็บประวัติเดิมไว้โดยไม่ต้องลบข้อมูลเก่า
 */
try {
    mysqli_query($conn, "ALTER TABLE adl_assessment MODIFY caregiver_user_id INT NULL");
} catch (mysqli_sql_exception $e) {
    if ($error === '') {
        $error = 'ไม่สามารถปรับตาราง ADL สำหรับผู้ใช้งานหมอได้: ' . $e->getMessage();
    }
}

$patients = [];
$res = mysqli_query($conn, "SELECT Patient_id,Firstname,Lastname,Fullname,Age,Weight_kg,Height_cm,Address,Phone,Disease FROM patient ORDER BY Fullname ASC");
if ($res) {
    while ($row = mysqli_fetch_assoc($res)) {
        $patients[] = $row;
    }
} elseif ($error === '') {
    $error = 'ไม่สามารถอ่านรายชื่อผู้สูงอายุได้: ' . mysqli_error($conn);
}

/* =========================================================
   ข้อมูลหมู่บ้าน + เพิ่มผู้สูงอายุจากหน้า ADL
========================================================= */
$villages = [];
$villageRes = mysqli_query(
    $conn,
    "SELECT village_id, villagename, district, province
     FROM village
     ORDER BY village_id ASC"
);
if ($villageRes) {
    while ($villageRow = mysqli_fetch_assoc($villageRes)) {
        $villages[] = $villageRow;
    }
}

$addPatientModalOpen = false;

if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && (string) ($_POST['action'] ?? '') === 'add_patient'
    && $error === ''
) {
    $addPatientModalOpen = true;

    $newFirstname = trim((string) ($_POST['new_firstname'] ?? ''));
    $newLastname = trim((string) ($_POST['new_lastname'] ?? ''));
    $newFullname = trim($newFirstname . ' ' . $newLastname);
    $newGender = trim((string) ($_POST['new_gender'] ?? ''));
    $newAge = (int) ($_POST['new_age'] ?? 0);
    $newWeight = trim((string) ($_POST['new_weight_kg'] ?? ''));
    $newHeight = trim((string) ($_POST['new_height_cm'] ?? ''));
    $newWeightValue = $newWeight === '' ? null : (float) $newWeight;
    $newHeightValue = $newHeight === '' ? null : (float) $newHeight;
    $newVillageId = (int) ($_POST['new_village_id'] ?? 0);
    $newAddress = trim((string) ($_POST['new_address'] ?? ''));
    $newPhone = trim((string) ($_POST['new_phone'] ?? ''));
    $newDisease = trim((string) ($_POST['new_disease'] ?? ''));

    if (
        $newFirstname === ''
        || $newLastname === ''
        || !in_array($newGender, ['ชาย', 'หญิง'], true)
        || $newAge <= 0
        || $newAge > 150
        || $newVillageId <= 0
    ) {
        $error = 'กรุณากรอกชื่อ นามสกุล เพศ อายุ และหมู่บ้านให้ครบถ้วน';
    } elseif ($newWeight !== '' && ($newWeightValue <= 0 || $newWeightValue > 500)) {
        $error = 'กรุณากรอกน้ำหนักให้ถูกต้อง';
    } elseif ($newHeight !== '' && ($newHeightValue <= 0 || $newHeightValue > 300)) {
        $error = 'กรุณากรอกส่วนสูงให้ถูกต้อง';
    } elseif ($newPhone !== '' && !preg_match('/^[0-9]{9,10}$/', $newPhone)) {
        $error = 'กรุณากรอกเบอร์โทรเป็นตัวเลข 9-10 หลัก';
    } else {
        $villageCheck = mysqli_prepare(
            $conn,
            "SELECT village_id FROM village WHERE village_id=? LIMIT 1"
        );
        $validVillage = false;

        if ($villageCheck) {
            mysqli_stmt_bind_param($villageCheck, 'i', $newVillageId);
            mysqli_stmt_execute($villageCheck);
            $validVillage = (bool) mysqli_fetch_row(mysqli_stmt_get_result($villageCheck));
            mysqli_stmt_close($villageCheck);
        }

        if (!$validVillage) {
            $error = 'ไม่พบข้อมูลหมู่บ้านที่เลือก';
        } else {
            $stmt = mysqli_prepare(
                $conn,
                "INSERT INTO patient
                    (Firstname,Lastname,Fullname,Gender,Age,Weight_kg,Height_cm,Address,Phone,Disease,Village_id)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?)"
            );

            if (!$stmt) {
                $error = 'ไม่สามารถเตรียมคำสั่งเพิ่มข้อมูลผู้สูงอายุได้: ' . mysqli_error($conn);
            } else {
                mysqli_stmt_bind_param(
                    $stmt,
                    'ssssiddsssi',
                    $newFirstname,
                    $newLastname,
                    $newFullname,
                    $newGender,
                    $newAge,
                    $newWeightValue,
                    $newHeightValue,
                    $newAddress,
                    $newPhone,
                    $newDisease,
                    $newVillageId
                );

                if (mysqli_stmt_execute($stmt)) {
                    $newPatientId = (int) mysqli_insert_id($conn);
                    mysqli_stmt_close($stmt);

                    header('Location: adl.php?new_patient=' . $newPatientId . '#adlForm');
                    exit;
                }

                $error = 'เพิ่มข้อมูลผู้สูงอายุไม่สำเร็จ: ' . mysqli_stmt_error($stmt);
                mysqli_stmt_close($stmt);
            }
        }
    }
}

$adlItems = [
    'feeding' => [
        'title' => '1. การรับประทานอาหาร',
        'subtitle' => 'รับประทานอาหารเมื่อเตรียมสำรับไว้ให้เรียบร้อยต่อหน้า',
        'options' => [
            0 => 'ไม่สามารถตักอาหารเข้าปากได้ ต้องมีคนป้อนให้',
            1 => 'ตักอาหารเองได้แต่ต้องมีคนช่วย เช่น ช่วยใช้ช้อนตักเตรียมไว้ให้ หรือตัดเป็นชิ้นเล็ก ๆ ไว้ล่วงหน้า',
            2 => 'ตักอาหารและช่วยตัวเองได้เป็นปกติ',
        ],
    ],
    'grooming' => [
        'title' => '2. การดูแลตนเอง',
        'subtitle' => 'ล้างหน้า หวีผม แปรงฟัน โกนหนวด ในระยะเวลา 24 - 28 ชั่วโมงที่ผ่านมา',
        'options' => [
            0 => 'ต้องการความช่วยเหลือ',
            1 => 'ทำเองได้ (รวมทั้งที่ทำได้เองถ้าเตรียมอุปกรณ์ไว้ให้)',
        ],
    ],
    'transfer' => [
        'title' => '3. การลุกนั่งและเคลื่อนย้าย',
        'subtitle' => 'ลุกนั่งจากที่นอน หรือจากเตียงไปยังเก้าอี้',
        'options' => [
            0 => 'ไม่สามารถนั่งได้ (นั่งแล้วจะล้มเสมอ) หรือต้องใช้คนสองคนช่วยกันยกขึ้น',
            1 => 'ต้องการความช่วยเหลืออย่างมากจึงจะนั่งได้ เช่น ต้องใช้คนที่แข็งแรงหรือมีทักษะ 1 คน หรือใช้คนทั่วไป 2 คนพยุงหรือดันขึ้นมาจึงจะนั่งอยู่ได้',
            2 => 'ต้องการความช่วยเหลือบ้าง เช่น บอกให้ทำตาม หรือช่วยพยุงเล็กน้อย หรือต้องมีคนดูแลเพื่อความปลอดภัย',
            3 => 'ทำได้เอง',
        ],
    ],
    'toilet_use' => [
        'title' => '4. การใช้ห้องน้ำ',
        'subtitle' => 'ใช้ห้องน้ำ',
        'options' => [
            0 => 'ช่วยตัวเองไม่ได้',
            1 => 'ทำเองได้บ้าง (อย่างน้อยทำความสะอาดตัวเองได้หลังจากเสร็จธุระ) แต่ต้องการความช่วยเหลือในบางสิ่ง',
            2 => 'ช่วยตัวเองได้ดี (ขึ้นนั่งและลงจากโถส้วมเองได้ ทำความสะอาดได้เรียบร้อยหลังจากเสร็จธุระ ถอดใส่เสื้อผ้าได้เรียบร้อย)',
        ],
    ],
    'mobility' => [
        'title' => '5. การเคลื่อนที่',
        'subtitle' => 'การเคลื่อนที่ภายในห้องหรือบ้าน',
        'options' => [
            0 => 'เคลื่อนที่ไปไหนไม่ได้',
            1 => 'ต้องใช้รถเข็นช่วยตัวเองให้เคลื่อนที่ได้เอง (ไม่ต้องมีคนเข็นให้) และจะต้องเข้าออกมุมห้องหรือประตูได้',
            2 => 'เดินหรือเคลื่อนที่โดยมีคนช่วย เช่น พยุง หรือบอกให้ทำตาม หรือต้องให้ความสนใจดูแลเพื่อความปลอดภัย',
            3 => 'เดินหรือเคลื่อนที่ได้เอง',
        ],
    ],
    'dressing' => [
        'title' => '6. การสวมใส่เสื้อผ้า',
        'subtitle' => 'การสวมใส่เสื้อผ้า',
        'options' => [
            0 => 'ต้องมีคนสวมใส่ให้ ช่วยตัวเองแทบไม่ได้หรือน้อย',
            1 => 'ช่วยตัวเองได้ประมาณร้อยละ 50 ที่เหลือต้องมีคนช่วย',
            2 => 'ช่วยตัวเองได้ดี (รวมทั้งการติดกระดุม รูดซิป หรือใช้เสื้อผ้าที่ดัดแปลงให้เหมาะสมก็ได้)',
        ],
    ],
    'stairs' => [
        'title' => '7. การขึ้นลงบันได',
        'subtitle' => 'การขึ้นลงบันได 1 ชั้น',
        'options' => [
            0 => 'ไม่สามารถทำได้',
            1 => 'ต้องการคนช่วย',
            2 => 'ขึ้นลงได้เอง (ถ้าต้องใช้เครื่องช่วยเดิน เช่น walker จะต้องเอาขึ้นลงได้ด้วย)',
        ],
    ],
    'bathing' => [
        'title' => '8. การอาบน้ำ',
        'subtitle' => 'การอาบน้ำ',
        'options' => [
            0 => 'ต้องมีคนช่วยหรือทำให้',
            1 => 'อาบน้ำเองได้',
        ],
    ],
    'bowels' => [
        'title' => '9. การกลั้นอุจจาระ',
        'subtitle' => 'การกลั้นการถ่ายอุจจาระในระยะ 1 สัปดาห์ที่ผ่านมา',
        'options' => [
            0 => 'กลั้นไม่ได้ หรือต้องการการสวนอุจจาระอยู่เสมอ',
            1 => 'กลั้นไม่ได้บางครั้ง (เป็นน้อยกว่า 1 ครั้งต่อสัปดาห์)',
            2 => 'กลั้นได้เป็นปกติ',
        ],
    ],
    'bladder' => [
        'title' => '10. การกลั้นปัสสาวะ',
        'subtitle' => 'การกลั้นปัสสาวะในระยะ 1 สัปดาห์ที่ผ่านมา',
        'options' => [
            0 => 'กลั้นไม่ได้ หรือใส่สายสวนปัสสาวะแต่ไม่สามารถดูแลเองได้',
            1 => 'กลั้นไม่ได้บางครั้ง (เป็นน้อยกว่าวันละ 1 ครั้ง)',
            2 => 'กลั้นได้เป็นปกติ',
        ],
    ],
];

/* =========================================================
   ข้อความรายละเอียดคำถาม ADL ที่แก้ไขได้
   - เก็บชื่อข้อ
   - คำอธิบาย
   - ข้อความตัวเลือก
   คะแนนตัวเลขยังคงเดิมเพื่อไม่ให้สูตร ADL เปลี่ยน
========================================================= */
$defaultAdlItems = $adlItems;

$questionConfigSql = "CREATE TABLE IF NOT EXISTS adl_question_config (
    field_key VARCHAR(50) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    subtitle TEXT NULL,
    options_json LONGTEXT NOT NULL,
    updated_by INT NULL,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if (!mysqli_query($conn, $questionConfigSql) && $error === '') {
    $error = 'ไม่สามารถเตรียมตารางรายละเอียดคำถาม ADL ได้: ' . mysqli_error($conn);
}

if ($error === '') {
    $configRes = mysqli_query(
        $conn,
        "SELECT field_key,title,subtitle,options_json
         FROM adl_question_config"
    );

    if ($configRes) {
        while ($configRow = mysqli_fetch_assoc($configRes)) {
            $fieldKey = (string) ($configRow['field_key'] ?? '');

            if (!isset($adlItems[$fieldKey], $defaultAdlItems[$fieldKey])) {
                continue;
            }

            $title = trim((string) ($configRow['title'] ?? ''));
            $subtitle = (string) ($configRow['subtitle'] ?? '');
            $savedOptions = json_decode((string) ($configRow['options_json'] ?? ''), true);

            if ($title !== '') {
                $adlItems[$fieldKey]['title'] = $title;
            }

            $adlItems[$fieldKey]['subtitle'] = $subtitle;

            if (is_array($savedOptions)) {
                foreach ($defaultAdlItems[$fieldKey]['options'] as $score => $defaultText) {
                    $lookupKey = (string) $score;

                    if (array_key_exists($lookupKey, $savedOptions)) {
                        $adlItems[$fieldKey]['options'][$score] = (string) $savedOptions[$lookupKey];
                    } elseif (array_key_exists($score, $savedOptions)) {
                        $adlItems[$fieldKey]['options'][$score] = (string) $savedOptions[$score];
                    }
                }
            }
        }
    }
}

$rules = [];
foreach ($adlItems as $key => $item) {
    $rules[$key] = array_keys($item['options']);
}

$caregiverOptions = [
    'ไม่มี ลูกญาติทอดทิ้ง',
    'ไม่มี อยู่ตามลำพังไม่มีญาติ',
    'มี ครอบครัวดูแล',
    'มี เพื่อนบ้านดูแล',
];
$welfareOptions = ['ไม่ได้รับ', 'ได้รับ', 'ไม่ทราบ'];
$clubOptions = ['ไม่ได้เป็น', 'ชมรมผู้สูงอายุ', 'คลังปัญญา', 'ชมรมผู้สูงอายุและคลังปัญญา', 'อื่นๆ'];

/* =========================================================
   บันทึกรายละเอียดข้อความของคำถามแต่ละข้อ
========================================================= */
if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && (string) ($_POST['action'] ?? '') === 'save_question_details'
) {
    header('Content-Type: application/json; charset=utf-8');

    $field = trim((string) ($_POST['field'] ?? ''));
    $title = trim((string) ($_POST['title'] ?? ''));
    $subtitle = trim((string) ($_POST['subtitle'] ?? ''));
    $postedOptions = json_decode((string) ($_POST['options'] ?? ''), true);

    if (!isset($defaultAdlItems[$field])) {
        echo json_encode([
            'ok' => false,
            'message' => 'ไม่พบข้อคำถามที่ต้องการแก้ไข'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if ($title === '') {
        echo json_encode([
            'ok' => false,
            'message' => 'กรุณากรอกชื่อข้อ'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if (!is_array($postedOptions)) {
        echo json_encode([
            'ok' => false,
            'message' => 'ข้อมูลตัวเลือกไม่ถูกต้อง'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $cleanOptions = [];

    foreach ($defaultAdlItems[$field]['options'] as $score => $defaultText) {
        $scoreKey = (string) $score;
        $optionText = trim((string) ($postedOptions[$scoreKey] ?? ''));

        if ($optionText === '') {
            echo json_encode([
                'ok' => false,
                'message' => 'กรุณากรอกรายละเอียดตัวเลือกคะแนน ' . $score . ' ให้ครบ'
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $cleanOptions[$scoreKey] = $optionText;
    }

    $optionsJson = json_encode(
        $cleanOptions,
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
    );

    $stmt = mysqli_prepare(
        $conn,
        "INSERT INTO adl_question_config
            (field_key,title,subtitle,options_json,updated_by,updated_at)
         VALUES (?,?,?,?,?,NOW())
         ON DUPLICATE KEY UPDATE
            title=VALUES(title),
            subtitle=VALUES(subtitle),
            options_json=VALUES(options_json),
            updated_by=VALUES(updated_by),
            updated_at=NOW()"
    );

    if (!$stmt) {
        echo json_encode([
            'ok' => false,
            'message' => 'ไม่สามารถเตรียมคำสั่งบันทึกรายละเอียดได้'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    mysqli_stmt_bind_param(
        $stmt,
        'ssssi',
        $field,
        $title,
        $subtitle,
        $optionsJson,
        $doctorId
    );

    $saved = mysqli_stmt_execute($stmt);
    $saveError = mysqli_stmt_error($stmt);
    mysqli_stmt_close($stmt);

    if (!$saved) {
        echo json_encode([
            'ok' => false,
            'message' => 'บันทึกรายละเอียดไม่สำเร็จ: ' . $saveError
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    echo json_encode([
        'ok' => true,
        'message' => 'บันทึกรายละเอียดข้อนี้เรียบร้อยแล้ว',
        'field' => $field,
        'title' => $title,
        'subtitle' => $subtitle,
        'options' => $cleanOptions
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

/* =========================================================
   บันทึกเฉพาะข้อที่กำลังแก้ไข
========================================================= */
if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && (string) ($_POST['action'] ?? '') === 'save_single_adl_field'
) {
    header('Content-Type: application/json; charset=utf-8');

    $adlId = (int) ($_POST['adl_id'] ?? 0);
    $field = trim((string) ($_POST['field'] ?? ''));
    $rawValue = (string) ($_POST['value'] ?? '');

    if ($adlId <= 0) {
        echo json_encode(['ok' => false, 'message' => 'ไม่พบรายการ ADL ที่ต้องการแก้ไข'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $ownerStmt = mysqli_prepare(
        $conn,
        "SELECT adl_id FROM adl_assessment
         WHERE adl_id=? AND doctor_user_id=? LIMIT 1"
    );

    if (!$ownerStmt) {
        echo json_encode(['ok' => false, 'message' => 'ไม่สามารถตรวจสอบสิทธิ์การแก้ไขได้'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    mysqli_stmt_bind_param($ownerStmt, 'ii', $adlId, $doctorId);
    mysqli_stmt_execute($ownerStmt);
    $owned = (bool) mysqli_fetch_row(mysqli_stmt_get_result($ownerStmt));
    mysqli_stmt_close($ownerStmt);

    if (!$owned) {
        echo json_encode(['ok' => false, 'message' => 'ไม่มีสิทธิ์แก้ไขรายการนี้'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    /* 10 ข้อที่มีคะแนน */
    if (array_key_exists($field, $rules)) {
        $value = (int) $rawValue;

        if (!in_array($value, $rules[$field], true)) {
            echo json_encode(['ok' => false, 'message' => 'ค่าคะแนนไม่ถูกต้อง'], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $sql = "UPDATE adl_assessment SET `$field`=? WHERE adl_id=? AND doctor_user_id=?";
        $stmt = mysqli_prepare($conn, $sql);

        if (!$stmt) {
            echo json_encode(['ok' => false, 'message' => 'ไม่สามารถเตรียมคำสั่งบันทึกได้'], JSON_UNESCAPED_UNICODE);
            exit;
        }

        mysqli_stmt_bind_param($stmt, 'iii', $value, $adlId, $doctorId);
        $saved = mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        if (!$saved) {
            echo json_encode(['ok' => false, 'message' => 'บันทึกข้อนี้ไม่สำเร็จ'], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $scoreStmt = mysqli_prepare(
            $conn,
            "SELECT feeding,grooming,transfer,toilet_use,mobility,dressing,stairs,bathing,bowels,bladder
             FROM adl_assessment
             WHERE adl_id=? AND doctor_user_id=? LIMIT 1"
        );
        mysqli_stmt_bind_param($scoreStmt, 'ii', $adlId, $doctorId);
        mysqli_stmt_execute($scoreStmt);
        $scoreRow = mysqli_fetch_assoc(mysqli_stmt_get_result($scoreStmt));
        mysqli_stmt_close($scoreStmt);

        $total = 0;
        foreach (array_keys($rules) as $scoreField) {
            $total += (int) ($scoreRow[$scoreField] ?? 0);
        }

        $totalStmt = mysqli_prepare(
            $conn,
            "UPDATE adl_assessment SET total_score=? WHERE adl_id=? AND doctor_user_id=?"
        );
        mysqli_stmt_bind_param($totalStmt, 'iii', $total, $adlId, $doctorId);
        mysqli_stmt_execute($totalStmt);
        mysqli_stmt_close($totalStmt);

        echo json_encode([
            'ok' => true,
            'message' => 'บันทึกข้อนี้เรียบร้อยแล้ว',
            'total' => $total
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    /* 3 ข้อเพิ่มเติม */
    $extraRules = [
        'regular_caregiver' => $caregiverOptions,
        'welfare_status' => $welfareOptions,
        'club_membership' => $clubOptions,
    ];

    if (array_key_exists($field, $extraRules)) {
        $value = trim($rawValue);

        if (!in_array($value, $extraRules[$field], true)) {
            echo json_encode(['ok' => false, 'message' => 'คำตอบไม่ถูกต้อง'], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $sql = "UPDATE adl_assessment SET `$field`=? WHERE adl_id=? AND doctor_user_id=?";
        $stmt = mysqli_prepare($conn, $sql);

        if (!$stmt) {
            echo json_encode(['ok' => false, 'message' => 'ไม่สามารถเตรียมคำสั่งบันทึกได้'], JSON_UNESCAPED_UNICODE);
            exit;
        }

        mysqli_stmt_bind_param($stmt, 'sii', $value, $adlId, $doctorId);
        $saved = mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        echo json_encode([
            'ok' => $saved,
            'message' => $saved ? 'บันทึกข้อนี้เรียบร้อยแล้ว' : 'บันทึกข้อนี้ไม่สำเร็จ'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    echo json_encode(['ok' => false, 'message' => 'ไม่พบหัวข้อที่ต้องการแก้ไข'], JSON_UNESCAPED_UNICODE);
    exit;
}


/* =========================================================
   ลบประวัติการประเมิน ADL
   - ลบได้เฉพาะรายการที่หมอคนที่ล็อกอินเป็นผู้ประเมิน
========================================================= */
if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && (string) ($_POST['action'] ?? '') === 'delete_adl'
) {
    $deleteAdlId = (int) ($_POST['adl_id'] ?? 0);

    if ($deleteAdlId <= 0) {
        $error = 'ไม่พบรายการ ADL ที่ต้องการลบ';
    } else {
        $deleteStmt = mysqli_prepare(
            $conn,
            "DELETE FROM adl_assessment
             WHERE adl_id=? AND doctor_user_id=?
             LIMIT 1"
        );

        if (!$deleteStmt) {
            $error = 'ไม่สามารถเตรียมคำสั่งลบได้: ' . mysqli_error($conn);
        } else {
            mysqli_stmt_bind_param($deleteStmt, 'ii', $deleteAdlId, $doctorId);

            if (mysqli_stmt_execute($deleteStmt)) {
                $deletedRows = mysqli_stmt_affected_rows($deleteStmt);
                mysqli_stmt_close($deleteStmt);

                if ($deletedRows > 0) {
                    header('Location: adl.php?deleted=1#adlHistory');
                    exit;
                }

                $error = 'ไม่พบรายการที่ต้องการลบ หรือคุณไม่มีสิทธิ์ลบรายการนี้';
            } else {
                $error = 'ลบข้อมูลไม่สำเร็จ: ' . mysqli_stmt_error($deleteStmt);
                mysqli_stmt_close($deleteStmt);
            }
        }
    }
}

/* =========================================================
   โหลดข้อมูลเดิมสำหรับโหมดแก้ไข
========================================================= */
$editId = (int) ($_GET['edit'] ?? $_POST['adl_id'] ?? 0);
$editRecord = null;

if ($editId > 0 && $error === '') {
    $editStmt = mysqli_prepare(
        $conn,
        "SELECT *
         FROM adl_assessment
         WHERE adl_id=? AND doctor_user_id=?
         LIMIT 1"
    );

    if ($editStmt) {
        mysqli_stmt_bind_param($editStmt, 'ii', $editId, $doctorId);
        mysqli_stmt_execute($editStmt);
        $editRecord = mysqli_fetch_assoc(mysqli_stmt_get_result($editStmt));
        mysqli_stmt_close($editStmt);

        if (!$editRecord) {
            $error = 'ไม่พบรายการ ADL ที่ต้องการแก้ไข หรือคุณไม่มีสิทธิ์แก้ไขรายการนี้';
            $editId = 0;
        }
    }
}

/* เติมค่าเดิมเข้าแบบฟอร์มเมื่อเปิดโหมดแก้ไข */
if ($editRecord && $_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_POST = [
        'adl_id' => $editRecord['adl_id'],
        'patient_id' => $editRecord['patient_id'],
        'assessment_date' => $editRecord['assessment_date'],
        'feeding' => $editRecord['feeding'],
        'grooming' => $editRecord['grooming'],
        'transfer' => $editRecord['transfer'],
        'toilet_use' => $editRecord['toilet_use'],
        'mobility' => $editRecord['mobility'],
        'dressing' => $editRecord['dressing'],
        'stairs' => $editRecord['stairs'],
        'bathing' => $editRecord['bathing'],
        'bowels' => $editRecord['bowels'],
        'bladder' => $editRecord['bladder'],
        'regular_caregiver' => $editRecord['regular_caregiver'],
        'welfare_status' => $editRecord['welfare_status'],
        'club_membership' => $editRecord['club_membership'],
        'note' => $editRecord['note'],
    ];
}

if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && (string) ($_POST['action'] ?? '') !== 'add_patient'
    && $error === ''
) {
    $patientId = (int) ($_POST['patient_id'] ?? 0);
    $date = trim((string) ($_POST['assessment_date'] ?? date('Y-m-d')));
    $note = trim((string) ($_POST['note'] ?? ''));
    $regularCaregiver = trim((string) ($_POST['regular_caregiver'] ?? ''));
    $welfare = trim((string) ($_POST['welfare_status'] ?? ''));
    $club = trim((string) ($_POST['club_membership'] ?? ''));

    $check = mysqli_prepare($conn, "SELECT Patient_id FROM patient WHERE Patient_id=? LIMIT 1");
    $validPatient = false;
    if ($check) {
        mysqli_stmt_bind_param($check, 'i', $patientId);
        mysqli_stmt_execute($check);
        $validPatient = (bool) mysqli_fetch_row(mysqli_stmt_get_result($check));
        mysqli_stmt_close($check);
    }

    $vals = [];
    $valid = true;
    foreach ($rules as $key => $allowed) {
        if (!isset($_POST[$key]) || $_POST[$key] === '') {
            $valid = false;
            break;
        }
        $value = (int) $_POST[$key];
        if (!in_array($value, $allowed, true)) {
            $valid = false;
            break;
        }
        $vals[$key] = $value;
    }

    if ($patientId <= 0 || !$validPatient) {
        $error = 'ไม่พบข้อมูลผู้สูงอายุที่เลือก';
    } elseif (!$valid) {
        $error = 'กรุณาประเมิน ADL ให้ครบทั้ง 10 หัวข้อ';
    } else {
        $total = array_sum($vals);

        // ส่งผลคะแนนต่อให้แคร์กิฟเวอร์ที่ถูกมอบหมายอยู่ในขณะนั้น
        $assignedCaregiverId = null;
        $assignmentTable = mysqli_query($conn, "SHOW TABLES LIKE 'patient_caregiver_assignment'");
        if ($assignmentTable && mysqli_num_rows($assignmentTable) > 0) {
            $handoffStmt = mysqli_prepare(
                $conn,
                "SELECT caregiver_user_id FROM patient_caregiver_assignment WHERE patient_id=? AND care_status='กำลังดูแล' LIMIT 1"
            );
            if ($handoffStmt) {
                mysqli_stmt_bind_param($handoffStmt, 'i', $patientId);
                mysqli_stmt_execute($handoffStmt);
                $handoffRow = mysqli_fetch_assoc(mysqli_stmt_get_result($handoffStmt));
                mysqli_stmt_close($handoffStmt);
                if ($handoffRow) {
                    $assignedCaregiverId = (int) $handoffRow['caregiver_user_id'];
                }
            }
        }
        $handoffStatus = $assignedCaregiverId ? 'รอแคร์กิฟเวอร์ประเมินต่อ' : 'รอมอบหมายแคร์กิฟเวอร์';
        $regularCaregiver = '';
        $welfare = '';
        $club = '';

        $postedAdlId = (int) ($_POST['adl_id'] ?? 0);

        if ($postedAdlId > 0) {
            /* แก้ไขรายการเดิมของหมอคนที่ล็อกอินเท่านั้น */
            $sql = "UPDATE adl_assessment SET
                        patient_id=?,
                        assessment_date=?,
                        feeding=?,
                        grooming=?,
                        transfer=?,
                        toilet_use=?,
                        mobility=?,
                        dressing=?,
                        stairs=?,
                        bathing=?,
                        bowels=?,
                        bladder=?,
                        total_score=?,
                        caregiver_user_id=?,
                        handoff_status=?,
                        regular_caregiver=NULL,
                        welfare_status=NULL,
                        club_membership=NULL,
                        caregiver_completed_at=NULL,
                        note=?
                    WHERE adl_id=? AND doctor_user_id=?";

            $stmt = mysqli_prepare($conn, $sql);

            if ($stmt) {
                mysqli_stmt_bind_param(
                    $stmt,
                    'isiiiiiiiiiiiissii',
                    $patientId,
                    $date,
                    $vals['feeding'],
                    $vals['grooming'],
                    $vals['transfer'],
                    $vals['toilet_use'],
                    $vals['mobility'],
                    $vals['dressing'],
                    $vals['stairs'],
                    $vals['bathing'],
                    $vals['bowels'],
                    $vals['bladder'],
                    $total,
                    $assignedCaregiverId,
                    $handoffStatus,
                    $note,
                    $postedAdlId,
                    $doctorId
                );

                if (mysqli_stmt_execute($stmt)) {
                    $message = 'บันทึกผลการประเมินครั้งที่ 1 โดยหมอเรียบร้อยแล้ว คะแนนรวม ' . $total . '/20';
                    $_POST = [];
                    $editId = 0;
                    $editRecord = null;
                } else {
                    $error = 'แก้ไขข้อมูลไม่สำเร็จ: ' . mysqli_stmt_error($stmt);
                }

                mysqli_stmt_close($stmt);
            } else {
                $error = 'ไม่สามารถเตรียมคำสั่งแก้ไขได้: ' . mysqli_error($conn);
            }
        } else {
            /* บันทึกเวลาจริงขณะประเมินเป็นเวลาไทย ไม่พึ่ง timezone ของ MySQL */
            $savedAt = (new DateTimeImmutable('now', new DateTimeZone('Asia/Bangkok')))->format('Y-m-d H:i:s');
            $sql = "INSERT INTO adl_assessment (
                patient_id,doctor_user_id,caregiver_user_id,assessment_date,feeding,grooming,transfer,toilet_use,mobility,dressing,stairs,bathing,bowels,bladder,total_score,
                handoff_status,note,created_at
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

            $stmt = mysqli_prepare($conn, $sql);

            if ($stmt) {
                mysqli_stmt_bind_param(
                    $stmt,
                    'iiisiiiiiiiiiiisss',
                    $patientId,
                    $doctorId,
                    $assignedCaregiverId,
                    $date,
                    $vals['feeding'],
                    $vals['grooming'],
                    $vals['transfer'],
                    $vals['toilet_use'],
                    $vals['mobility'],
                    $vals['dressing'],
                    $vals['stairs'],
                    $vals['bathing'],
                    $vals['bowels'],
                    $vals['bladder'],
                    $total,
                    $handoffStatus,
                    $note,
                    $savedAt
                );

                if (mysqli_stmt_execute($stmt)) {
                    $message = 'บันทึกผลการประเมินครั้งที่ 1 โดยหมอเรียบร้อยแล้ว คะแนนรวม ' . $total . '/20';
                    $_POST = [];
                } else {
                    $error = 'บันทึกไม่สำเร็จ: ' . mysqli_stmt_error($stmt);
                }

                mysqli_stmt_close($stmt);
            } else {
                $error = 'ไม่สามารถเตรียมคำสั่งบันทึกได้: ' . mysqli_error($conn);
            }
        }
    }
}

if (
    isset($_GET['deleted'])
    && (string) $_GET['deleted'] === '1'
    && $message === ''
    && $error === ''
) {
    $message = 'ลบประวัติการประเมิน ADL เรียบร้อยแล้ว';
}

function adlGroup(int $score): string
{
    if ($score > 20)
        return 'ข้อมูล ADL รูปแบบเดิม';
    if ($score >= 12)
        return '1B1280-Special PP (กลุ่มติดสังคม)';
    if ($score >= 5)
        return '1B1281-Special PP (กลุ่มติดบ้าน)';
    return '1B1282-Special PP (กลุ่มติดเตียง)';
}

function checkedPost(string $name, string $value): string
{
    return ((string) ($_POST[$name] ?? '') === $value) ? 'checked' : '';
}

function adlThaiDate(?string $value): string
{
    if (!$value) return '-';
    $ts = strtotime($value);
    if (!$ts) return (string) $value;
    $months = ['ม.ค.','ก.พ.','มี.ค.','เม.ย.','พ.ค.','มิ.ย.','ก.ค.','ส.ค.','ก.ย.','ต.ค.','พ.ย.','ธ.ค.'];
    return date('j', $ts) . ' ' . $months[(int) date('n', $ts) - 1] . ' ' . (date('Y', $ts) + 543);
}

function adlThaiDateTime(?string $value): string
{
    if (!$value) return '-';
    $ts = strtotime($value);
    if (!$ts) return (string) $value;
    return adlThaiDate(date('Y-m-d', $ts)) . ' • ' . date('H:i', $ts) . ' น.';
}

$patientMap = [];
foreach ($patients as $patient) {
    $patientMap[(string) $patient['Patient_id']] = [
        'fullname' => (string) ($patient['Fullname'] ?? ''),
        'age' => (string) ($patient['Age'] ?? ''),
        'address' => (string) ($patient['Address'] ?? ''),
        'phone' => (string) ($patient['Phone'] ?? ''),
        'disease' => (string) ($patient['Disease'] ?? ''),
    ];
}
$selectedPatientId = (string) ($_POST['patient_id'] ?? ($_GET['patient_id'] ?? ($_GET['new_patient'] ?? '')));
$selectedPatient = $patientMap[$selectedPatientId] ?? null;

function adlOptionText(array $adlItems, string $field, $score): string
{
    if (!isset($adlItems[$field]['options'])) return '-';
    $scoreKey = (string) $score;
    foreach ($adlItems[$field]['options'] as $optionScore => $optionText) {
        if ((string) $optionScore === $scoreKey) return (string) $optionText;
    }
    return '-';
}

$adlHistoryMap = [];
$historyRes = mysqli_query($conn, "SELECT a.*, COALESCE(u.display_name, u.username, '-') AS doctor_name
    FROM adl_assessment a
    LEFT JOIN users u ON u.user_id = a.doctor_user_id
    ORDER BY a.patient_id ASC, a.assessment_date ASC, a.created_at ASC, a.adl_id ASC");
if ($historyRes) {
    while ($historyRow = mysqli_fetch_assoc($historyRes)) {
        $patientKey = (string) ($historyRow['patient_id'] ?? '');
        if ($patientKey === '') continue;
        $adlHistoryMap[$patientKey][] = $historyRow;
    }
}
if ($selectedPatientId === '' || !$selectedPatient) {
    header('Location: adl.php');
    exit;
}
$selectedHistoryRows = $adlHistoryMap[$selectedPatientId] ?? [];
$historyPerPage = 5;
$historyTotal = count($selectedHistoryRows);
$historyTotalPages = max(1, (int) ceil($historyTotal / $historyPerPage));
$historyPage = max(1, (int) ($_GET['page'] ?? 1));
if ($historyPage > $historyTotalPages) $historyPage = $historyTotalPages;
$historyOffset = ($historyPage - 1) * $historyPerPage;
$historyPageRows = array_slice($selectedHistoryRows, $historyOffset, $historyPerPage);
?>
<!doctype html>
<html lang="th">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>รายละเอียดการประเมิน ADL | <?= e(appName()) ?></title>
<?php renderPastelTheme(); ?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Thai:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<style>
.history-only-page{padding-bottom:40px}
.history-only-shell{display:grid;gap:16px}
.history-back{display:flex;justify-content:flex-start}
.history-back a{display:inline-flex;align-items:center;justify-content:center;min-height:44px;padding:0 18px;border-radius:14px;background:#fff;border:1px solid #cfe4e1;color:#286465;text-decoration:none;font-size:13px;font-weight:900;box-shadow:0 8px 18px rgba(36,108,115,.06)}
.history-card{border:1px solid #d8ebe8;border-radius:26px;background:#fff;overflow:hidden;box-shadow:0 14px 34px rgba(36,108,115,.06)}
.history-card-head{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:18px 22px;background:linear-gradient(135deg,#59bfc0,#49a8aa);color:#fff}
.history-card-head h1{margin:0;font-size:21px;color:#fff}
.history-count{display:inline-flex;align-items:center;justify-content:center;min-width:82px;padding:8px 13px;border-radius:999px;background:rgba(255,255,255,.18);border:1px solid rgba(255,255,255,.28);font-size:12px;font-weight:900}
.history-body{padding:18px}
.history-empty{padding:36px 16px;border:1px dashed #d9e8e5;border-radius:18px;background:#fbfefe;text-align:center;color:#718986}
.history-list{display:grid;gap:14px}
.assessment{border:1px solid #dcebe8;border-radius:20px;background:linear-gradient(180deg,#fff,#fbfefe);overflow:hidden}
.assessment summary{list-style:none;display:flex;align-items:center;justify-content:space-between;gap:14px;padding:17px 18px;cursor:pointer}
.assessment summary::-webkit-details-marker{display:none}
.assessment-title{font-size:21px;font-weight:900;color:#204f53}
.assessment-meta{margin-top:7px;color:#788f8b;font-size:14px;line-height:1.6}
.score{display:inline-flex;align-items:center;justify-content:center;min-width:96px;min-height:50px;padding:9px 15px;border-radius:14px;background:#eaf8f5;color:#215e58;font-size:24px;font-weight:900}
.assessment-detail{padding:0 18px 18px}
.detail-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;padding-top:16px;border-top:1px dashed #d9e8e5}
.detail-field{padding:16px 16px;border:1px solid #e3efed;border-radius:13px;background:#fff}
.detail-field small{display:block;margin-bottom:6px;color:#6f8581;font-size:14px;font-weight:700}
.detail-field strong{display:block;color:#294f53;font-size:16px;line-height:1.6}
.detail-field p{margin:8px 0 0;color:#536d68;font-size:15px;line-height:1.65}.detail-score-line{display:flex;align-items:center;justify-content:space-between;gap:14px}.detail-score-line small{margin-bottom:0!important}.detail-score-line strong{white-space:nowrap;color:#1f5b60!important}.score-line-field p{margin-top:8px!important}
.detail-field.full{grid-column:1/-1}
.history-pagination{display:flex;align-items:center;justify-content:center;gap:8px;flex-wrap:wrap;margin-top:18px}.history-page-link,.history-page-current,.history-page-ellipsis{display:inline-flex;align-items:center;justify-content:center;min-width:38px;height:38px;padding:0 10px;border-radius:11px;font-size:13px;font-weight:900;text-decoration:none}.history-page-link{background:#fff;border:1px solid #d6e8e5;color:#2d6466}.history-page-link:hover{background:#f2faf9}.history-page-current{background:linear-gradient(135deg,#59bfc0,#49aaac);border:1px solid #49aaac;color:#fff;box-shadow:0 8px 18px rgba(88,191,192,.18)}.history-page-ellipsis{color:#78908b}.history-page-link.disabled{opacity:.4;pointer-events:none}
@media(max-width:760px){.history-card-head,.assessment summary{align-items:flex-start;flex-direction:column}.detail-grid{grid-template-columns:1fr}.detail-field.full{grid-column:auto}}
</style>
</head>
<body class="role-page history-only-page">
<?php renderSidebar(); ?>
<main class="main">
<?php renderUserTopbar(); ?>

<div class="history-only-shell">
    <div class="history-back">
        <a href="adl.php">ย้อนกลับ</a>
    </div>

    <section class="history-card">
        <div class="history-card-head">
            <h1>รายละเอียดการประเมิน</h1>
        </div>
        <div class="history-body">
            <?php if (!$selectedHistoryRows): ?>
                <div class="history-empty">ยังไม่มีผลการประเมินของผู้สูงอายุรายนี้</div>
            <?php else: ?>
                <div class="history-list">
                    <?php foreach ($historyPageRows as $historyIndex => $historyRow): ?>
                        <?php $historyNumber = $historyOffset + $historyIndex + 1; ?>
                        <details class="assessment" <?= $historyIndex === 0 ? 'open' : '' ?>>
                            <summary>
                                <div>
                                    <div class="assessment-title">การประเมินครั้งที่ <?= (int)$historyNumber ?></div>
                                    <div class="assessment-meta">
                                        วันที่ประเมิน <?= e(adlThaiDate($historyRow['assessment_date'] ?? '')) ?>
                                        • ผู้ประเมิน <?= e($historyRow['doctor_name'] ?? '-') ?>
                                    </div>
                                </div>
                                <div class="score"><?= (int)($historyRow['total_score'] ?? 0) ?>/20</div>
                            </summary>

                            <div class="assessment-detail">
                                <div class="detail-grid">
                                    <?php foreach ($adlItems as $historyField => $historyItem): ?>
                                        <div class="detail-field score-line-field">
                                            <div class="detail-score-line">
                                                <small><?= e($historyItem['title']) ?></small>
                                                <strong><?= (int)($historyRow[$historyField] ?? 0) ?> คะแนน</strong>
                                            </div>
                                            <p><?= e(adlOptionText($adlItems, $historyField, (string)($historyRow[$historyField] ?? ''))) ?></p>
                                        </div>
                                    <?php endforeach; ?>

                                    <div class="detail-field">
                                        <small>ผู้ดูแลประจำ</small>
                                        <strong><?= e($historyRow['regular_caregiver'] ?? '-') ?></strong>
                                    </div>
                                    <div class="detail-field">
                                        <small>สิทธิ/สวัสดิการ</small>
                                        <strong><?= e($historyRow['welfare_status'] ?? '-') ?></strong>
                                    </div>
                                    <div class="detail-field">
                                        <small>สมาชิกชมรม</small>
                                        <strong><?= e($historyRow['club_membership'] ?? '-') ?></strong>
                                    </div>
                                    <div class="detail-field">
                                        <small>บันทึกเมื่อ</small>
                                        <strong><?= e(adlThaiDateTime($historyRow['created_at'] ?? '')) ?></strong>
                                    </div>
                                    <div class="detail-field full">
                                        <small>หมายเหตุ</small>
                                        <strong><?= nl2br(e(trim((string)($historyRow['note'] ?? '')) !== '' ? $historyRow['note'] : '-')) ?></strong>
                                    </div>
                                </div>
                            </div>
                        </details>
                    <?php endforeach; ?>
                </div>

                <?php if ($historyTotalPages > 1): ?>
                    <nav class="history-pagination" aria-label="หน้าประวัติการประเมิน">
                        <?php
                        $baseHistoryUrl = 'adl_history.php?patient_id=' . urlencode((string)$selectedPatientId) . '&page=';
                        $startPage = max(1, $historyPage - 2);
                        $endPage = min($historyTotalPages, $historyPage + 2);
                        ?>
                        <a class="history-page-link <?= $historyPage <= 1 ? 'disabled' : '' ?>" href="<?= e($baseHistoryUrl . max(1, $historyPage - 1)) ?>">&lt;</a>

                        <?php if ($startPage > 1): ?>
                            <a class="history-page-link" href="<?= e($baseHistoryUrl . '1') ?>">1</a>
                            <?php if ($startPage > 2): ?><span class="history-page-ellipsis">...</span><?php endif; ?>
                        <?php endif; ?>

                        <?php for ($pageNo = $startPage; $pageNo <= $endPage; $pageNo++): ?>
                            <?php if ($pageNo === $historyPage): ?>
                                <span class="history-page-current"><?= $pageNo ?></span>
                            <?php else: ?>
                                <a class="history-page-link" href="<?= e($baseHistoryUrl . $pageNo) ?>"><?= $pageNo ?></a>
                            <?php endif; ?>
                        <?php endfor; ?>

                        <?php if ($endPage < $historyTotalPages): ?>
                            <?php if ($endPage < $historyTotalPages - 1): ?><span class="history-page-ellipsis">...</span><?php endif; ?>
                            <a class="history-page-link" href="<?= e($baseHistoryUrl . $historyTotalPages) ?>"><?= $historyTotalPages ?></a>
                        <?php endif; ?>

                        <a class="history-page-link <?= $historyPage >= $historyTotalPages ? 'disabled' : '' ?>" href="<?= e($baseHistoryUrl . min($historyTotalPages, $historyPage + 1)) ?>">&gt;</a>
                    </nav>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </section>
</div>
</main>
</body>
</html>
