<?php
require_once __DIR__ . '/director_tools.php';
$metrics = dirPatientMetrics($conn);
$reports = dirBuildReportRows($conn);
$directorMonth = trim((string)($_GET['month'] ?? ''));
if ($directorMonth !== '' && !preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $directorMonth)) $directorMonth = '';
$directorMonthNames=[1=>'มกราคม',2=>'กุมภาพันธ์',3=>'มีนาคม',4=>'เมษายน',5=>'พฤษภาคม',6=>'มิถุนายน',7=>'กรกฎาคม',8=>'สิงหาคม',9=>'กันยายน',10=>'ตุลาคม',11=>'พฤศจิกายน',12=>'ธันวาคม'];
$directorMonthLabel='ทุกเดือน';
$filteredReports=$reports;
if ($directorMonth!=='') {
    $directorMonthLabel=($directorMonthNames[(int)substr($directorMonth,5,2)]??'').' '.((int)substr($directorMonth,0,4)+543);
    $filteredReports=array_values(array_filter($reports,function($r) use ($directorMonth){
        $d=(string)($r['report_date']??''); return substr($d,0,7)===$directorMonth;
    }));
}
$wc = dirWorkflowCounts($filteredReports);
$recent = array_slice($filteredReports,0,5);
$groups = $metrics['adl_groups'] ?? ['ติดสังคม'=>0,'ติดบ้าน'=>0,'ติดเตียง'=>0];
$totalAdl = max(1,(int)($groups['ติดสังคม']??0)+(int)($groups['ติดบ้าน']??0)+(int)($groups['ติดเตียง']??0));
?>
<!doctype html><html lang="th"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>ภาพรวมผู้บริหาร | <?= e(appName()) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Thai:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../assets/style.css"><link rel="stylesheet" href="../assets/role_pages.css"><link rel="stylesheet" href="../assets/director_portal.css?v=20260927-12">
<link rel="stylesheet" href="../assets/inspired_layout.css?v=20260929-1"><link rel="stylesheet" href="../assets/unified_home_report.css?v=20260929-1">
<style>
.director-dashboard-unified{display:grid;gap:18px;max-width:1460px!important;margin:0 auto!important;padding:0 28px 40px!important}
body.director-v2 .deeden-home-heading{margin-top:20px!important;margin-bottom:26px!important}
body.director-v2 .deeden-home-heading h1{font-size:38px!important;line-height:1.15!important}
body.director-v2 .dir-top-row{margin-bottom:14px!important}
.dir-top-row{display:flex;align-items:center;justify-content:flex-start;gap:18px;margin:0 0 2px}
.dir-month-filter{display:flex;justify-content:flex-start;position:relative;z-index:40;margin:0}
.dir-month-picker{position:relative;width:263px}.dir-month-trigger{width:100%;height:44px;padding:0 14px;border:1px solid #cfe6e3;border-radius:13px;background:#fff;display:flex;align-items:center;justify-content:space-between;color:#285d60;font:inherit;font-weight:900;cursor:pointer}
.dir-month-pop{display:none;position:absolute;top:0;right:calc(100% + 10px);width:292px;padding:12px;border:1px solid #d4e8e5;border-radius:14px;background:#fff;box-shadow:0 14px 30px rgba(36,108,115,.12);z-index:90}.dir-month-picker.open .dir-month-pop{display:block}
.dir-month-yearbar{display:grid;grid-template-columns:36px 1fr 36px;gap:6px;align-items:center}.dir-month-nav{height:34px;border:0;border-radius:9px;background:#f2f8f7;color:#2d6467;font-size:18px;font-weight:900}.dir-month-year{text-align:center;font-weight:900}.dir-month-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-top:8px}.dir-month-opt{height:38px;border:0;border-radius:9px;background:#fff;color:#285d60;font-weight:800;cursor:pointer}.dir-month-opt:hover{background:#eef8f7}.dir-month-opt.sel{background:#55bfc0;color:#fff}.dir-month-actions{display:flex;justify-content:space-between;margin-top:10px;padding-top:9px;border-top:1px solid #edf4f2}.dir-month-actions button{border:0;background:none;color:#2c777a;font-weight:900;cursor:pointer}
.dir-unified-stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:16px}.dir-u-card{position:relative;min-height:126px;padding:20px 22px 18px;border:1px solid #d6ebe7;border-radius:22px;background:#fff;box-shadow:0 12px 28px rgba(36,108,115,.07);display:flex;flex-direction:column;justify-content:center;overflow:hidden}.dir-u-card:before{content:'';position:absolute;left:0;top:0;right:0;height:4px;background:#55aee2}.dir-u-card.green:before{background:#5bb99d}.dir-u-card.rose:before{background:#e78391}.dir-u-card.amber:before{background:#e5bc56}.dir-u-card .label{font-size:13px;color:#6f878b;font-weight:800}.dir-u-card .value{margin-top:14px;font-size:38px;line-height:1;font-weight:900;color:#214f54}.dir-u-card .unit{margin-top:6px;font-size:11px;color:#8ca2a4;font-weight:700}
.dir-unified-grid{display:grid;grid-template-columns:minmax(0,1.15fr) minmax(380px,.85fr);gap:20px}.dir-u-panel{overflow:hidden;border:1px solid #d6ebe7;border-radius:24px;background:#fff;box-shadow:0 14px 30px rgba(36,108,115,.07)}.dir-u-head{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:16px 18px;border-bottom:1px solid #e5f0ee;background:linear-gradient(180deg,#f8fdfd,#eef9f7)}.dir-u-head h2{margin:0;font-size:18px;color:#1f5459}.dir-u-head a{font-size:12px;color:#246c73;text-decoration:none;font-weight:900}.dir-u-body{padding:20px}
.dir-recent{display:grid;gap:10px}.dir-recent-row{display:grid;grid-template-columns:1fr 130px 120px;gap:12px;align-items:center;padding:13px 14px;border:1px solid #e2efed;border-radius:14px;background:#fbfefe}.dir-recent-row strong{display:block;color:#214f54}.dir-recent-row small{display:block;margin-top:4px;color:#819596}.dir-status{padding:7px 10px;border-radius:999px;text-align:center;background:#eef8f7;color:#276c66;font-weight:800;font-size:12px}
.dir-adl-layout{display:grid;grid-template-columns:170px 1fr;gap:20px;align-items:center}.dir-donut{position:relative;width:168px;height:168px;border-radius:50%;margin:auto}.dir-donut:after{content:'';position:absolute;inset:20px;border-radius:50%;background:#fff}.dir-donut-center{position:absolute;inset:0;z-index:2;display:flex;align-items:center;justify-content:center;flex-direction:column}.dir-donut-center strong{font-size:32px;color:#214f54}.dir-donut-center span{font-size:12px;color:#71888b;font-weight:800}.dir-legend{display:grid;gap:10px}.dir-leg{display:flex;justify-content:space-between;gap:10px;padding:10px 12px;border:1px solid #e5f0ee;border-radius:14px;background:#fbfefe}.dir-leg span{color:#214f54;font-weight:800}.dir-leg b{color:#246c73}
@media(max-width:1050px){.dir-unified-stats{grid-template-columns:repeat(2,minmax(0,1fr))}.dir-unified-grid{grid-template-columns:1fr}}@media(max-width:650px){.director-dashboard-unified{padding-left:16px!important;padding-right:16px!important}.dir-top-row{align-items:stretch;flex-direction:column;gap:12px}.dir-month-filter,.dir-month-picker{width:100%}.dir-unified-stats{grid-template-columns:1fr}.dir-adl-layout{grid-template-columns:1fr}.dir-month-pop{top:calc(100% + 8px);right:0}.dir-recent-row{grid-template-columns:1fr}}
</style>

</head><body class="role-page dashboard-page director-v2">
<?php renderSidebar(); ?>
<main class="main">
<?php renderUserTopbar(); ?>
<section class="deeden-home-heading"><h1>ภาพรวมข้อมูล</h1></section>
<section class="director-dashboard-v2 unified-home-page director-dashboard-unified">
  <div class="dir-top-row">
    <form class="dir-month-filter" method="get" id="directorMonthForm"><div class="dir-month-picker" id="dirMonthPicker"><input type="hidden" name="month" id="dirMonthValue" value="<?= dirH($directorMonth) ?>"><button type="button" class="dir-month-trigger" id="dirMonthTrigger"><span id="dirMonthText"><?= dirH($directorMonthLabel) ?></span><span>▦</span></button><div class="dir-month-pop"><div class="dir-month-yearbar"><button type="button" class="dir-month-nav" id="dirPrev">‹</button><div class="dir-month-year" id="dirYear"></div><button type="button" class="dir-month-nav" id="dirNext">›</button></div><div class="dir-month-grid" id="dirGrid"></div><div class="dir-month-actions"><button type="button" id="dirClear">ทุกเดือน</button><button type="button" id="dirThis">เดือนนี้</button></div></div></div></form>
  </div>

  <section class="dir-unified-stats">
    <article class="dir-u-card"><div class="label">รายงานทั้งหมด</div><div class="value"><?= number_format($wc['total']) ?></div><div class="unit">รายการ</div></article>
    <article class="dir-u-card amber"><div class="label">รอตรวจสอบ</div><div class="value"><?= number_format($wc['pending_review']) ?></div><div class="unit">รายการ</div></article>
    <article class="dir-u-card rose"><div class="label">รอลงนาม</div><div class="value"><?= number_format($wc['pending_sign']) ?></div><div class="unit">รายการ</div></article>
    <article class="dir-u-card green"><div class="label">ลงนามแล้ว</div><div class="value"><?= number_format($wc['signed']+$wc['approved']) ?></div><div class="unit">รายการ</div></article>
  </section>

  <section class="dir-unified-grid">
    <article class="dir-u-panel"><div class="dir-u-head"><h2>การดำเนินงานล่าสุด</h2><a href="director_signature_history.php">ดูทั้งหมด</a></div><div class="dir-u-body"><div class="dir-recent">
      <?php if(!$recent): ?><div class="dv2-empty">ยังไม่มีรายการในช่วงที่เลือก</div><?php else: foreach($recent as $r): $status=$r['approval_status']==='approved'||$r['approval_status']==='signed'?'ลงนามแล้ว':($r['review_status']==='reviewed'?'รอลงนาม':'รอตรวจสอบ'); ?>
      <div class="dir-recent-row"><div><strong><?= dirH($r['title']) ?></strong><small><?= dirH($r['patient_name']) ?></small></div><span><?= dirH(dirThaiDate($r['report_date'])) ?></span><span class="dir-status"><?= dirH($status) ?></span></div><?php endforeach; endif; ?>
    </div></div></article>
    <article class="dir-u-panel"><div class="dir-u-head"><h2>ภาพรวมผล ADL ล่าสุด</h2><a href="director_patients.php">ดูรายละเอียด</a></div><div class="dir-u-body"><div class="dir-adl-layout"><?php $social=(int)($groups['ติดสังคม']??0);$home=(int)($groups['ติดบ้าน']??0);$bed=(int)($groups['ติดเตียง']??0);$p1=$social/$totalAdl*100;$p2=$home/$totalAdl*100; ?><div class="dir-donut" style="background:conic-gradient(#20AFA6 0 <?=$p1?>%,#83d5d1 <?=$p1?>% <?=$p1+$p2?>%,#7dc7e6 <?=$p1+$p2?>% 100%)"><div class="dir-donut-center"><strong><?= number_format((int)$metrics['patients']) ?></strong><span>คน</span></div></div><div class="dir-legend"><div class="dir-leg"><span>ติดสังคม</span><b><?=$social?> คน</b></div><div class="dir-leg"><span>ติดบ้าน</span><b><?=$home?> คน</b></div><div class="dir-leg"><span>ติดเตียง</span><b><?=$bed?> คน</b></div></div></div></div></article>
  </section>
</section>
</main>
<script>(function(){const p=document.getElementById('dirMonthPicker'),f=document.getElementById('directorMonthForm'),v=document.getElementById('dirMonthValue'),t=document.getElementById('dirMonthText'),g=document.getElementById('dirGrid'),y=document.getElementById('dirYear'),names=['มกราคม','กุมภาพันธ์','มีนาคม','เมษายน','พฤษภาคม','มิถุนายน','กรกฎาคม','สิงหาคม','กันยายน','ตุลาคม','พฤศจิกายน','ธันวาคม'],now=new Date(),m=(v.value||'').match(/^(\d{4})-(\d{2})$/);let vy=m?+m[1]:now.getFullYear();function render(){y.textContent='พ.ศ. '+(vy+543);g.innerHTML='';names.forEach((n,i)=>{let b=document.createElement('button');b.type='button';b.className='dir-month-opt'+(m&&+m[1]===vy&&+m[2]===i+1?' sel':'');b.textContent=n;b.onclick=()=>{v.value=vy+'-'+String(i+1).padStart(2,'0');t.textContent=n+' '+(vy+543);f.submit()};g.appendChild(b)})}document.getElementById('dirMonthTrigger').onclick=()=>{p.classList.toggle('open');render()};document.getElementById('dirPrev').onclick=()=>{vy--;render()};document.getElementById('dirNext').onclick=()=>{vy++;render()};document.getElementById('dirClear').onclick=()=>{v.value='';f.submit()};document.getElementById('dirThis').onclick=()=>{v.value=now.getFullYear()+'-'+String(now.getMonth()+1).padStart(2,'0');f.submit()};document.addEventListener('click',e=>{if(!p.contains(e.target))p.classList.remove('open')})})();</script>
</body></html>