<?php
require_once __DIR__ . '/director_tools.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $key=(string)($_POST['report_key']??'');$action=(string)($_POST['action']??'');$reason=(string)($_POST['reason']??'');dirSaveWorkflowAction($conn,$key,$action,$reason);header('Location: director_assessments.php');exit;
}
$rows=dirBuildReportRows($conn);$rows=array_values(array_filter($rows,fn($r)=>($r['review_status']??'')==='reviewed' && !in_array(($r['approval_status']??'pending'),['approved'],true)));
?>
<!doctype html><html lang="th"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ลงนามอนุมัติ | <?=e(appName())?></title>
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Thai:wght@400;500;600;700;800;900&display=swap" rel="stylesheet"><link rel="stylesheet" href="../assets/style.css"><link rel="stylesheet" href="../assets/role_pages.css"><link rel="stylesheet" href="../assets/director_portal.css?v=20260927-12"></head>
<body class="role-page director-v2"><?php renderSidebar();renderUserTopbar();?><main class="director-main">
<div class="director-page-title"><h1>ลงนามอนุมัติ</h1></div>
<section class="director-panel"><div class="director-panel__head"><div><h2>รายงานที่ผ่านการตรวจสอบแล้ว</h2></div></div><div class="director-table-wrap"><table class="director-table"><thead><tr><th>เลขที่รายงาน</th><th>รายงาน / ผู้สูงอายุ</th><th>วันที่ส่ง</th><th>สถานะ</th><th>การดำเนินการ</th></tr></thead><tbody>
<?php if(!$rows):?><tr><td colspan="5"><div class="director-empty">ยังไม่มีรายงานที่รอลงนามอนุมัติ</div></td></tr><?php else:foreach($rows as $r):?>
<tr><td><strong><?=dirH(strtoupper(str_replace(':','-',$r['report_key'])))?></strong></td><td><strong><?=dirH($r['title'])?></strong><div class="director-note"><?=dirH($r['patient_name'])?> · <?=dirH($r['author'])?></div></td><td><?=dirH(dirThaiDate($r['report_date']))?></td><td><span class="director-status"><?=($r['approval_status']??'pending')==='signed'?'ลงนามแล้ว':'รอลงนาม'?></span></td><td>
<form method="post" style="display:flex;gap:6px;flex-wrap:wrap"><input type="hidden" name="report_key" value="<?=dirH($r['report_key'])?>"><button class="director-btn" name="action" value="sign">ลงนาม</button><button class="director-btn primary" name="action" value="approve">อนุมัติ</button><input class="director-search" style="min-width:180px;height:40px" name="reason" placeholder="เหตุผลกรณีส่งกลับ"><button class="director-btn danger" name="action" value="return">ส่งกลับแก้ไข</button></form>
</td></tr><?php endforeach;endif;?></tbody></table></div></section></main></body></html>
