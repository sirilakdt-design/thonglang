<?php
require_once __DIR__ . '/director_tools.php';

$perPage = 20;
$page = max(1, (int)($_GET['page'] ?? 1));

if($_SERVER['REQUEST_METHOD']==='POST'){
    dirSaveWorkflowAction($conn,(string)($_POST['report_key']??''),'review');
    $returnPage = max(1, (int)($_POST['page'] ?? 1));
    header('Location: director_visits.php?page=' . $returnPage);
    exit;
}

$rows=dirBuildReportRows($conn);
$rows=array_values(array_filter($rows,fn($r)=>($r['review_status']??'pending_review')!=='reviewed' || ($r['approval_status']??'')==='returned'));
$totalRows = count($rows);
$totalPages = max(1, (int)ceil($totalRows / $perPage));
if ($page > $totalPages) $page = $totalPages;
$offset = ($page - 1) * $perPage;
$pageRows = array_slice($rows, $offset, $perPage);
?>
<!doctype html><html lang="th"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ตรวจสอบรายงาน | <?=e(appName())?></title>
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Thai:wght@400;500;600;700;800;900&display=swap" rel="stylesheet"><link rel="stylesheet" href="../assets/style.css"><link rel="stylesheet" href="../assets/role_pages.css"><link rel="stylesheet" href="../assets/director_portal.css?v=20260927-12"></head>
<body class="role-page director-v2"><?php renderSidebar();renderUserTopbar();?><main class="director-main">
<div class="director-page-title"><h1>ตรวจสอบรายงาน</h1></div>
<section class="director-panel"><div class="director-panel__head"><div><h2>รายการรายงานที่รอตรวจสอบ</h2></div></div><div class="director-table-wrap">
<table class="director-table"><thead><tr><th>เลขที่รายงาน</th><th>ชื่อรายงาน / ผู้สูงอายุ</th><th>ผู้จัดทำ</th><th>วันที่ส่งรายงาน</th><th>สถานะ</th><th>การดำเนินการ</th></tr></thead><tbody>
<?php if(!$pageRows):?><tr><td colspan="6"><div class="director-empty">ไม่มีรายงานที่รอตรวจสอบ</div></td></tr><?php else:foreach($pageRows as $r):?>
<tr><td><strong><?=dirH(strtoupper(str_replace(':','-',$r['report_key'])))?></strong></td><td><strong><?=dirH($r['title'])?></strong><div class="director-note"><?=dirH($r['patient_name'])?></div></td><td><?=dirH($r['author'])?></td><td><?=dirH(dirThaiDate($r['report_date']))?></td><td><span class="director-status"><?=($r['approval_status']??'')==='returned'?'ส่งกลับแก้ไข':'รอตรวจสอบ'?></span><?php if(!empty($r['return_reason'])):?><div class="director-note"><?=dirH($r['return_reason'])?></div><?php endif;?></td><td><form method="post" style="display:inline"><input type="hidden" name="report_key" value="<?=dirH($r['report_key'])?>"><input type="hidden" name="page" value="<?=$page?>"><button class="director-btn primary" type="submit">ผ่านการตรวจสอบ</button></form></td></tr>
<?php endforeach;endif;?></tbody></table></div>
<?php if($totalPages > 1): ?>
<nav class="director-pagination" aria-label="แบ่งหน้า">
    <a class="page-nav <?= $page <= 1 ? 'disabled' : '' ?>" href="<?= $page > 1 ? 'director_visits.php?page='.($page-1) : '#' ?>" aria-label="หน้าก่อนหน้า">&lt;</a>
    <?php
    $items = [];
    if ($totalPages <= 7) {
        for ($i=1; $i<=$totalPages; $i++) $items[] = $i;
    } else {
        $items = [1];
        if ($page > 4) $items[] = '...';
        $start = max(2, $page - 1);
        $end = min($totalPages - 1, $page + 1);
        if ($page <= 4) $end = 5;
        if ($page >= $totalPages - 3) $start = $totalPages - 4;
        for ($i=$start; $i<=$end; $i++) $items[] = $i;
        if ($page < $totalPages - 3) $items[] = '...';
        $items[] = $totalPages;
    }
    foreach ($items as $item):
        if ($item === '...'): ?>
            <span class="page-ellipsis">...</span>
        <?php else: ?>
            <a class="page-number <?= $item === $page ? 'active' : '' ?>" href="director_visits.php?page=<?= $item ?>"><?= $item ?></a>
        <?php endif;
    endforeach; ?>
    <a class="page-nav <?= $page >= $totalPages ? 'disabled' : '' ?>" href="<?= $page < $totalPages ? 'director_visits.php?page='.($page+1) : '#' ?>" aria-label="หน้าถัดไป">&gt;</a>
</nav>
<?php endif; ?>
</section></main></body></html>
