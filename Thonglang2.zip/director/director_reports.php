<?php require_once __DIR__ . '/director_tools.php';$metrics=dirPatientMetrics($conn);$vm=dirVisitMetrics($conn,date('Y-m'));$am=dirAssessmentMetrics($conn);?>
<!doctype html><html lang="th"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>รายงานสรุป | <?=e(appName())?></title><link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Thai:wght@400;500;600;700;800;900&display=swap" rel="stylesheet"><link rel="stylesheet" href="../assets/style.css"><link rel="stylesheet" href="../assets/role_pages.css"><link rel="stylesheet" href="../assets/director_portal.css?v=20260927-12"><link rel="stylesheet" href="../assets/inspired_layout.css?v=20260929-1"><link rel="stylesheet" href="../assets/unified_home_report.css?v=20260929-1"></head>
<body class="role-page director-v2 unified-report-page"><?php renderSidebar();renderUserTopbar();?><main class="director-main unified-report-wrap">
<section class="unified-report-title"><h1>รายงานสรุปข้อมูลผู้สูงอายุ</h1><p>ดูภาพรวมข้อมูลล่าสุดในระบบ และเลือกเปิดรายงานที่ต้องการ</p></section>
<section class="unified-report-panel">
<h2>สรุปข้อมูลในระบบ</h2>
<div class="unified-report-kpis">
<div class="unified-report-kpi"><span>ผู้สูงอายุในระบบ</span><strong><?=number_format((int)$metrics['patients'])?> คน</strong></div>
<div class="unified-report-kpi"><span>ประเมิน ADL แล้ว</span><strong><?=number_format((int)$am['done'])?> คน</strong></div>
<div class="unified-report-kpi"><span>การเข้าเยี่ยมทั้งหมด</span><strong><?=number_format((int)$vm['total'])?> ครั้ง</strong></div>
<div class="unified-report-kpi"><span>การเข้าเยี่ยมเดือนนี้</span><strong><?=number_format((int)$vm['monthTotal'])?> ครั้ง</strong></div>
</div>
</section>
<section class="unified-report-panel">
<h2>เลือกรายงานที่ต้องการดู</h2>
<div class="unified-report-grid">
<article class="unified-report-card"><span class="report-card-kicker">ภาพรวม</span><h3>รายงานสรุปภาพรวม</h3><p>สรุปจำนวนผู้สูงอายุ หมู่บ้าน ผลการประเมิน ADL และข้อมูลสำคัญของระบบในหน้าเดียว</p><div class="unified-report-actions"><a class="unified-report-btn primary" href="../admin/statistics.php">ดูรายงานสรุป</a><a class="unified-report-btn" href="../admin/statistics_print.php" target="_blank" rel="noopener">พิมพ์รายงาน</a></div></article>
<article class="unified-report-card"><span class="report-card-kicker">รายบุคคล</span><h3>ข้อมูลผู้สูงอายุ</h3><p>ดูรายชื่อและข้อมูลสำคัญของผู้สูงอายุแต่ละรายที่บันทึกอยู่ในระบบ</p><div class="unified-report-actions"><a class="unified-report-btn primary" href="director_patients.php">ดูข้อมูลผู้สูงอายุ</a></div></article>
<article class="unified-report-card"><span class="report-card-kicker">การติดตามดูแล</span><h3>รายงานการเข้าเยี่ยม</h3><p>ดูประวัติการเข้าเยี่ยม วันที่เข้าเยี่ยม และข้อมูลการติดตามดูแลผู้สูงอายุ</p><div class="unified-report-actions"><a class="unified-report-btn primary" href="director_visits.php">ดูรายงานการเข้าเยี่ยม</a></div></article>
<article class="unified-report-card"><span class="report-card-kicker">ผลการประเมิน</span><h3>รายงานผลการประเมิน ADL</h3><p>ดูคะแนน ADL ผลการประเมิน และสถานะล่าสุดของผู้สูงอายุแต่ละราย</p><div class="unified-report-actions"><a class="unified-report-btn primary" href="director_assessments.php">ดูผลการประเมิน ADL</a></div></article>
</div>
</section>
</main></body></html>
