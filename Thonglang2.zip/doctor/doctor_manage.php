<?php
header('Location: doctor.php');
exit;
