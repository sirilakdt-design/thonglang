<?php
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

function jsonOut($data, int $status = 200): void {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function requestJson(string $url): array {
    $ua = 'Thonglang Elderly Care System/1.2 (local XAMPP application)';
    $body = false;
    $status = 0;

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_TIMEOUT => 15,
            CURLOPT_USERAGENT => $ua,
            CURLOPT_HTTPHEADER => ['Accept: application/json', 'Accept-Language: th,en;q=0.8'],
        ]);
        $body = curl_exec($ch);
        $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_error($ch);
        curl_close($ch);
        if ($body === false) throw new RuntimeException($err !== '' ? $err : 'ไม่สามารถเชื่อมต่อบริการค้นหาตำแหน่งได้');
    } else {
        $context = stream_context_create([
            'http' => [
                'method' => 'GET',
                'timeout' => 15,
                'header' => "User-Agent: {$ua}\r\nAccept: application/json\r\nAccept-Language: th,en;q=0.8\r\n",
            ],
        ]);
        $body = @file_get_contents($url, false, $context);
        if ($body === false) throw new RuntimeException('ไม่สามารถเชื่อมต่อบริการค้นหาตำแหน่งได้');
        $status = 200;
    }

    if ($status >= 400) throw new RuntimeException('บริการค้นหาตำแหน่งตอบกลับผิดพลาด (' . $status . ')');
    $json = json_decode((string)$body, true);
    if (!is_array($json)) throw new RuntimeException('ข้อมูลตำแหน่งที่ได้รับไม่ถูกต้อง');
    return $json;
}

function norm(string $text): string {
    $text = mb_strtolower($text, 'UTF-8');
    return preg_replace('/\s+/u', '', $text) ?? $text;
}

function normalizeVillageKey(string $text): string {
    $text = trim($text);
    $text = preg_replace('/^บ้าน/u', '', $text) ?? $text;
    $text = preg_replace('/\s*หมู่(?:ที่)?\s*\d+\s*$/u', '', $text) ?? $text;
    $text = mb_strtolower($text, 'UTF-8');
    return preg_replace('/\s+/u', '', $text) ?? $text;
}

function localVillageDirectory(): array {
    // พิกัดศูนย์กลางหมู่บ้านใน ต.ทองหลาง ใช้เป็น fallback เมื่อ API ภายนอกค้นชื่อไทยไม่พบ
    return [
        'เหมสูง' => ['name'=>'บ้านเหมสูง','moo'=>'1','lat'=>'15.063750','lon'=>'102.342560'],
        'โนนนางฝ้าย' => ['name'=>'บ้านโนนนางฝ้าย','moo'=>'2','lat'=>'15.060472','lon'=>'102.371417'],
        'เหมต่ำ' => ['name'=>'บ้านเหมต่ำ','moo'=>'3','lat'=>'15.073670','lon'=>'102.340580'],
        'ทองหลาง' => ['name'=>'บ้านทองหลาง','moo'=>'4','lat'=>'15.050000','lon'=>'102.353700'],
        'หนองบัวตะแบง' => ['name'=>'บ้านหนองบัวตะแบง','moo'=>'5','lat'=>'15.055860','lon'=>'102.364030'],
        'หนองตาโยย' => ['name'=>'บ้านหนองตาโยย','moo'=>'6','lat'=>'15.056000','lon'=>'102.374250'],
        'หนองมโนรมย์' => ['name'=>'บ้านหนองมโนรมย์','moo'=>'7','lat'=>'15.019440','lon'=>'102.357050'],
        'ตูม' => ['name'=>'บ้านตูม','moo'=>'8-9','lat'=>'15.038470','lon'=>'102.344720'],
    ];
}

function localVillageMatches(string $q): array {
    $key = normalizeVillageKey($q);
    if ($key === '') return [];
    $out = [];
    foreach (localVillageDirectory() as $name => $row) {
        $n = normalizeVillageKey($name);
        if ($n === $key || mb_strpos($n, $key) !== false || mb_strpos($key, $n) !== false) {
            $display = $row['name'] . ' หมู่ที่ ' . $row['moo'] . ', ตำบลทองหลาง, อำเภอจักราช, จังหวัดนครราชสีมา';
            $out[] = [
                'place_id' => 'local-' . md5($name),
                'lat' => $row['lat'],
                'lon' => $row['lon'],
                'name' => $row['name'],
                'display_name' => $display,
                'type' => 'village',
                'source' => 'local_directory',
                'address' => [
                    'village' => $row['name'],
                    'subdistrict' => 'ทองหลาง',
                    'district' => 'จักราช',
                    'province' => 'นครราชสีมา',
                    'country' => 'ประเทศไทย'
                ]
            ];
        }
    }
    return $out;
}

function isInThonglangVicinity(array $item): bool {
    $lat = isset($item['lat']) ? (float)$item['lat'] : null;
    $lon = isset($item['lon']) ? (float)$item['lon'] : null;
    if ($lat === null || $lon === null) return false;
    // ขอบเขตกว้างพอสำหรับทุกหมู่บ้านใน ต.ทองหลาง และช่วยตัดผลลัพธ์ชื่อซ้ำต่างจังหวัดออก
    return $lat >= 14.98 && $lat <= 15.10 && $lon >= 102.31 && $lon <= 102.40;
}

function nominatimSearch(string $query, int $limit = 10): array {
    $url = 'https://nominatim.openstreetmap.org/search?' . http_build_query([
        'format' => 'jsonv2',
        'q' => $query,
        'addressdetails' => 1,
        'limit' => $limit,
        'countrycodes' => 'th',
        'accept-language' => 'th',
        // จำกัดบริเวณรอบ ต.ทองหลาง แต่ไม่ใช้ bounded=1 เพื่อไม่ให้ชื่อที่อยู่ชิดขอบหาย
        'viewbox' => '102.31,15.10,102.40,14.98'
    ]);
    $rows = requestJson($url);
    $near = array_values(array_filter($rows, 'isInThonglangVicinity'));
    return $near ?: $rows;
}

function cleanVillageName(string $q): string {
    $q = trim($q);
    $q = preg_replace('/\s+/u', ' ', $q) ?? $q;
    return trim($q);
}

function baseVillageName(string $q): string {
    $q = cleanVillageName($q);
    $q = preg_replace('/^บ้าน/u', '', $q) ?? $q;
    $q = preg_replace('/\s*หมู่(?:ที่)?\s*\d+\s*$/u', '', $q) ?? $q;
    return trim($q);
}

$action = strtolower(trim((string)($_GET['action'] ?? 'search')));
try {
    if ($action === 'reverse') {
        $lat = trim((string)($_GET['lat'] ?? ''));
        $lon = trim((string)($_GET['lon'] ?? ''));
        if (!is_numeric($lat) || !is_numeric($lon)) jsonOut(['ok' => false, 'message' => 'พิกัดไม่ถูกต้อง'], 422);
        $latF = (float)$lat; $lonF = (float)$lon;
        if ($latF < -90 || $latF > 90 || $lonF < -180 || $lonF > 180) jsonOut(['ok' => false, 'message' => 'พิกัดอยู่นอกช่วงที่ถูกต้อง'], 422);

        $url = 'https://nominatim.openstreetmap.org/reverse?' . http_build_query([
            'format' => 'jsonv2', 'lat' => $latF, 'lon' => $lonF,
            'addressdetails' => 1, 'zoom' => 18, 'accept-language' => 'th'
        ]);
        $data = requestJson($url);
        if (!isInThonglangVicinity($data)) {
            jsonOut(['ok' => false, 'message' => 'ตำแหน่งนี้อยู่นอกบริเวณตำบลทองหลาง อำเภอจักราช จังหวัดนครราชสีมา'], 422);
        }
        jsonOut(['ok' => true, 'result' => $data]);
    }

    $q = cleanVillageName((string)($_GET['q'] ?? ''));
    if (mb_strlen($q, 'UTF-8') < 2) jsonOut(['ok' => false, 'message' => 'กรุณาพิมพ์ชื่อหมู่บ้านอย่างน้อย 2 ตัวอักษร'], 422);

    $base = baseVillageName($q);

    // ใช้รายการหมู่บ้านใน ต.ทองหลางก่อน เพื่อให้ชื่อหมู่บ้านที่ API ภายนอกสะกด/จัดเขตไม่ตรงยังค้นหาได้แน่นอน
    $all = localVillageMatches($base !== '' ? $base : $q);
    $seen = [];
    foreach ($all as $row) {
        $seen[(string)$row['place_id']] = true;
    }

    // เสริมผลจาก OpenStreetMap สำหรับชื่อที่ไม่มีในรายการ fallback หรือมีจุดที่ละเอียดกว่า
    $queries = array_values(array_unique(array_filter([
        'บ้าน' . $base . ', จักราช, นครราชสีมา',
        $base . ', จักราช, นครราชสีมา',
        $base . ', นครราชสีมา',
        $q
    ])));

    foreach ($queries as $query) {
        try {
            $rows = nominatimSearch($query, 10);
        } catch (Throwable $ignore) {
            $rows = [];
        }
        foreach ($rows as $row) {
            if (!isInThonglangVicinity($row)) continue;
            $key = (string)($row['place_id'] ?? (($row['lat'] ?? '') . '|' . ($row['lon'] ?? '')));
            if ($key === '' || isset($seen[$key])) continue;
            $seen[$key] = true;
            $all[] = $row;
            if (count($all) >= 7) break 2;
        }
    }

    if (!$all) {
        jsonOut(['ok' => true, 'results' => [], 'village_query' => $q, 'message' => 'ไม่พบชื่อหมู่บ้านในตำบลทองหลาง']);
    }
    jsonOut(['ok' => true, 'results' => $all, 'village_query' => $q]);
} catch (Throwable $e) {
    jsonOut(['ok' => false, 'message' => 'ค้นหาตำแหน่งไม่สำเร็จ: ' . $e->getMessage()], 502);
}
